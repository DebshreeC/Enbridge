﻿using BOLTAPIServices.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using BOLTAPIServices.Settings;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Repositories.FlowRates;
using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Helpers.Interfaces;
using Microsoft.ApplicationInsights;
using Azure;
using System.Security.Cryptography.Xml;
using Namotion.Reflection;




namespace BOLTAPIServices.Services
{
    /// <summary>
    /// Flow rate service injected from controller class to get flow rate data
    /// </summary>
    public class FlowRateService
    {
        private readonly IViewCombinedFlowRateRepository _combinedflowrateRepository;
        private readonly IViewMetaFlowRateRepository _viewMetaFlowRateRepository;
        private readonly IViewHistoryMetaFlowRateRepository _viewHistoryMetaFlowRateRepository;
        private readonly IViewHistoryDetailFlowRateRepository _historyDetailFlowRateRepository;
        private readonly IViewHistorySummaryFlowRateRepository _historySummaryFlowRateRepository;

        private readonly ILineStationReferenceRepository _lineStationReferenceRepository;
        private readonly IReferenceFlowRateRepository _referenceFlowRateRepository;
        private readonly IDraftFlowRateRepository _draftFlowRateRepository;

        private readonly IPublishedFlowRateRepository _publishedFlowRateRepository;


        private readonly ILogger<FlowRateService> _logger;
        private readonly IHttpClientFactory _httpFactory;
        private readonly IConfiguration _configuration;
        private readonly BoltConfigSettings _boltConfigSettings;
        private readonly CredentialService _credentialService;
        private readonly IKeyVaultManager _keyVaultManager;
        private Boolean debug = false;
        private TelemetryClient _teleClient;



        /// <summary>
        /// Flow rate service injected from controller class to get flow rate data
        /// </summary>
        public FlowRateService(IViewCombinedFlowRateRepository combinedflowrateRepository, IViewMetaFlowRateRepository viewMetaFlowRateRepository, IViewHistoryMetaFlowRateRepository viewHistoryMetaFlowRateRepository,IViewHistoryDetailFlowRateRepository historyDetailFlowRateRepository,
                                IViewHistorySummaryFlowRateRepository historySummaryFlowRateRepository, ILineStationReferenceRepository lineStationReferenceRepository, IReferenceFlowRateRepository referenceFlowRateRepository, 
                                IDraftFlowRateRepository draftFlowRateRepository, IPublishedFlowRateRepository publishedFlowRateRepository, ILogger<FlowRateService> logger, IHttpClientFactory httpFactory, 
                                IConfiguration configration, IOptions<BoltConfigSettings> boltconfigsettings, IKeyVaultManager keyVaultManager, CredentialService credentialService, TelemetryClient teleClient)
        {
            _combinedflowrateRepository = combinedflowrateRepository ?? throw new ArgumentNullException(nameof(combinedflowrateRepository));
            _viewMetaFlowRateRepository = viewMetaFlowRateRepository ?? throw new ArgumentNullException(nameof(viewMetaFlowRateRepository));
            _viewHistoryMetaFlowRateRepository = viewHistoryMetaFlowRateRepository ?? throw new ArgumentNullException(nameof(viewHistoryMetaFlowRateRepository));
            _historyDetailFlowRateRepository = historyDetailFlowRateRepository ?? throw new ArgumentNullException(nameof(historyDetailFlowRateRepository));
            _historySummaryFlowRateRepository = historySummaryFlowRateRepository ?? throw new ArgumentNullException(nameof(historySummaryFlowRateRepository));

            _lineStationReferenceRepository = lineStationReferenceRepository ?? throw new ArgumentNullException(nameof(lineStationReferenceRepository));
            _referenceFlowRateRepository = referenceFlowRateRepository ?? throw new ArgumentNullException(nameof(referenceFlowRateRepository));
            _draftFlowRateRepository = draftFlowRateRepository ?? throw new ArgumentNullException(nameof(draftFlowRateRepository));

            _publishedFlowRateRepository = publishedFlowRateRepository ?? throw new ArgumentNullException(nameof(publishedFlowRateRepository));

            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpFactory = httpFactory ?? throw new ArgumentNullException(nameof(httpFactory));
            _configuration = configration ?? throw new ArgumentNullException(nameof(configration));
            _credentialService = credentialService ?? throw new ArgumentNullException(nameof(credentialService));
            _keyVaultManager = keyVaultManager ?? throw new ArgumentNullException(nameof(keyVaultManager));
            _teleClient = teleClient ?? throw new ArgumentNullException(nameof(teleClient));
            // _paginationSettings = paginationSettings.Value;
            _boltConfigSettings = boltconfigsettings.Value;
            debug = _configuration.GetValue<Boolean>("Debug");
        }

        /// <summary>
        /// Retrieves all combined flow rates asynchronously.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a collection of ViewCombinedFlowRate.</returns>
        public async Task<RootFlowRate> GetCombinedFlowRatesAsync()
        {

            try

            {



                List<ViewCombinedFlowRate> items = null;
                List<ViewMetaFlowRate> meta = null;

                Parallel.Invoke(
                () => items = _combinedflowrateRepository.GetAll()
                                                            .OrderBy(i => _lineStationReferenceRepository.GetByColumName("line", i.Line)
                                                                .Select(j => j.RegionOrder).FirstOrDefault())
                                                            .ThenBy(i => _lineStationReferenceRepository.GetByColumName("line", i.Line)
                                                                .Select(j => j.LineOrder).FirstOrDefault())
                                                            .ToList(),
                () => meta = _viewMetaFlowRateRepository.GetAll().ToList()
                );

                RootFlowRate rootFlowRate = new RootFlowRate()
                {
                    Meta = new ViewMetaFlowRate
                    {
                        optimusUpdadateSuccessFlag = 0,
                        refFlowRateUpdatedDateTime = meta.FirstOrDefault().refFlowRateUpdatedDateTime,
                        userFlowRateUpdatedDateTime = meta.FirstOrDefault().userFlowRateUpdatedDateTime,
                        publishedFlowRateUpdatedDateTime = meta.FirstOrDefault().publishedFlowRateUpdatedDateTime,
                        updatedByUserGUID = meta.FirstOrDefault().updatedByUserGUID,
                        updatedByUserId = meta.FirstOrDefault().updatedByUserId.Trim(),
                        updatedByUsername = meta.FirstOrDefault().updatedByUsername.Trim()

                    },

                    Data = items.Select(x => new ViewCombinedFlowRate
                    {
                        Line = x.Line.Trim()
                        ,Region = x.Region.Trim()
                        ,RefFlowRatem3hr = x.RefFlowRatem3hr
                        ,PublishedFlowRatem3hr = x.PublishedFlowRatem3hr
                        ,DraftFlowRatem3hr = x.DraftFlowRatem3hr
                    }).ToList()
                };

                var result = rootFlowRate;
                return await Task.FromResult(result);


            }

            catch (Exception ex)

            {

                _logger.LogError(GetType().Name, ex);

                return new RootFlowRate();

            }

        }


        /// <summary>
        /// Creates a draft of reference flow rates.
        /// </summary>
        /// <returns> result indicating the outcome of the operation.</returns>
        public async Task<bool> CreateReferencetAsync(int refVal)
        {
            try
            {
                List<ReferenceFlowRate> referenceFlowRates = new List<ReferenceFlowRate>();
                string json = string.Empty;
                bool bMockOptimus = _configuration.GetValue<bool>("MockOptimus");
                if (!bMockOptimus)
                {
                    _logger.LogInformation($"Debug: {debug}");

                    if (debug)
                    {
                        _logger.LogInformation($"MockOptimus: {bMockOptimus}");
                        _logger.LogInformation($"Getting keyvault secret..");
                    }
                        

                    Dictionary<String, String> optimusCreds = _keyVaultManager.GetOptimusUserCreds();

                    if (debug)
                        _logger.LogInformation($"Received keyvault secret.Ref value is {refVal}");
                    
                    string username = optimusCreds["username"];
                    string password = optimusCreds["password"];
                    string domain = optimusCreds["domain"];

                    if (debug)
                        _logger.LogInformation($"service principal user: {username} : {password} : {domain}");

                    _credentialService.SetCredentials(username, password, domain);

                    HttpClient httpclient = _httpFactory.CreateClient("FlowRatesHttpClient");
                    
                    if (_configuration.GetValue<String>("Debug") + "".ToLower() == "true")

                    {
                        _logger.LogInformation($"FlowRatesHttpClient.BaseURL {httpclient.BaseAddress}");
                    }
                    DateTime date = DateTime.Now;
                    string formattedDate = date.ToString("MM-dd-yyyy");
                    var response = await httpclient.GetAsync($"GetNFRReportForDate?dateTime={formattedDate}");

                    if (response.IsSuccessStatusCode)
                    { json = await response.Content.ReadAsStringAsync();
                      _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "optimus reponse success", json.Length.ToString() } });
                    }


                    else
                    {
                        if (debug)
                        {
                            _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "optimus reponse failed", $"Ref value {refVal}" } });
                            _logger.LogInformation($"optimus reponse failed {response} Ref value {refVal}");
                        }

                    }

                }
                else
                {
                    _logger.LogInformation($"MockOptimus: {bMockOptimus}");

                    if (_configuration.GetValue<String>("Debug") + "".ToLower() == "true")
                    {
                        _logger.LogInformation("debug is on");
                    }
                    json = System.IO.File.ReadAllText("Mock/Mock.json");

                    
                }

                if (json.Length > 0)
                {

                    if (debug)
                    {
                        _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "Optimus Response", "Received" } });
                        _logger.LogInformation($"Optimus Response Received");
                        
                    }

                    var settings = new JsonSerializerSettings { Converters = new List<JsonConverter> { new DecimalToIntJsonConverter(("RefFlowRatem3hr")) } }; // Assuming default settings, adjust as needed
                    var referenceRoot = JsonConvert.DeserializeObject<ReferenceRoot>(json, settings);
                    if (referenceRoot != null && referenceRoot.LineRows.Count > 0)
                    {
                        referenceFlowRates = BuildReferenceData(referenceRoot);
                        // Process referenceRoot as needed
                        var result = await LoadReferenceFlowRates(referenceFlowRates, true,refVal);
                        return result;
                    }
                    else
                    {
                        _logger.LogError("Failed to deserialize json results");
                        _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "Deserialization", "Failed" } });
                        return false;
                    }
                }
                else
                {
                    _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "request success", "with no data" } });
                    _logger.LogError("Failed to get Optimus data for reference flow rate");
                    var result = await LoadReferenceFlowRates(referenceFlowRates, false,refVal);
                    if (debug)
                    {
                        _logger.LogInformation($"No optimus response");
                        _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "request success", "No optimus response" } });
                    }
                    
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                _teleClient.TrackEvent("CreateReferencetAsync", new Dictionary<string, string> { { "error", ex.ToString() } });
                var result = await LoadReferenceFlowRates(null, false, refVal);
                return false;
            }
        }
        private List<ReferenceFlowRate> BuildReferenceData(ReferenceRoot rRoot)
        {
            // Define the start and end times
            DateTime startTime = DateTime.Now;

            var referenceFlowRates = new List<ReferenceFlowRate>();
            var lineStationReferences = _lineStationReferenceRepository.GetAll();

            var joinedData = from line in rRoot.LineRows
                             join lsr in lineStationReferences
                             on line.LineId equals lsr.OptimusLineReferenceGuid
                             from rate in line.Rates
                             select new { lsr.Region, lsr.Line, Rate = rate };

            foreach (var item in joinedData)
            {
                // Check if the combination already exists
                bool exists = referenceFlowRates.Any(r =>
                    r.region == item.Region &&
                    r.line == item.Line &&
                    r.refFlowRatem3hr == item.Rate);

                if (!exists)
                {
                    var referenceFlowRate = new ReferenceFlowRate
                    {
                        region = item.Region ?? string.Empty,
                        line = item.Line ?? string.Empty,
                        refFlowRatem3hr = item.Rate,
                        refFlowRateUpdatedDateTime = rRoot.PublishDate
                    };
                    referenceFlowRates.Add(referenceFlowRate);
                }
            }
            DateTime endTime = DateTime.Now;

            // Calculate the difference
            TimeSpan timeDifference = endTime - startTime;

            Console.WriteLine($"Time taken to build reference data: {timeDifference.TotalSeconds} seconds");
            return referenceFlowRates;
        }
        private async Task<bool> LoadReferenceFlowRates(List<ReferenceFlowRate> incomingFlowRates, bool bsuccessfulpull, int refVal)
        {
            if (bsuccessfulpull) {
                var settings = new JsonSerializerSettings { Converters = new List<JsonConverter> { new DecimalToIntJsonConverter(("RefFlowRatem3hr")) } }; // Assuming default settings, adjust as needed
                string json = JsonConvert.SerializeObject(incomingFlowRates, settings);
                return await _referenceFlowRateRepository.LoadReferenceFlowRateTrans(json, bsuccessfulpull, refVal) > 0; }
            else
            {
                return await _referenceFlowRateRepository.LoadReferenceFlowRateTrans("", bsuccessfulpull, refVal) > 0;
            }

        }

        public async Task<bool> UpdateDraftFlowRate(string json, HttpContext httpcontext)
        {
            try
            {
                if (_draftFlowRateRepository is DraftFlowRateRepository derived)
                {
                    var result = await derived.UpsertData(json,httpcontext);
                    return result > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return false;
            }
        }

        public async Task<bool> PubslishedFlowRateTrans(HttpContext httpcontext)
        {
            try
            {
                if (_publishedFlowRateRepository != null)
                {
                    var result = await _publishedFlowRateRepository.LoadPublishedFlowRateTrans(httpcontext);
                    return result > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return false;
            }
        }

        /// <summary>
        /// Reterive History Detail Flow rate asynchronusly
        /// </summary>
        /// <returns></returns>

        public async Task<RootHistoryDetailFlowRate> GetHistoryDetailFlowRatesAsync( int HistoryID)
        {

            try

            {
                IEnumerable<ViewHistoryDetailFlowRate>? items = null;
                IEnumerable<ViewHistoryMetaFlowRate>? meta = null;

                Parallel.Invoke(() => items = _historyDetailFlowRateRepository.GetByColumName("HistoryID", HistoryID), () => meta = _viewHistoryMetaFlowRateRepository.GetByColumName("HistoryID", HistoryID));

                var orderedItems = items
                    .OrderBy(item => _lineStationReferenceRepository.GetAll()
                        .Where(lsr => lsr.Line == item.Line)  // Filter by `line`
                        .Select(lsr => lsr.RegionOrder)             // Reference `RegionOrder`
                        .FirstOrDefault())                         // Get the first match (or default)
                    .ThenBy(item => _lineStationReferenceRepository.GetAll()
                        .Where(lsr => lsr.Line == item.Line)  // Filter by `line`
                        .Select(lsr => lsr.LineOrder)               // Reference `LineOrder`
                        .FirstOrDefault())                         // Get the first match (or default)
                    .ToList();

                if (items != null && items.ToList().Count()>0)
                {
                    RootHistoryDetailFlowRate rootFlowRate = new RootHistoryDetailFlowRate()
                    {
                        Meta = new ViewHistoryMetaFlowRate
                        {
                            HistoryId = meta.FirstOrDefault().HistoryId,
                            refFlowRateUpdatedDateTime = meta.FirstOrDefault().refFlowRateUpdatedDateTime,
                            userFlowRateUpdatedDateTime = meta.FirstOrDefault().userFlowRateUpdatedDateTime,
                            publishedFlowRateUpdatedDateTime = meta.FirstOrDefault().publishedFlowRateUpdatedDateTime,
                            updatedByUserGUID = meta.FirstOrDefault().updatedByUserGUID,
                            updatedByUserId = meta.FirstOrDefault().updatedByUserId,
                            updatedByUsername = meta.FirstOrDefault().updatedByUsername
                        },
                        Data = orderedItems.ToList()

                    };
                    var result = rootFlowRate;
                    return await Task.FromResult(result);
                }
                else

                    return new RootHistoryDetailFlowRate();

            }

            catch (Exception ex)

            {

                _logger.LogError(GetType().Name, ex);

                return new RootHistoryDetailFlowRate();

            }

        }

        /// <summary>
        /// page size of summary record set
        /// </summary>
        public int GetPageSize()
        {
            return _boltConfigSettings.Pagination.PageSize;
        }

        public async Task<(IEnumerable<ViewHistorySummaryFlowRate>, int reccount)> GetHistorySummaryFlowRatesAsync(int pageNumber)
        {

            try
            {
                // Validate the page number
                if (pageNumber < 1) pageNumber = 1;

                // Fetch paginated records
                var items = _historySummaryFlowRateRepository.GetPaginatedFlowRates(pageNumber, GetPageSize());
                int totalrecords = await _historySummaryFlowRateRepository.GetTotalRecordsAsync();
                return  (items, totalrecords);

            }
            catch (Exception ex)

            {

                _logger.LogError(GetType().Name, ex);

                return (new List<ViewHistorySummaryFlowRate>(),0) ;

            }
        }

    }
}


    