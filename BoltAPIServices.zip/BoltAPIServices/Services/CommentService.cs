﻿using BOLTAPIServices.Models;
using BOLTAPIServices.Models.PowerCurves;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Repositories.Interfaces.PowerCurves;
using BOLTAPIServices.Settings;
using Microsoft.Extensions.Options;
using System.Net;

namespace BOLTAPIServices.Services
{
    public class CommentService
    {
        private readonly ICommentRepository _commentRepository;


        public CommentService(ICommentRepository commentRepository)
        {

            _commentRepository = commentRepository ?? throw new ArgumentNullException(nameof(commentRepository));

        }

            /// <inheritdoc/>
        public async Task<HttpStatusCode> AddComment(CommentInput commentInput, HttpContext httpcontext)
        {
            HttpStatusCode result = await _commentRepository.AddComment(commentInput, httpcontext);
            return result;


        }


        public async Task<IEnumerable<Comments>> ViewComment(string reference, int refId)
        {
            try
            {

                IEnumerable<Comments> items = null;
                items = await _commentRepository.ViewComment(reference, refId);   
                return await Task.FromResult(items);

            }

            catch (Exception ex)
            {

               // _logger.LogError(GetType().Name, ex);

                return new List<Comments>();

            }

        }
    }

}
