﻿using BOLTAPIServices.Models;
using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;
using BOLTAPIServices.Repositories;
using Microsoft.Extensions.Options;
using BOLTAPIServices.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using BOLTAPIServices.Repositories.Interfaces.PowerCurves;
using BOLTAPIServices.Models.PowerCurves;
using static BOLTAPIServices.Models.UpdateUserPower;
using BOLTAPIServices.Repositories.Interfaces;
using Microsoft.AspNetCore.Http.HttpResults;
using BOLTAPIServices.Models.FlowRates;
using Namotion.Reflection;
using System.Text.Json.Nodes;
using BOLTAPIServices.DTO;
using AutoMapper;
using System.Collections.Generic;
using Microsoft.ApplicationInsights;



namespace BOLTAPIServices.Services
{
    /// <summary>
    /// Power Curve  service injected from controller class to get PowerCurve data
    /// </summary>
    public class PowerCurveService
    {
        private readonly IViewPowerCurveRegionRepository _viewPowerCurveRepository;
        private readonly IPowerCurveRepository _powerCurveRepository;
        private readonly IPowerCurveDetailsRepository _powerCurveDetailsRepository;



        private readonly ILogger<PowerCurveService> _logger;
        private readonly IHttpClientFactory _httpFactory;
        private readonly IConfiguration _configuration;
        private readonly BoltConfigSettings _boltConfigSettings;
        private readonly IMapper _mapper;
        private readonly TelemetryClient _teleclient ;



        /// <summary>
        /// Power curve  service injected from controller class to get Power Curve  data
        /// </summary>
        public PowerCurveService(IViewPowerCurveRegionRepository viewPowerCurveRepository, IMapper mapper, IPowerCurveRepository powerCurveRepository, IPowerCurveDetailsRepository powerCurveDetailsRepository, ILogger<PowerCurveService> logger, IHttpClientFactory httpFactory, IConfiguration configration, IOptions<BoltConfigSettings> boltconfigsettings, TelemetryClient teleClient)
        {
            _viewPowerCurveRepository = viewPowerCurveRepository ?? throw new ArgumentNullException(nameof(viewPowerCurveRepository));
            _powerCurveRepository = powerCurveRepository ?? throw new ArgumentNullException(nameof(powerCurveRepository));
            _powerCurveDetailsRepository = powerCurveDetailsRepository ?? throw new ArgumentNullException(nameof(powerCurveDetailsRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpFactory = httpFactory ?? throw new ArgumentNullException(nameof(httpFactory));
            _configuration = configration ?? throw new ArgumentNullException(nameof(configration));
            _teleclient = teleClient ?? throw new ArgumentNullException(nameof(teleClient));
            _boltConfigSettings = boltconfigsettings.Value;
            _mapper = mapper ?? throw new ArgumentNullException(nameof (mapper));
        }

        /// <summary>
        /// Reterive the PowerCurve summary
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ViewPowerCurveRegion>> GetPowerCurveAsync()
        {
            try
            {

                // Fetch all items from the repository
                var items = _viewPowerCurveRepository.GetAll().ToList();

                // Apply ordering by lineOrder and regionOrder
                var orderedItems = items
                    .OrderBy(item => item.regionOrder)  // Order by regionOrder
                    .ThenBy(item => item.lineOrder) // Then by lineOrder
                    .ToList();

                return await Task.FromResult(orderedItems);

            }

            catch (Exception ex)
            {

                _logger.LogError(GetType().Name, ex);

                return new List<ViewPowerCurveRegion>();

            }

        }

        /// <summary>
        /// Reterive the PowerCurve Details  based on PowerCurveID
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<PowerCurveDetails>> GetPowerCurveDetailsAsync(int PowerCurveID)
        {
            try
            {

                List<PowerCurveDetails> items = null;
                items = _powerCurveDetailsRepository.GetByColumName("PowerCurveID", PowerCurveID).ToList();
                // Associate station details with power curve details
                foreach (var detail in items)
                {
                    if (detail != null && detail.historicalDateRange != null)
                    {
                        // detail.PowerCurveStationDetails = items?.ToList();
                        // Convert JSON string to a List
                        detail.historicalDateRanges = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HistoricalDateRange>>(detail.historicalDateRange) ?? new List<HistoricalDateRange>();

                    }
                }
                return await Task.FromResult(items);

            }

            catch (Exception ex)
            {

                _logger.LogError(GetType().Name, ex);

                return new List<PowerCurveDetails>();

            }

        }


        /// <summary>
        /// Method to  toggle the favourite the power curve based on PowerCurveID
        /// </summary>
        /// <param name="PowerCurveID"></param>
        /// <returns></returns>
        public async Task<PowerCurve?> MarkFavouriteAsync(int PowerCurveID)
        {
            var result = await _powerCurveRepository.MarkFavourite(PowerCurveID);
            return result;
        }

        /// <inheritdoc/>

        public async Task<(string StatusMessage, int StatusCode)> SaveDraftPowerCurve(DraftPowerCurve draftPowerCurveData, HttpContext httpcontext)
        {

            try
            {


                string jsonData = JsonSerializer.Serialize(draftPowerCurveData);
                var (result, StatusCode) = await _powerCurveRepository.LoadDraftPowerCurveTrans(jsonData, httpcontext);
                return (result, StatusCode);


            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }

        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> UpdateDraftPowerCurve(UpdateDraftPowerCurve draftPowerCurveData, int PowerCurveID, HttpContext httpcontext)
        {

            try
            {


                string jsonData = JsonSerializer.Serialize(draftPowerCurveData);
                var (result, StatusCode) = await _powerCurveRepository.UpdatePowerCurveDraft(jsonData, PowerCurveID, httpcontext);
                return (result, StatusCode);


            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }




        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> StationPowerCurveDraft(StationPowerCurveDraft stationPowerCurveData, int PowerCurveID, HttpContext httpcontext)
        {

            try
            {


                string jsonData = JsonSerializer.Serialize(stationPowerCurveData);
                var (result, StatusCode) = await _powerCurveRepository.StationPowerCurveDraft(jsonData, PowerCurveID, httpcontext);
                await callAzureHttpRequest(PowerCurveID);
                return (result, StatusCode);


            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> UpdateStationforPowerCurveDraft(UpdateStationPowerCurve stationPowerCurveData, int PowerCurveDetailID, HttpContext httpcontext)
        {

            try
            {

                // Retrieve a single item
                PowerCurveDetails items = null;
                int PowerCurveID=0;
                items = _powerCurveDetailsRepository.GetByColumName("PowerCurveDetailID", PowerCurveDetailID).FirstOrDefault();
                if (items != null)
                {

                    items.historicalDateRanges = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HistoricalDateRange>>(items.historicalDateRange) ?? new List<HistoricalDateRange>();
                    PowerCurveID = items.powerCurveID;
                    
                }

                string jsonData = JsonSerializer.Serialize(stationPowerCurveData);



                var (result, StatusCode) = await _powerCurveRepository.UpdateStationforPowerCurveDraft(jsonData, PowerCurveDetailID, httpcontext);

                if(stationPowerCurveData.data.historicDates!= null)
                {
                    // Map historicalDateRanges to a comparable list
                    var OldHistoricDates = items.historicalDateRanges
                        .Select(dateRange => new { StartDate=dateRange.startDate.Date, EndDate=dateRange.endDate.Date })
                        .ToList();

                    // Map historicDates to a comparable list
                    var NewHistoricDates = stationPowerCurveData.data.historicDates
                        .Select(date => new {StartDate= date.startDate.Date, EndDate=date.endDate.Date })
                        .ToList();

                    // Compare the two lists using SequenceEqual
                    bool areHistricalDatesEqual = OldHistoricDates.SequenceEqual(NewHistoricDates);

                    if (!areHistricalDatesEqual)
                    {
                        await callAzureHttpRequest(PowerCurveID);

                    }

                }

                return (result, StatusCode);



            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> GeneratePowerAsync(int PowerCurveID)
        {
            
             
            try
            {

                var (result, StatusCode) = await _powerCurveRepository.GeneratePowerCurve(PowerCurveID);
               await callAzureHttpRequest(PowerCurveID);

                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return  (ex.GetBaseException().ToString(), 400);
            }
        }

        /// <summary>
        /// Reterive the PowerCurve + PowerCurve Details  based on PowerCurveID
        /// </summary>
        /// <returns></returns>
        public async Task<RootPowerCurveDetail> ViewPowerCurveDetailsAsync(int PowerCurveID)
        {
            try
            {

                IEnumerable<ViewPowerCurveDetail> items = null;

                items = _powerCurveRepository.ViewPowerCurveDetailsAsync(PowerCurveID).Result;

                // Associate station details with power curve details
                foreach (var detail in items)
                {
                    if (detail != null && detail.historicalDateRange != null)
                    {
                        // detail.PowerCurveStationDetails = items?.ToList();
                        // Convert JSON string to a List
                        detail.historicalDateRanges = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HistoricalDateRange>>(detail.historicalDateRange) ?? new List<HistoricalDateRange>();

                    }
                }

                IEnumerable<ViewPowerCurveRegion>? meta = null;
                meta = _viewPowerCurveRepository.GetByColumName("PowerCurveID",PowerCurveID);

                var metaDto = _mapper.Map<MetaPowerCurveDTO>(meta.FirstOrDefault());

                RootPowerCurveDetail rootPowerCurve = new RootPowerCurveDetail()
                {
                    meta = metaDto,
                    data = items.ToList()

                };

                var result = rootPowerCurve;
                return await Task.FromResult(result);


                // return await Task.FromResult(items);

            }

            catch (Exception ex)
            {

                _logger.LogError(GetType().Name, ex);

                return new RootPowerCurveDetail();

            }

        }

        /// <summary>
        /// Retrieve the PowerCurve and PowerCurve Details based on PowerCurveID and Station.
        /// </summary>
        /// <param name="PowerCurveID">The PowerCurve ID.</param>
        /// <param name="Station">The Station name.</param>
        /// <returns>A <see cref="PowerCurveResponse"/> containing metadata and details.</returns>
        public async Task<PowerCurveResponse> GetPowerCurveDtlbasedonStation(int PowerCurveID, string? Station)
        {
            try
            {
                // Fetch metadata
                var meta = _viewPowerCurveRepository.GetByColumName("PowerCurveID", PowerCurveID);
                if (meta == null || !meta.Any())
                {
                    throw new Exception("Metadata not found for the given PowerCurveID.");
                }

            
                var powerCurveDetails = await _powerCurveRepository.GetPowerCurveDtl(PowerCurveID, Station);

                // Associate station details with power curve details
                foreach (var detail in powerCurveDetails)
                {
                    if (detail != null && detail.historicalDateRange != null)
                    {
                        // detail.PowerCurveStationDetails = items?.ToList();
                        // Convert JSON string to a List
                     detail.historicalDateRanges = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HistoricalDateRange>>(detail.historicalDateRange) ?? new List<HistoricalDateRange>();
                    }
                }

                // Construct the response
                var powerCurveResponse = new PowerCurveResponse
                {
                    meta = new ViewPowerCurveRegion
                    {
                        powerCurveID = meta.FirstOrDefault()?.powerCurveID ?? 0,
                        line = meta.FirstOrDefault()?.line,
                        region = meta.FirstOrDefault()?.region,
                        title = meta.FirstOrDefault()?.title,
                        applicableDateStart = meta.FirstOrDefault()?.applicableDateStart ?? DateTime.MinValue,
                        applicableDateEnd = meta.FirstOrDefault()?.applicableDateEnd ?? DateTime.MinValue,
                        status=meta.FirstOrDefault()?.status,
                        updatedByUserGUID=meta.FirstOrDefault()?.updatedByUserGUID,
                        updatedByUserId=meta.FirstOrDefault()?.updatedByUserId, 
                        updatedByUsername=meta.FirstOrDefault()?.updatedByUsername, 
                        lastUpdateDateTime = meta.FirstOrDefault()?.lastUpdateDateTime,
                        isFavourite=meta.FirstOrDefault().isFavourite
                        
                    },
                    data = powerCurveDetails.ToList()
                };

                return powerCurveResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in {MethodName}. PowerCurveID: {PowerCurveID}, Station: {Station}",
                    nameof(GetPowerCurveDtlbasedonStation), PowerCurveID, Station);

                // Return an empty response in case of an error
                return new PowerCurveResponse();
            }
        }
//
        public async Task<(string StatusMessage, int StatusCode)> DeletePowerCurve(int PowerCurveID)
        {
            try
            {
                var (result, status) = await _powerCurveRepository.DeletePowerCurve(PowerCurveID);
                return (result, status);
                // return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.Message.ToString(), 401);
            }
        }

        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> DeletePowerCurveStation(int PowerCurveDetailID)
        {

            try
            {

                var (result, status) = await _powerCurveRepository.DeletePowerCurveStation(PowerCurveDetailID);
                return (result, status);

                // return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.Message.ToString(), 401);
            }
        }

        public async Task<(string StatusMessage, int StatusCode)> OverridePowerCurveDraft(OverridePowerCurve overridePowerCurveData, int PowerCurveDetailID, HttpContext httpcontext)
        {

            try
            {

                string jsonData = JsonSerializer.Serialize(overridePowerCurveData);
                var (result, StatusCode) = await _powerCurveRepository.OverridePowerCurveDraft(jsonData, PowerCurveDetailID, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }



        public async Task<(string StatusMessage, int StatusCode)> UpdateUserPowerforPowerCurveStation(OverrideUserPower OverrideUserPower, int PowerCurveDetailID, HttpContext httpcontext)
        {
            try
            {
                string jsonData = JsonSerializer.Serialize(OverrideUserPower);
                var (result, StatusCode) = await _powerCurveRepository.UpdateUserPowerforPowerCurveStation(jsonData, PowerCurveDetailID, httpcontext);
                
                var powerCurveDetail = await _powerCurveDetailsRepository.GetById(PowerCurveDetailID).FirstOrDefaultAsync();

                // Access the powerCurveID property
                int? PowerCurveID = powerCurveDetail?.powerCurveID;
                if (PowerCurveID.HasValue )
                {
                    await callAzureHttpRequest(PowerCurveID.Value);
                }
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }



        public async Task<(string StatusMessage, int StatusCode)> PublishPowerCurve( int PowercurveID, HttpContext httpcontext)
        {
            try
            {
                  var (result, StatusCode) = await  _powerCurveRepository.PublishPowerCurve(PowercurveID,httpcontext);
                    return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }




        public async Task<(string StatusMessage, int StatusCode)> DuplicatePowerCurve(int PowercurveID, HttpContext httpcontext)
        {
            try
            {
                var (result, StatusCode) = await _powerCurveRepository.DuplicatePowerCurve(PowercurveID, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }



       private  async Task callAzureHttpRequest(int PowerCurveID)
        {
            _logger.LogInformation("Generate power curve db update success. starting http trigger...");
            HttpClient _httpClient = new HttpClient();
            string functionkey = _configuration["powercurvefunctionkey"] + "";
            _logger.LogInformation($"powercurvefunctionkey : {functionkey}");
            _teleclient.TrackEvent("PowerCurveService", new Dictionary<string, string> { { "powercurvefunctionkey", functionkey.ToString() } });
            _httpClient.DefaultRequestHeaders.Add("x-functions-key", functionkey);
            string functionUrl = _configuration["powercurvefunction"] + "";
            //HttpResponseMessage response = _httpClient.GetAsync($"https://func-bolt-dev-cac.azurewebsites.net/api/RefPowerCalculationHttpTrigger?PowerCurveID=" + PowerCurveID).Result;
            var response = await _httpClient.GetAsync(functionUrl + "?PowerCurveID=" + PowerCurveID);
            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                _logger.LogInformation("http trigger success: " + content);
            }
            else
            {
                // Handle the error response
                _logger.LogInformation($"http trigger Error: {response.StatusCode}");
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogInformation("http trigger Error details: " + errorContent);
            }

        }



    }


}