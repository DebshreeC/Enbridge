﻿using AutoMapper;
using BOLTAPIServices.DTO;
using BOLTAPIServices.Models;
using BOLTAPIServices.Models.DRA;
using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Models.PowerCurves;
using BOLTAPIServices.Repositories;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Settings;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System.Linq;
using System.Net;
using System.Text.Json;
using static System.Collections.Specialized.BitVector32;

namespace BOLTAPIServices.Services
{
    public class DRAService
    {
        private readonly IDRARepository _draRepository;
        private readonly ILogger<DRAService> _logger;
        private readonly IMapper _mapper;


        public DRAService(IDRARepository draRepository, IMapper mapper)
        {

            _draRepository = draRepository ?? throw new ArgumentNullException(nameof(draRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

        }
        public async Task<(string StatusMessage, int StatusCode)> CreateDRADraft(DraftDRA draftDRAdata, HttpContext httpcontext)
        {
            try
            {

                string jsonData = JsonSerializer.Serialize(draftDRAdata);
                var (result, StatusCode) = await _draRepository.CreateDRADraft(jsonData, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }
        public async Task<DRACostResponse> ViewDRACost()
        {
            try
            {
                var draCostDetails = await _draRepository.ViewDRACosts();
                var latestRecord = draCostDetails.Where(x => x.updatedDateTime != null).OrderByDescending(x => x.updatedDateTime).FirstOrDefault();
               
                DRACostResponse draCost = new DRACostResponse()
                {
                    meta = new DRACostMeta
                    {
                        // Use LINQ to get the latest (most recent) updatedDateTime
                        updatedByUserGUID = latestRecord?.updatedByUserGUID,
                        updatedByUserId = latestRecord?.updatedByUserId,
                        updatedByUserName = latestRecord?.updatedByUserName,
                        updatedDateTime = latestRecord?.updatedDateTime
                    },
                    data = draCostDetails.ToList()

                };
                var result = draCost;
                return await Task.FromResult(result);
            }

            catch (Exception ex)
            {
                return new DRACostResponse();
            }
        }
        public async Task<DRAfluidgroupResponse> ViewDRAfluidgroup()
        {
            try
            {                
                var draFluidgroupDetails = await _draRepository.ViewDRAfluidgroup();
                var latestRecord = draFluidgroupDetails.Where(x => x.updatedDateTime != null).OrderByDescending(x => x.updatedDateTime).FirstOrDefault();
                DRAfluidgroupResponse drafluidgroup = new DRAfluidgroupResponse()
                {
                    meta = new DRAfluidgroupMeta
                    {                        
                        // Use LINQ to get the latest (most recent) updatedDateTime
                        updatedByUserGUID = latestRecord?.updatedByUserGUID,
                        updatedByUserId = latestRecord?.updatedByUserId,
                        updatedByUserName = latestRecord?.updatedByUserName,
                        updatedDateTime = latestRecord?.updatedDateTime
                    },
                    data = draFluidgroupDetails.ToList()

                };

                var result = drafluidgroup;
                return await Task.FromResult(result);
            }     
       

            catch (Exception ex)
            {
                // _logger.LogError(GetType().Name, ex);
                return new DRAfluidgroupResponse();
            }
        }


        public async Task<IQueryable<DRADTO>> ViewDRAAsync()
        {
            try
            {
                // Fetch data from the repository
                var items = await _draRepository.ViewDRA(); 
                var itemsDto = _mapper.Map<IEnumerable<DRADTO>>(items).ToList();
                
                // Return IQueryable for OData query processing.
                return itemsDto.AsQueryable();
               
            }
            catch (Exception ex)
            {
              
                return Enumerable.Empty<DRADTO>().AsQueryable();
            }
        }

      




        /// <summary>
        /// Reterive the DRA summary and DRA Detail basedon DRASummaryID
        /// </summary>
        /// <returns></returns>
        public async Task<RootDRADetail> GetDRADetail(int DRASummaryID)
        {
            try
            {

                IEnumerable<ViewDRADetail> items = null;
                items = _draRepository.ViewDRADetailsAsync(DRASummaryID).Result;
            
                IEnumerable<DRASummary> meta = null;
                meta = _draRepository.GetByColumName("draSummaryID", DRASummaryID);

                RootDRADetail rootDRADetail = new RootDRADetail()
                {
                    meta = meta.FirstOrDefault(),   
                    data = items.ToList()

                };

                var result = rootDRADetail;
                return await Task.FromResult(result);
              
            }
            catch (Exception ex)
            {

                _logger.LogError(GetType().Name, ex);
                return new RootDRADetail();

            }

        }



        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> UpdateDRASummaryDraft(UpdateDRADraft draftDRAata, HttpContext httpcontext)
        {
            try
            {
                string jsonData = JsonSerializer.Serialize(draftDRAata);
                var (result, StatusCode) = await _draRepository.UpdateDRASummaryDraft(jsonData, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }

        public async Task<(string StatusMessage, int StatusCode)> UpdateDRADetailDraft(UpdateDRADetailDraft dRADetailDraft , int DRASummaryID, HttpContext httpcontext)
        {
            try
            {
                string jsonData = JsonSerializer.Serialize(dRADetailDraft);
                var (result, StatusCode) = await _draRepository.UpdateDRADetailDraft(jsonData, DRASummaryID, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


        public async Task<(string StatusMessage, int StatusCode)> UpdateFluidGroup(UpdateFluidGroupDraft FluidGroupDraft, string line, HttpContext httpcontext)
        {
            try
            {
                string jsonData = JsonSerializer.Serialize(FluidGroupDraft);
                var (result, StatusCode) = await _draRepository.UpdateFluidGroup(jsonData, line, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }




        public async Task<(string StatusMessage, int StatusCode)> UpdateDRACost(UpdateDRACostRequest dRACostRequest , HttpContext httpcontext)
        {
            try
            {
                string jsonData = JsonSerializer.Serialize(dRACostRequest);
                var (result, StatusCode) = await _draRepository.UpdateDRACost(jsonData, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


        public async Task<(string StatusMessage, int StatusCode)> DeleteDRA(int DRASummaryID)
        {
            try
            {
                var (result, status) = await _draRepository.DeleteDRA(DRASummaryID);
                return (result, status);
                // return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.Message.ToString(), 401);
            }
        }

        /// <summary>
        /// Method to  toggle the favourite the power curve based on DRASummaryID
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>
        public async Task<(string StatusMessage, int StatusCode)> MarkFavouriteAsync(int DRASummaryID)
        {
            var result = await _draRepository.MarkFavourite(DRASummaryID);
            return result;
        }


        public async Task<(string StatusMessage, int StatusCode)> ArchiveDRAAsync(int DRASummaryID,HttpContext httpcontext)
        {
            var result = await _draRepository.ArchiveDRA(DRASummaryID,httpcontext);
            return result;
        }

        public async Task<(string StatusMessage, int StatusCode)> DuplicateDRA(int DRASummaryID, HttpContext httpcontext)
        {
            try
            {
                var (result, StatusCode) = await _draRepository.DuplicateDRA(DRASummaryID, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


        public async Task<(string StatusMessage, int StatusCode)> PublishDRA(int DRASummaryID, HttpContext httpcontext)
        {
            try
            {
                var (result, StatusCode) = await _draRepository.PublishDRA(DRASummaryID, httpcontext);
                return (result, StatusCode);

            }
            catch (Exception ex)
            {
                _logger.LogError(GetType().Name, ex);
                return (ex.ToString(), 400);
            }
        }


    }

}
