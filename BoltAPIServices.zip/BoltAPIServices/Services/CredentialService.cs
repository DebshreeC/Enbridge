﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace BOLTAPIServices.Services
{
  

    public class CredentialService
    {
        private NetworkCredential _credentials;

        public void SetCredentials(string username, string password, string domain)
        {
            _credentials = new NetworkCredential(username, password, domain);
        }

        public NetworkCredential GetCredentials()
        {
            return _credentials;
        }
    }

}
