﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Linq.Dynamic.Core;
using System.Runtime.InteropServices;

namespace BOLTAPIServices.Repositories
{
    public abstract class FullRepository<T> : IFullRepository<T> where T : class
    {
        /// <summary>
        /// Service provider for dependency injection.
        /// </summary>
        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <inheritdoc/>
        public FullRepository(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        // do this for not having issues with disposing boltDbContext or calling multiple async methods
        //on the same dbcontext instance
        public BoltDbContext GetContext()
        {
            if (_context == null)
            {
                var scope = _serviceProvider.CreateScope();
                _context = scope.ServiceProvider.GetRequiredService<BoltDbContext>();
            }
            return _context;
        }
        /// <inheritdoc/>
        public virtual async Task<T> Create(T entity)
        {
            // add entity and return new entity
            // set return
            _context.Set<T>();
            await _context.SaveChangesAsync();
            return entity;
        }
        /// <inheritdoc/>
        public virtual async Task<bool> CreateAll(List<T> entities)
        {
            // add entity and return new entity
            // set return
            _context.Set<T>().AddRange(entities);
            return await _context.SaveChangesAsync() > 0;

        }
        /// <inheritdoc/>
        public virtual async Task<IEnumerable<T>> GetAll()
        {
            return await _context.Set<T>().ToListAsync();

        }
        /// <inheritdoc/>
        public virtual IQueryable<T?> GetById(int id)
        {
            // Get key using reflection
            var keyColumnName = this.GetKeyProperty(typeof(T));
            // Generate dynamic expression
            var expression = DynamicExpressionParser.ParseLambda(typeof(T), typeof(bool), $"{keyColumnName} == @0", id);
            return _context.Set<T>().Where(expression).OfType<T>();

        }
        /// <inheritdoc/>
        public virtual async Task<int> Update(Delta<T> entity, T currentEntity)
        {
            // find

            entity.Patch(currentEntity);
            _context.Set<T>().Update(currentEntity);
            return await _context.SaveChangesAsync();
        }
        /// <inheritdoc/>
        public virtual async Task<int> Remove(T entity)
        {

            return await _context.SaveChangesAsync();
        }
        /// <inheritdoc/>
        public virtual async Task<int> RemoveAll()
        {
            return await _context.Database.ExecuteSqlRawAsync("DELETE FROM bolt_stage.Ts");


        }
        /// <inheritdoc/>
        protected virtual string GetKeyProperty(Type entityType)
        {
            var props = entityType.GetProperties();
            foreach (var prop in props)
            {
                var attribute = Attribute.GetCustomAttribute(prop, typeof(KeyAttribute)) as KeyAttribute;

                if (attribute != null)
                {
                    return prop.Name;
                }
            }
            return "";
        }
    }
}

