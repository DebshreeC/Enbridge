﻿using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;

using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Data;

using System.Linq.Dynamic.Core;
using System.Text.Json;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace BOLTAPIServices.Repositories.FlowRates
{
    /// <inheritdoc/>>

    public class PublishedFlowRateRepository : FullRepository<PublishedFlowRate>, IPublishedFlowRateRepository
    {
        /// <summary>
        /// Service provider for dependency injection.
        /// </summary>

        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <inheritdoc/>
        public PublishedFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }

        public async Task<int> LoadPublishedFlowRateTrans(HttpContext httpContext)
        {
            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }

            var parameters = new[]
            {
                //this parameter is to be used for success of optimus data pull
                //should be set 0 if optimus pull fails
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
            };
            return await _context.Database.ExecuteSqlRawAsync(" execute [bolt_stage].[usp_PublishFlowRateTransactions] @username,@userid,@userguid", parameters);
        }
    }
}
