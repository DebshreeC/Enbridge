﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.FlowRates
{
    public class ViewHistorySummaryFlowRateRepository : ReadOnlyRepository<ViewHistorySummaryFlowRate>, IViewHistorySummaryFlowRateRepository
    {
        private IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <summary>
        /// Constructor for ViewMetaFlowRateRepository.
        /// </summary>
        public ViewHistorySummaryFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }


        /// <summary>
        /// Gets all flow rates.
        /// </summary>
        /// <returns>An enumerable of ViewMetaFlowRate.</returns>
        public IEnumerable<ViewHistorySummaryFlowRate> GetAll()
        {
            return _context.ViewHistorySummaryFlowRates?.ToList() ?? new List<ViewHistorySummaryFlowRate>();
        }

        public async Task<int> GetTotalRecordsAsync()
        {

            return await (_context.ViewHistorySummaryFlowRates?.CountAsync() ?? Task.FromResult(0));

        }

        /// <summary>
        /// Gets all flow rates.
        /// </summary>
        /// <returns>An enumerable of ViewMetaFlowRate.</returns>
        public IQueryable<ViewHistorySummaryFlowRate> GetPaginatedFlowRates(int pageNumber, int pageSize)
        {
            return _context.ViewHistorySummaryFlowRates?
                    .OrderBy(f => f.HistoryID) // Adjust the ordering as needed
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize) ?? Enumerable.Empty<ViewHistorySummaryFlowRate>().AsQueryable();

        }

    }
}
