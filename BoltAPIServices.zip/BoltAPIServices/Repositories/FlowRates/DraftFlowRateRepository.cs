﻿using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Text.Json;

namespace BOLTAPIServices.Repositories.FlowRates
{

    /// <inheritdoc/>>
    public class DraftFlowRateRepository : FullRepository<DraftFlowRate>, IDraftFlowRateRepository
    {
        private BoltDbContext _context;
        /// <summary>
        /// Service provider for dependency injection.
        /// </summary>
        /// <inheritdoc/>
        public DraftFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _context = GetContext();
        }

        /// <inheritdoc/>
        public async Task<int> UpsertData(string json, HttpContext httpContext)
        {

			httpContext.Items.TryGetValue("X-Username", out var username);
			httpContext.Items.TryGetValue("X-UserID", out var userID);
			httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

			// Ensure userGUID is of type Guid
			Guid userGuidValue = Guid.Empty;
			if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
			{
				userGuidValue = parsedGuid;
			}
		
		  var parameters = new[]
          {
                
                //input param to storedprocedure
                new SqlParameter("@DraftFlowRateData", SqlDbType.NVarChar) {Value=json },
				new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
				new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
				new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
			};
            return await _context.Database.ExecuteSqlRawAsync(" execute [bolt_stage].[UpsertDraftFlowRates]  @DraftFlowRateData,@username,@userid,@userguid", parameters);
        }

    }
}
