﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.FlowRates
{
    public class ViewCombinedFlowRateRepository : ReadOnlyRepository<ViewCombinedFlowRate>, IViewCombinedFlowRateRepository
    {

        /// <summary>
        /// Constructor for ViewCombinedFlowRateRepository.
        /// </summary>
        public ViewCombinedFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {

        }


    }
}
