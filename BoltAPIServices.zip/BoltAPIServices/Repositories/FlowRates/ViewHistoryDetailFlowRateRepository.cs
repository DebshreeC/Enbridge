﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Linq.Dynamic.Core;
using System.ComponentModel.DataAnnotations;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.FlowRates
{
    public class ViewHistoryDetailFlowRateRepository : ReadOnlyRepository<ViewHistoryDetailFlowRate>, IViewHistoryDetailFlowRateRepository
    {
        private IServiceProvider _serviceProvider;
        private BoltDbContext _context;

        /// <summary>
        /// Constructor for ViewCombinedFlowRateRepository.
        /// </summary>
        public ViewHistoryDetailFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();

        }

    }
}
