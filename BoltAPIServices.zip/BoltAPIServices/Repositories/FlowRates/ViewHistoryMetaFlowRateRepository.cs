﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.FlowRates
{
    public class ViewHistoryMetaFlowRateRepository : ReadOnlyRepository<ViewHistoryMetaFlowRate>, IViewHistoryMetaFlowRateRepository
    {
        private IServiceProvider _serviceProvider;
        private BoltDbContext _context;

        /// <summary>
        /// Constructor for ViewMetaFlowRateRepository.
        /// </summary>
        public ViewHistoryMetaFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }

        /// <summary>
        /// Gets all flow rates.
        /// </summary>
        /// <returns>An enumerable of ViewMetaFlowRate.</returns>
        public IEnumerable<ViewHistoryMetaFlowRate> GetAll()
        {

            return _context.ViewHistoryMetaFlowRates.ToList();

        }


    }
}
