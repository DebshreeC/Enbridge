﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.FlowRates
{
    public class ViewMetaFlowRateRepository : ReadOnlyRepository<ViewMetaFlowRate>, IViewMetaFlowRateRepository
    {
        private IServiceProvider _serviceProvider;
        private BoltDbContext _context;

        /// <summary>
        /// Constructor for ViewMetaFlowRateRepository.
        /// </summary>
        public ViewMetaFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }

        /// <summary>
        /// Gets all flow rates.
        /// </summary>
        /// <returns>An enumerable of ViewMetaFlowRate.</returns>
        public IEnumerable<ViewMetaFlowRate> GetAll()
        {

            return _context.ViewMetaFlowRates.ToList();

        }

        /// <summary>
        /// Gets a flow rate by ID.
        /// </summary>
        /// <param name="id">The ID of the flow rate.</param>
        /// <returns>An IQueryable of ViewMetaFlowRate.</returns>
        public IQueryable<ViewMetaFlowRate?> GetById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
