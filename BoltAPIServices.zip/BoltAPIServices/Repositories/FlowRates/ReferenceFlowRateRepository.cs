﻿using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Text.Json;

namespace BOLTAPIServices.Repositories.FlowRates
{
    /// <inheritdoc/>>


    public class ReferenceFlowRateRepository : FullRepository<ReferenceFlowRate>, IReferenceFlowRateRepository


    {
        /// <summary>
        /// Service provider for dependency injection.
        /// </summary>

        private BoltDbContext _context;
        /// <inheritdoc/>
        public ReferenceFlowRateRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _context = GetContext();
        }


        /// <inheritdoc/>
        public async Task<int> LoadReferenceFlowRateTrans(string json, bool bsuccessfulpull, int refVal)
        {
            var parameters = new[]
               {
                //this parameter is to be used for success of optimus data pull
                //should be set 0 if optimus pull fails
                new SqlParameter("@OptimusUpdateSuccessFlag", SqlDbType.Bit) {Value=bsuccessfulpull },
                new SqlParameter("@ReferenceFlowRateData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@Ref", SqlDbType.Bit) {Value=refVal }
            };

            return await _context.Database.ExecuteSqlRawAsync(" execute [bolt_stage].[usp_ReferenceFlowRateLoadTransactions] @OptimusUpdateSuccessFlag, @ReferenceFlowRateData,@Ref", parameters);


        }

    }
}
