﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using static System.Collections.Specialized.BitVector32;
using System.Net;
using BOLTAPIServices.Models.DRA;
using System;
using System.Drawing.Printing;

namespace BOLTAPIServices.Repositories
{/// <inheritdoc/>
    public class DRARepository : ReadOnlyRepository<DRASummary>, IDRARepository
    {
        /// <summary>
        /// Constructor for  DRA Repository.
        /// </summary>
        /// 
        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <inheritdoc/>
        public DRARepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }
       /// <inheritdoc/>
        public async Task<List<DRA_Cost>> ViewDRACosts()
        {
            var pcdRecords = await _context.DRA_Cost.ToListAsync();
            if (!pcdRecords.Any())
            {
                throw new KeyNotFoundException("No DRA Cost found.");
            }
            return pcdRecords;
        }
       
        /// <inheritdoc/>
        public async Task<List<DRA_fluidgroup>> ViewDRAfluidgroup()
        {

            var pcdRecords = await (
    from dra in _context.DRA_fluidgroup
    join lineRef in
        (from lineStation in _context.LineStationReferences
         select new
         {
             Line = lineStation.Line.Trim(),  // Normalize Line
             Region = lineStation.Region.Trim(),  // Normalize Region
             LineOrder = lineStation.LineOrder,
             RegionOrder = lineStation.RegionOrder
         }).Distinct()
        on new { Line = dra.line.Trim(), Region = dra.region.Trim() }
        equals new { Line = lineRef.Line, Region = lineRef.Region }
    orderby lineRef.RegionOrder, lineRef.LineOrder, dra.fluidGroup
    select dra  // Return the full DRA_fluidgroup entity
).ToListAsync();

            if (!pcdRecords.Any())
            {
                throw new KeyNotFoundException("No DRA Fluid Group found.");
            }
            return pcdRecords;
        }
        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> CreateDRADraft(string json, HttpContext httpContext)
        {
            try
            {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                {
                new SqlParameter("@DraftDRAData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_CreateDRADraft] @DraftDRAData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed

        }

        public async Task<IEnumerable<DRASummary>> ViewDRA()
        {


            var pcdrecords = _context.DRASummary.AsEnumerable()
                .OrderBy(i => i.regionOrder)
                .ThenBy(i => i.lineOrder)
                .ToList();
            if (!pcdrecords.Any())
            {
                throw new KeyNotFoundException("No DRA found.");
            }
            return pcdrecords;
        }
        /// <inheritdoc/>
      

        public async Task<IEnumerable<ViewDRADetail>> ViewDRADetailsAsync(int DRASummaryID)
        {

            var draRecords = await _context.ViewDRADetails
      .Where(d => d.draSummaryID == DRASummaryID &&
                  _context.LineStationReferences
                      .Any(l => l.Station == d.station && l.Line == d.line))  // Ensure matching station and line
      .OrderBy(d => _context.LineStationReferences
                      .Where(l => l.Station == d.station && l.Line == d.line)
                      .Select(l => l.RegionOrder)
                      .FirstOrDefault())
      .ThenBy(d => _context.LineStationReferences
                      .Where(l => l.Station == d.station && l.Line == d.line)
                      .Select(l => l.LineOrder)
                      .FirstOrDefault())
      .ThenBy(d => _context.LineStationReferences
                      .Where(l => l.Station == d.station && l.Line == d.line)
                      .Select(l => l.StationOrder)
                      .FirstOrDefault())
      .ToListAsync();



            if (!draRecords.Any())
            {
                throw new KeyNotFoundException("No DRA details found with the specified summary ID.");
            }
            else
            {
                return (IEnumerable<ViewDRADetail>)draRecords;
            }
        }

        public async Task<(string StatusMessage, int StatusCode)> UpdateDRASummaryDraft(string json, HttpContext httpContext)
        {
            try
            {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {

                new SqlParameter("@DraftDRAData", SqlDbType.NVarChar) {Value=json },
               new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
               // new SqlParameter("@DRASummaryID",SqlDbType.Int){Value=DRASummaryID},
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdateDRASummaryDraft] @DraftDRAData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed
        }
        public async Task<(string StatusMessage, int StatusCode)> UpdateDRADetailDraft(string json, int DRASummaryID, HttpContext httpContext)
        {
            try
            {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@DraftDRAData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@DRASummaryID",SqlDbType.Int){Value=DRASummaryID},
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdateDRADetail] @DraftDRAData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@DRASummaryID,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed
        }




        public async Task<(string StatusMessage, int StatusCode)> DeleteDRA(int DRASummaryID)
        {
        //    if ((_context == null) | (_context?. == null))
        //        return ("DRA data not initialized.", 400);

            var parameters = new[]
                {
                new SqlParameter("@DRASummaryID", SqlDbType.Int) {Value = DRASummaryID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },

                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_DeleteDRA] @DRASummaryID, @StatusMessage OUTPUT, @StatusCode OUTPUT",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;

            return (statusMessage, StatusCode);

        }

        public async Task<(string StatusMessage, int StatusCode)> MarkFavourite(int DRASummaryID)
        {
            var parameters = new[]
               {
                new SqlParameter("@DRASummaryID", SqlDbType.Int) {Value = DRASummaryID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },

                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_MarkFavouriteDRA] @DRASummaryID, @StatusMessage OUTPUT, @StatusCode OUTPUT",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;

            return (statusMessage, StatusCode);

        }



        public async Task<(string StatusMessage, int StatusCode)> ArchiveDRA(int DRASummaryID , HttpContext httpContext)
        {
            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }
            var parameters = new[]
               {
                new SqlParameter("@DRASummaryID", SqlDbType.Int) {Value = DRASummaryID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                 new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }

                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_ArchiveDRA] @DRASummaryID, @StatusMessage OUTPUT, @StatusCode OUTPUT, @username, @userid, @userguid",
                    parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;

            return (statusMessage, StatusCode);

        }

        public async Task<(string StatusMessage, int StatusCode)> DuplicateDRA(int DRASummaryID, HttpContext httpContext)
        {
            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }

            var parameters = new[]
            {
                new SqlParameter("@DRASummaryID", SqlDbType.Int) {Value = DRASummaryID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_DuplicateDRAData] @DRASummaryID, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;
            return (statusMessage, StatusCode);

        }

        public async Task<(string StatusMessage, int StatusCode)> UpdateFluidGroup(string json, string line, HttpContext httpContext)
        { 
            try
            {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@DraftFluidGroupData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@line",SqlDbType.VarChar){Value=line},
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdateFluidGroup] @DraftFluidGroupData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@line,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed
        }



        public async Task<(string StatusMessage, int StatusCode)> UpdateDRACost(string json, HttpContext httpContext)
        {
            try
            {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@DraftDRACostData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdateDRACost] @DraftDRACostData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed
        }


        public async Task<(string StatusMessage, int StatusCode)> PublishDRA(int DRASummaryID, HttpContext httpContext)
        {
           
            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }

            var parameters = new[]
            {
                new SqlParameter("@DRASummaryID", SqlDbType.Int) {Value = DRASummaryID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_PublishDRA] @DRASummaryID, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;
            return (statusMessage, StatusCode);

        }






    }
}
