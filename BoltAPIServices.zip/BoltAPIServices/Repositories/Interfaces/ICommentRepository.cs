﻿using BOLTAPIServices.Models;
using System.Net;

namespace BOLTAPIServices.Repositories.Interfaces
{
    public interface ICommentRepository
    {

        Task<HttpStatusCode> AddComment(CommentInput commentInput, HttpContext httpContext);

        Task<IEnumerable<Comments>> ViewComment(string reference, int refId);
    }
}
