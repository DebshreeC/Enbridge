﻿using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    /// <summary>
    /// Interface for flowrates data from bolt_stage.ViewCombinedFlowRates
    /// </summary>
    public interface IViewHistoryDetailFlowRateRepository : IReadOnlyRepository<ViewHistoryDetailFlowRate>
    {
    }
}
