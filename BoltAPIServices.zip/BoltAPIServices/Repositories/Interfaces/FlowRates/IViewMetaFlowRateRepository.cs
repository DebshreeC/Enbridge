﻿using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    /// <summary>
    /// Interface for flowrates data from bolt_stage.ViewMetaFlowRates
    /// </summary>
    public interface IViewMetaFlowRateRepository : IReadOnlyRepository<ViewMetaFlowRate>
    {
    }
}
