﻿using BOLTAPIServices.Models.FlowRates;
using Microsoft.AspNetCore.OData.Deltas;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    /// <summary>
    /// Allow all operations on a repository
    /// </summary>

    public interface IReferenceFlowRateRepository : IFullRepository<ReferenceFlowRate>
    {
        Task<int> LoadReferenceFlowRateTrans(string json, bool bsuccessfulpull, int refVal);
    }
}


