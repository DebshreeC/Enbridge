﻿using BOLTAPIServices.Models.FlowRates;
using Microsoft.AspNetCore.OData.Deltas;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    /// <summary>
    /// Allow all operations on a repository
    /// </summary>
    public interface IDraftFlowRateRepository : IFullRepository<DraftFlowRate>
    {
    }
}
