﻿using BOLTAPIServices.Models.FlowRates;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    /// <summary>
    /// Interface for flowrates data from bolt_stage.ViewCombinedFlowRates
    /// </summary>
    public interface IViewHistorySummaryFlowRateRepository : IReadOnlyRepository<ViewHistorySummaryFlowRate>
    {
        /// <summary>
        /// query record by page
        /// <summary>
        public IQueryable<ViewHistorySummaryFlowRate> GetPaginatedFlowRates(int pageNumber, int pageSize);

        /// <summary>
        /// count of total record
        /// <summary>
        public Task<int> GetTotalRecordsAsync();
    }
}
