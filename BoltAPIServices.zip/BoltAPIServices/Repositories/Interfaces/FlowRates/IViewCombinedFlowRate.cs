﻿using BOLTAPIServices.Repositories.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace BOLTAPIServices.Repositories.Interfaces.FlowRates
{
    // model for flowrates data from bolt_stage.ViewCombinedFlowRates
    public interface IViewCombinedFlowRate
    {

        public long Id { get; set; }
        public string Region { get; set; }

        public string Line { get; set; }

        public int? RefFlowRatem3hr { get; set; }


        public int? DraftFlowRatem3hr { get; set; }


        public int? PublishedFlowRatem3hr { get; set; }

    }
}
