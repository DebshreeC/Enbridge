﻿namespace BOLTAPIServices.Repositories.Interfaces
{
    /// <summary>
    /// Allow only read operations on a repository
    /// </summary>
    public interface IReadOnlyRepository<T>  where T : class
    {
        /// <summary>
        /// Get all entities
        /// </summary>
        /// <returns>List of entities</returns>
        IEnumerable<T> GetAll();
        /// <summary>
        /// Get entity by id
        /// </summary>
        /// <param name="id">Entity Id</param>
        /// <returns>single entity</returns>
       IQueryable<T?> GetById(int id);
      IEnumerable<T>  GetByColumName(string columnName, object value);


    }
}
