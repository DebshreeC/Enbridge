﻿using BOLTAPIServices.Models.PowerCurves;

namespace BOLTAPIServices.Repositories.Interfaces.PowerCurves
{
    /// <summary>
    /// Interface for PowerCurve data from bolt_stage.ViewPowerCurve
    /// </summary>
    public interface IViewPowerCurveRegionRepository : IReadOnlyRepository<ViewPowerCurveRegion>
    {

    }
}
