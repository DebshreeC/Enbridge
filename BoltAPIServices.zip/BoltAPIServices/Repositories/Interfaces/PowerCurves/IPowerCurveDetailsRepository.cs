﻿using BOLTAPIServices.Models;
using BOLTAPIServices.Models.PowerCurves;

namespace BOLTAPIServices.Repositories.Interfaces.PowerCurves
{
    /// <summary>
    /// Interface for PowerCurveDetails data from bolt_stage.ViewPowerCurve
    /// </summary>
    public interface IPowerCurveDetailsRepository : IReadOnlyRepository<PowerCurveDetails>
    {

    }
}
