﻿using BOLTAPIServices.Repositories.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace BOLTAPIServices.Interfaces
{
    // model for flowrates data from bolt_stage.ViewHistoryDetailFlowRates
    public interface IViewHistorySummaryFlowRate 
    {

      
        public string? HistoryId { get; set; }


        public DateTime? ccoUpdatedDateTime { get; set; }
        public DateTime? userFlowRateUpdateDateTime { get; set; }
        public Guid updateByUserGUID { get; set; }
        public string? updateByUserId { get; set; }
        public string? updateByUsername { get; set; }



    }
}
