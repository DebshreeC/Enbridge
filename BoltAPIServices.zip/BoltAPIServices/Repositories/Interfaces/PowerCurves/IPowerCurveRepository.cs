﻿using BOLTAPIServices.Models;

namespace BOLTAPIServices.Repositories.Interfaces
{
    /// <summary>
    /// Interface for PowerCurve data from bolt_stage.ViewPowerCurve
    /// </summary>
    public interface IPowerCurveRepository : IReadOnlyRepository<PowerCurve>
    {

        //public async Task<PowerCurve> MarkFavourite(int id);
        Task<PowerCurve> MarkFavourite(int powerCurveID);
        Task<(string StatusMessage, int StatusCode)> GeneratePowerCurve(int PowerCurveID);

        Task<(string StatusMessage, int StatusCode)> LoadDraftPowerCurveTrans(string json, HttpContext httpcontext);
        Task<(string StatusMessage, int StatusCode)> StationPowerCurveDraft(string json, int PowerCurveID, HttpContext httpcontext);

        Task<(string StatusMessage, int StatusCode)> UpdatePowerCurveDraft(string json, int PowerCurveID, HttpContext httpcontext);
        Task<(string StatusMessage, int StatusCode)> DeletePowerCurveStation(int PowerCurveDetailID);
        Task<(string StatusMessage, int StatusCode)> UpdateStationforPowerCurveDraft(string json, int PowerCurveID, HttpContext httpcontext);

        Task<IEnumerable<ViewPowerCurveDetail>> ViewPowerCurveDetailsAsync(int PowerCurveID);

        Task<(string StatusMessage, int StatusCode)> OverridePowerCurveDraft(string json, int PowerCurveDetailID, HttpContext httpcontext);

        Task<(string StatusMessage, int StatusCode)> UpdateUserPowerforPowerCurveStation(string json, int PowerCurveDetailID, HttpContext httpContext);

        Task<(string StatusMessage, int StatusCode)> DeletePowerCurve(int PowerCurveID);


        Task<(string StatusMessage, int StatusCode)> PublishPowerCurve(int PowercurveID, HttpContext httpContext);


        Task<(string StatusMessage, int StatusCode)> DuplicatePowerCurve(int PowercurveID, HttpContext httpContext);

        Task<IEnumerable<PowerCurveDetails>> GetPowerCurveDtl(int PowerCurveID, string Station);


    }
        
}
