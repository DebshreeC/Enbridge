﻿using BOLTAPIServices.Models;

namespace BOLTAPIServices.Repositories.Interfaces
{
    /// <summary>
    /// Interface for flowrates data from bolt_stage.LineStationReferences
    /// </summary>
    public interface ILineStationReferenceRepository: IReadOnlyRepository<LineStationReference>
    {
    }
}
