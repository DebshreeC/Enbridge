﻿using Microsoft.AspNetCore.OData.Deltas;

namespace BOLTAPIServices.Repositories.Interfaces
{
    /// <summary>
    /// Allow all operations on a repository
    /// </summary>
    public interface IFullRepository<T> where T : class
    {
        /// <summary>
        /// Get all entities
        /// </summary>
        /// <returns>List of entities</returns>
        Task<IEnumerable<T>> GetAll();
        /// <summary>
        /// Get entity by id
        /// </summary>
        /// <param name="id">Entity Id</param>
        /// <returns>single entity</returns>
        IQueryable<T?> GetById(int id);
        /// <summary>
        /// Create new entity
        /// </summary>
        /// <param name="entity">new entity to save</param>
        /// <returns>The number of state entries written to the database</returns>

        Task<T> Create(T entity);

        /// <summary>
        /// Create new entities
        /// </summary>
        /// <param name="entities">new entities to save</param>
        /// <returns>The number of state entries written to the database</returns>
        Task<bool> CreateAll(List<T> entities);
        /// <summary>
        /// Updates entity
        /// </summary>
        /// <param name="entity">Entity to update</param>
        /// <param name="currentEntity">Changes to entity</param>
        /// <returns>new entity</returns>
        Task<int> Update(Delta<T> entity, T currentEntity);
        /// <summary>
        /// Delete entity
        /// </summary>
        /// <param name="json"></param>
       /// <returns>success of operations with more number of rows</returns>
      /// <returns>success of operations with more number of rows</returns>
        /// Delete all rows
        /// </summary>
        Task<int> Remove(T entity);
    }
}
