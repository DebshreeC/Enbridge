﻿using BOLTAPIServices.Models;
using BOLTAPIServices.Models.DRA;
using System.Net;

namespace BOLTAPIServices.Repositories.Interfaces
{
    /// <summary>
    /// Interface for DRA data from bolt_stage.DRA
    /// </summary>
    public interface IDRARepository : IReadOnlyRepository<DRASummary>
    {

        Task<(string StatusMessage, int StatusCode)> CreateDRADraft(string json, HttpContext httpContext);
        Task<(string StatusMessage, int StatusCode)> UpdateDRASummaryDraft(string json, HttpContext httpContext);
        Task<(string StatusMessage, int StatusCode)> UpdateDRADetailDraft(string json, int DRASummaryID, HttpContext httpContext);
        Task<List<DRA_Cost>> ViewDRACosts();        
        Task<List<DRA_fluidgroup>> ViewDRAfluidgroup();
       // Task<IEnumerable<DRASummary>> ViewDRA(string status, int pageNumber);
        Task<IEnumerable<ViewDRADetail>> ViewDRADetailsAsync(int DRASummaryID);
        Task<IEnumerable<DRASummary>> ViewDRA();
        Task<(string StatusMessage, int StatusCode)> DeleteDRA(int DRASummaryID);
        Task<(string StatusMessage, int StatusCode)> MarkFavourite(int DRASummaryID);
        Task<(string StatusMessage, int StatusCode)> DuplicateDRA(int DRASummaryID, HttpContext httpContext);
        Task<(string StatusMessage, int StatusCode)> UpdateFluidGroup(string json, string line, HttpContext httpContext);

        Task<(string StatusMessage, int StatusCode)> ArchiveDRA(int DRASummaryID  ,HttpContext httpContext);
        Task<(string StatusMessage, int StatusCode)> PublishDRA(int DRASummaryID, HttpContext httpContext);
        Task<(string StatusMessage, int StatusCode)> UpdateDRACost(string json, HttpContext httpContext);


    }
}
