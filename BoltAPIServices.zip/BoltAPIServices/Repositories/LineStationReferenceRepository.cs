﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;

namespace BOLTAPIServices.Repositories
{
    public class LineStationReferenceRepository : ReadOnlyRepository<LineStationReference>, ILineStationReferenceRepository
    {
        private IServiceProvider _serviceProvider;

        /// <summary>
        /// Constructor for LineStationReferenceRepository.
        /// </summary>
        public LineStationReferenceRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        /// <summary>
        /// Gets all flow rates.
        /// </summary>
        /// <returns>An enumerable of ViewCombinedFlowRate.</returns>
        public IEnumerable<LineStationReference> GetAll()
        {
           
            using (var scope = _serviceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<BoltDbContext>();
                return context.LineStationReferences.ToList();
                
            }
        }
    }
}
