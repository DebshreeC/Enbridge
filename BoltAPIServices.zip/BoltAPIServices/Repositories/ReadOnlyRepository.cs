﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System.ComponentModel.DataAnnotations;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Text.Json;

namespace BOLTAPIServices.Repositories
{
    /// <inheritdoc/>>
    public abstract class ReadOnlyRepository<T> : IReadOnlyRepository<T> where T : class // Add 'where T : class'
    {
        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;

        /// <inheritdoc/>
        public ReadOnlyRepository(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();
        }

        // do this for not having issues with disposing boltDbContext or calling multiple async methods
        //on the same dbcontext instance
        public BoltDbContext GetContext()
        {
            if (_context == null)
            {
                var scope = _serviceProvider.CreateScope();
                _context = scope.ServiceProvider.GetRequiredService<BoltDbContext>();
            }
            return _context;
        }

        /// <inheritdoc/>
        public virtual IEnumerable<T> GetAll()
        {
           return _context.Set<T>().ToList();
        }

        /// <inheritdoc/>
        public IQueryable<T?> GetById(int id)
        {
            // Get key using reflection
            var keyColumnName = this.GetKeyProperty(typeof(T));
            // Generate dynamic expression
            var expression = DynamicExpressionParser.ParseLambda(typeof(T), typeof(bool), $"{keyColumnName} == @0", id);
            return _context.Set<T>().Where(expression).OfType<T>();
        }

        /// <inheritdoc/>
        protected string GetKeyProperty(Type entityType)
        {
            var props = entityType.GetProperties();
            foreach (var prop in props)
            {
                var attribute = Attribute.GetCustomAttribute(prop, typeof(KeyAttribute)) as KeyAttribute;

                if (attribute != null)
                {
                    return prop.Name;
                }
            }
            return "";
        }

        public IEnumerable<T> GetByColumName(string columnName, object value)
        {
            // Create a parameter expression for the type T
            var parameter = Expression.Parameter(typeof(T), "x");

            // Create an expression for the property based on the column name
            var property = Expression.Property(parameter, columnName);

            // Handle nullable types
            var propertyType = property.Type;
            var constant = Expression.Constant(value, propertyType); // Create constant with the property type

            // Create an expression to compare the property value with the input value
            var equals = Expression.Equal(property, constant);

            // Create a lambda expression from the comparison
            var lambda = Expression.Lambda<Func<T, bool>>(equals, parameter);

            // Query the database using the dynamically created expression
            var items = _context.Set<T>().Where(lambda).AsEnumerable().ToList();
            return items;
        }
    }
}

