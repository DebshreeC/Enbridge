﻿using Azure.Identity;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Models.PowerCurves;
using BOLTAPIServices.Models.DRA;


namespace BOLTAPIServices.Repositories.Contexts
{// db context for flowrates
    public class BoltDbContext : DbContext
    {
        /// <summary>
        /// Constructor initialized with MI and token based auth
        /// </summary>
        /// <param name="options"></param>
        /// <param name="config"></param>
        public BoltDbContext(DbContextOptions<BoltDbContext> options, IConfiguration config) : base(options)
        {
            var connection = (Microsoft.Data.SqlClient.SqlConnection)Database.GetDbConnection();
            var credential = new DefaultAzureCredential();
            var token = credential
                    .GetToken(new Azure.Core.TokenRequestContext(
                        new[] { "https://database.windows.net/.default" }));


           if  (config["RunMode"]!= "local")
            connection.AccessToken = token.Token;



        }
        /// <inheritdoc/>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ViewHistoryDetailFlowRate>()
                .HasNoKey()
                .ToView("ViewHistoryDetailFlowRates", "bolt_stage");


            modelBuilder.Entity<HistoricalDateRange>().HasNoKey();


           modelBuilder.Entity<PowerCurveDetails>()
          .HasMany(pcd => pcd.PowerCurveStationDetails)
          .WithOne()
          .HasForeignKey(pcsd => pcsd.powerCurveDetailID);
        }


        // public virtual DbSet<DailyPowerPiAvg> DailyPowerPiAvgs { get; set; }

        // public virtual DbSet<DraftFlowRate> DraftFlowRates { get; set; }

        // public virtual DbSet<FlowRatesDetail> FlowRatesDetails { get; set; }


        //public virtual DbSet<HistPowerUsage> HistPowerUsages { get; set; }


        public virtual DbSet<LineStationReference> LineStationReferences { get; set; }

        public virtual DbSet<PublishedFlowRate> PublishedFlowRates { get; set; }

        public virtual DbSet<ReferenceFlowRate> ReferenceFlowRates { get; set; }

        //public virtual DbSet<ReferenceTable> ReferenceTables { get; set; }

        //public virtual DbSet<SourceNfr> SourceNfrs { get; set; }

        //public virtual DbSet<ViewCombinedFlowRate> ViewCombinedFlowRates { get; set; }
        public DbSet<ViewCombinedFlowRate>? ViewCombinedFlowRates { get; set; }
        public DbSet<ViewHistoryDetailFlowRate>? ViewHistoryDetailFlowRates { get; set; }
        public DbSet<ViewHistorySummaryFlowRate>? ViewHistorySummaryFlowRates { get; set; }


        public DbSet<ViewPowerCurveRegion>? ViewPowerCurves { get; set; }
        public DbSet<ViewPowerCurveDetail>? ViewPowerCurveDetails { get; set; }

        public DbSet<PowerCurve>? PowerCurves { get; set; }
        public DbSet<PowerCurveDetails>? PowerCurveDetails { get; set; }
        public DbSet<PowerCurveStationDetails>? PowerCurveStationDetails { get; set; }
        public DbSet<Comments> Comments { get; set; }
        public DbSet<ViewMetaFlowRate>? ViewMetaFlowRates { get; set; }
        public DbSet<ViewHistoryMetaFlowRate>? ViewHistoryMetaFlowRates { get; set; }
        public DbSet<HistoricalDateRange> HistoricalDateRanges { get; set; }
        public DbSet<DRA_Cost> DRA_Cost { get; set; }
        public DbSet<DRA_fluidgroup> DRA_fluidgroup { get; set; }
        public DbSet<DRASummary> DRASummary { get; set; }
        public DbSet<ViewDRADetail> ViewDRADetails { get; set; }    
    }
}
