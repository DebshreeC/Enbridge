﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using BOLTAPIServices.Models.PowerCurves;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace BOLTAPIServices.Repositories
{   /// <inheritdoc/>
    public class PowerCurveRepository : ReadOnlyRepository<PowerCurve>, IPowerCurveRepository
    {

        /// <summary>
        /// Constructor for  Power curve Repository.
        /// </summary>
        /// 
        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <inheritdoc/>
        public PowerCurveRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();

        }
        /// <inheritdoc/>
        public async Task<PowerCurve> MarkFavourite(int id)
        {
            var item = await _context.PowerCurves.FindAsync(id);
            if (item == null)
            {
                throw new KeyNotFoundException("Power curve not found.");

            }

            if (item.status.ToUpper() == "PUBLISHED")
            {
                item.isFavourite = !item.isFavourite; // Toggle the boolean field
                await _context.SaveChangesAsync(); // Save changes to the database
                return item; // Return the updated feature

            }
            else
            {
                throw new KeyNotFoundException("Power curve is not in published status.");

            }


        }


        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> LoadDraftPowerCurveTrans(string json, HttpContext httpContext)
        {
            try
            {

                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {

                new SqlParameter("@DraftPowerCurveData", SqlDbType.NVarChar) {Value=json },
               new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
};

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_DraftPowerCurveLoadTransactions] @DraftPowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[1].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[2].Value;

                return (statusMessage, StatusCode);
            }
            catch (Exception ex)
            {
                return (ex.ToString(), 400);
            }

            // Return results as needed

        }
        /// <inheritdoc/>



        public async Task<(string StatusMessage, int StatusCode)> UpdatePowerCurveDraft(string json, int PowerCurveID, HttpContext httpContext)
        {
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@PowerCurveID", SqlDbType.Int) {Value = PowerCurveID},
                new SqlParameter("@DraftPowerCurveData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                   };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdatePowerCurveDraft] @PowerCurveID, @DraftPowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[2].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[3].Value;

                return (statusMessage, StatusCode);
           
        }
        /// <inheritdoc/>


        public async Task<(string StatusMessage, int StatusCode)> UpdateStationforPowerCurveDraft(string json, int PowerCurveDetailID, HttpContext httpContext)
        {
            
                if ((_context == null) | (_context?.PowerCurveDetails == null))
                    return ("Power curve data not initialized.", 400);

                var item = await _context.PowerCurveDetails.FindAsync(PowerCurveDetailID);
                if (item == null)
                {
                    return ("Power curve Detail not found.", 400);
                }

                else
                {
                    int PowerCurveID = item.powerCurveID;

                    var PowerCurveResult = await _context.PowerCurves.FindAsync(PowerCurveID);
                    if (PowerCurveResult != null)
                    {
                        if (PowerCurveResult.status.ToUpper() == "DRAFT")
                        {

                            httpContext.Items.TryGetValue("X-Username", out var username);
                            httpContext.Items.TryGetValue("X-UserID", out var userID);
                            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                            // Ensure userGUID is of type Guid
                            Guid userGuidValue = Guid.Empty;
                            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                            {
                                userGuidValue = parsedGuid;
                            }

                            var parameters = new[]
                           {
                                new SqlParameter("@PowerCurveDetailID", SqlDbType.Int) {Value = PowerCurveDetailID},
                                new SqlParameter("@DraftPowerCurveData", SqlDbType.NVarChar) {Value=json },
                                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                           };

                            // Execute the stored procedure
                            await _context.Database.ExecuteSqlRawAsync(
                                "EXEC [bolt_stage].[usp_UpdateStationPowerCurveDraft] @PowerCurveDetailID, @DraftPowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                                parameters);

                            // Retrieve the output values
                            var statusMessage = parameters[2].Value.ToString();
                            int StatusCode = (int)parameters[3].Value;

                            return (statusMessage, StatusCode);
                        }
                        else
                        {
                            return ("Power Curve not in Draft status", 401);
                        }
                    }
                    else
                    {
                        return ("Power Curve not found", 400);
                    }
                }
           
        }



        public async Task<(string StatusMessage, int StatusCode)> GeneratePowerCurve(int id)
        {
            
                var item = await _context.PowerCurves.FindAsync(id);
                if (item == null)
                {
                    throw new KeyNotFoundException("Power curve not found.");
                }

                if (item.status == "Draft" || item.status=="DRAFT")
                {
                    // Retrieve all records with the specified PowerCurveID
                    var pcdRecords = await _context.PowerCurveDetails
                        .Where(p => p.powerCurveID == item.powerCurveID && (p.status == "Draft" || p.status=="DRAFT"))
                        .ToListAsync();

                    if (!pcdRecords.Any())
                    {
                        throw new KeyNotFoundException("No power curve details found with the specified ID and status.");
                    }

                    // Update the status for each record
                    foreach (var pcd in pcdRecords)
                    {
                        pcd.status = "NEW";
                    }

                    // Save changes to the database
                    await _context.SaveChangesAsync();
                    return ("Generate option updated successfully", 200); // Return the updated feature

            }
                else
                {
                return ("PowerCurve is not in Draft status",400); // Return the updated feature
                 }
          

          

        }



        public async Task<(string StatusMessage, int StatusCode)> StationPowerCurveDraft(string json, int PowerCurveID, HttpContext httpContext)
        {
            

                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@PowerCurveID", SqlDbType.Int) {Value = PowerCurveID},
                new SqlParameter("@DraftPowerCurveData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }

                   };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_AddStationPowerCurveDraft] @PowerCurveID, @DraftPowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[2].Value.ToString() ?? string.Empty;
                int StatusCode = (int)parameters[3].Value;

                return (statusMessage, StatusCode);
           
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<ViewPowerCurveDetail>> ViewPowerCurveDetailsAsync(int PowerCurveID)
        {

            var pcdRecords = await _context.ViewPowerCurveDetails
                       .Where(p => p.PowerCurveID == PowerCurveID)
                       .ToListAsync();

            if (!pcdRecords.Any())
            {
                throw new KeyNotFoundException("No power curve details found with the specified ID and status.");
            }
            else
            {
                return pcdRecords;
            }

        }


        public async Task<IEnumerable<PowerCurveDetails>> GetPowerCurveDtl(int PowerCurveID, string? Station)
        {
            var pcdRecords = await _context.PowerCurveDetails
                .Where(p => p.powerCurveID == PowerCurveID &&
                            (string.IsNullOrEmpty(Station) || p.station == Station) &&
                            _context.LineStationReferences
                                .Any(lsr => lsr.Line == p.line && lsr.Station == p.station)) // Filter using a subquery
                .Include(pcd => pcd.PowerCurveStationDetails) // Include station details
                .Select(pcd => new
                {
                    PowerCurveDetail = pcd, // Select the PowerCurveDetails entity
                    StationOrder = _context.LineStationReferences
                                   .Where(lsr => lsr.Line == pcd.line && lsr.Station == pcd.station)
                                   .Select(lsr => lsr.StationOrder)
                                   .FirstOrDefault() // Fetch StationOrder
                })
                .OrderBy(result => result.StationOrder) // Order by StationOrder
                .ToListAsync();

            // Map the stationOrder to PowerCurveDetails
            var mappedRecords = pcdRecords.Select(result =>
            {
                result.PowerCurveDetail.stationOrder = result.StationOrder;
                return result.PowerCurveDetail; // Return the updated PowerCurveDetails object
            }).ToList();

            if (!mappedRecords.Any())
            {
                throw new KeyNotFoundException("No power curve details found with the specified ID and station.");
            }

            return mappedRecords;
        }



        /// <inheritdoc/>
        public async Task<(string StatusMessage, int StatusCode)> OverridePowerCurveDraft(string json, int PowerCurveDetailID, HttpContext httpContext)
        {
           
            

                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }
                var parameters = new[]
                   {
                new SqlParameter("@PowerCurveDetailID", SqlDbType.Int) {Value = PowerCurveDetailID},
                new SqlParameter("@OverridePowerCurveData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }

                   };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_OverridePowerCurveStation] @PowerCurveDetailID, @OverridePowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[2].Value.ToString();
                int StatusCode = (int)parameters[3].Value;

                return (statusMessage, StatusCode);
           
        }




        public async Task<(string StatusMessage, int StatusCode)> UpdateUserPowerforPowerCurveStation(string json, int PowerCurveDetailID, HttpContext httpContext)
        {
            
                httpContext.Items.TryGetValue("X-Username", out var username);
                httpContext.Items.TryGetValue("X-UserID", out var userID);
                httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

                // Ensure userGUID is of type Guid
                Guid userGuidValue = Guid.Empty;
                if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                }

                var parameters = new[]
                {
                new SqlParameter("@PowerCurveDetailID", SqlDbType.Int) {Value = PowerCurveDetailID},
                new SqlParameter("@UserPowerCurveData", SqlDbType.NVarChar) {Value=json },
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC [bolt_stage].[usp_UpdateUserPowerforPowerCurveStation] @PowerCurveDetailID, @UserPowerCurveData, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                    parameters);

                // Retrieve the output values
                var statusMessage = parameters[2].Value.ToString();
                int StatusCode = (int)parameters[3].Value;

                return (statusMessage, StatusCode);
           
        }



        public async Task<(string StatusMessage, int StatusCode)> DeletePowerCurveStation(int PowercurveDetailID)
        {
            if ((_context == null) | (_context?.PowerCurveDetails == null))
                return ("Power curve data not initialized.", 400);

            var item = await _context.PowerCurveDetails.FindAsync(PowercurveDetailID);

            if (item == null)
            {
                return ("Power curve Detail not found.", 400);
            }

            else
            {
                int PowerCurveID = item.powerCurveID;

                var PowerCurveResult = await _context.PowerCurves.FindAsync(PowerCurveID);
                if (PowerCurveResult != null)
                {
                    if (PowerCurveResult.status.ToUpper() == "DRAFT")
                    {
                        var parameters = new[]
                           {
                            new SqlParameter("@PowerCurveDetailID", SqlDbType.Int) {Value = PowercurveDetailID},
                            new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                            new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output }

                            };

                        // Execute the stored procedure
                        await _context.Database.ExecuteSqlRawAsync(
                            "EXEC  [bolt_stage].[usp_DeletePowerCurveStation]  @PowerCurveDetailID, @StatusMessage OUTPUT, @StatusCode OUTPUT",
                            parameters);

                        // Retrieve the output values
                        var statusMessage = parameters[1].Value.ToString();
                        int StatusCode = (int)parameters[2].Value;
                        return (statusMessage, StatusCode);
                    }
                    else
                    {
                        return ("Power Curve not in Draft status", 401);
                    }
                }
                else
                {
                    return ("Power Curve not found", 400);
                }

            }

        }



        public async Task<(string StatusMessage, int StatusCode)> DeletePowerCurve(int PowerCurveID)
        {
            if ((_context == null) | (_context?.PowerCurveDetails == null))
                return ("Power curve data not initialized.", 400);

            var parameters = new[]
                {
                new SqlParameter("@PowerCurveID", SqlDbType.Int) {Value = PowerCurveID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
              
                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_DeletePowerCurve] @PowerCurveID, @StatusMessage OUTPUT, @StatusCode OUTPUT",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;

            return (statusMessage, StatusCode);

        }







        public async Task<(string StatusMessage, int StatusCode)> PublishPowerCurve(int PowercurveID, HttpContext httpContext)
        {
            if ((_context == null) | (_context?.PowerCurveDetails == null))
                return ("Power curve data not initialized.", 400);



            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }

            var parameters = new[]
            {
                new SqlParameter("@PowerCurveID", SqlDbType.Int) {Value = PowercurveID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_PublishPowerCurve] @PowerCurveID, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;
            return (statusMessage, StatusCode);
           
        }



        public async Task<(string StatusMessage, int StatusCode)> DuplicatePowerCurve(int PowercurveID, HttpContext httpContext)
        {
            if ((_context == null) | (_context?.PowerCurveDetails == null))
                return ("Power curve data not initialized.", 400);


            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }

            var parameters = new[]
            {
                new SqlParameter("@PowerCurveID", SqlDbType.Int) {Value = PowercurveID},
                new SqlParameter("@StatusMessage", SqlDbType.NVarChar, 4000) { Direction = ParameterDirection.Output },
                new SqlParameter("@StatusCode", SqlDbType.Int) { Direction = ParameterDirection.Output },
                new SqlParameter("@username", SqlDbType.VarChar) {Value=username?.ToString() },
                new SqlParameter("@userid", SqlDbType.NVarChar) {Value=userID?.ToString() },
                new SqlParameter("@userguid", SqlDbType.UniqueIdentifier) {Value=userGuidValue }
                };

            // Execute the stored procedure
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC [bolt_stage].[usp_DuplicatePowerCurveData] @PowerCurveID, @StatusMessage OUTPUT, @StatusCode OUTPUT,@username,@userid,@userguid",
                parameters);

            // Retrieve the output values
            var statusMessage = parameters[1].Value.ToString();
            int StatusCode = (int)parameters[2].Value;
            return (statusMessage, StatusCode);

        }



    }
}
