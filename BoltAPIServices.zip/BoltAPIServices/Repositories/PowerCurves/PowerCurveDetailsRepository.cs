﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.PowerCurves;

namespace BOLTAPIServices.Repositories
{
    public class PowerCurveDetailsRepository : ReadOnlyRepository<PowerCurveDetails>, IPowerCurveDetailsRepository
    {
       
        /// <summary>
        /// Constructor for PowerCurveDetail.
        /// </summary>
        public PowerCurveDetailsRepository(IServiceProvider serviceProvider) : base (serviceProvider)
        {
           
        }

       

    }
}
