﻿using BOLTAPIServices.Repositories.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BOLTAPIServices.Repositories.Interfaces.PowerCurves;
using BOLTAPIServices.Models.PowerCurves;

namespace BOLTAPIServices.Repositories.PowerCurves
{
    public class ViewPowerCurveRegionRepository : ReadOnlyRepository<ViewPowerCurveRegion>, IViewPowerCurveRegionRepository
    {

        /// <summary>
        /// Constructor for Powercurve Repository.
        /// </summary>
        public ViewPowerCurveRegionRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {

        }



    }
}
