﻿using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using static System.Collections.Specialized.BitVector32;
using System.Net;

namespace BOLTAPIServices.Repositories
{
    public class CommentRepository : ReadOnlyRepository<Comments>, ICommentRepository
    {

        protected readonly IServiceProvider _serviceProvider;
        private BoltDbContext _context;
        /// <inheritdoc/>
        public CommentRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _context = GetContext();

        }
        /// <inheritdoc/>
        public async Task<HttpStatusCode> AddComment(CommentInput commentInput, HttpContext httpContext)
        {

            httpContext.Items.TryGetValue("X-Username", out var username);
            httpContext.Items.TryGetValue("X-UserID", out var userID);
            httpContext.Items.TryGetValue("X-UserGUID", out var userGUID);

            // Ensure userGUID is of type Guid
            Guid userGuidValue = Guid.Empty;
            if (userGUID != null && Guid.TryParse(userGUID.ToString(), out var parsedGuid))
            {
                userGuidValue = parsedGuid;
            }
            //Check refid should be in draft status
            if (commentInput.refSubject == "PowerCurve")
            {
                var item = await (_context.PowerCurves?.FindAsync(commentInput.refId) ?? ValueTask.FromResult<PowerCurve?>(null));
                if (item == null)
                {
                    return HttpStatusCode.NotFound;

                }

                    // Create a new Comment entity from the input model
                    var newComment = new Comments
                    {
                        Ref = commentInput.refSubject,
                        RefID = commentInput.refId,
                        Comment = commentInput.Comment,
                        CreatedByUserId = userID?.ToString(), // This would come from authenticated user context
                        CreatedByUserGUID = userGuidValue, // This would also come from authenticated user context
                        CreatedByUserName = username?.ToString() ?? "", // Replace with actual username
                        LastUpdateDateTime = DateTime.UtcNow
                    };

                    // Add and save the new comment to the database
                    _context.Comments.Add(newComment);
                    await _context.SaveChangesAsync();
                    return HttpStatusCode.OK;
               
            }

            else
            {
               return  HttpStatusCode.BadRequest;
            }
          
        }


        public async Task<IEnumerable<Comments>> ViewComment(string reference, int refId)
        {
            var pcdRecords = await _context.Comments
              .Where(p => p.Ref == reference && p.RefID == refId)
              .ToListAsync();

            if (!pcdRecords.Any())
            {
                throw new KeyNotFoundException("No comments found.");
            }
            return pcdRecords;
        }
    }
}
