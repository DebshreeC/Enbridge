﻿using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
    public class CommentInput
    {
            [JsonPropertyName("ref")]   
            public string refSubject { get; set; }
            public int refId { get; set; }
            [JsonPropertyName("comment")]
            public string Comment { get; set; }
        
    }
}
