﻿using Microsoft.AspNetCore.OData.Deltas;

namespace BOLTAPIServices.Models.Interfaces
{// generic flowrate data for draft, pub and ref
    /// <summary>
    /// Interface representing the flow rate data for draft, pub, and ref.
    /// </summary>
    public interface IFlowRate
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        int id { get; set; }

        /// <summary>
        /// Gets or sets the region.
        /// </summary>
        string region { get; set; }

        /// <summary>
        /// Gets or sets the line.
        /// </summary>
        string? line { get; set; }

        /// <summary>
        /// Gets or sets the flow rate in cubic meters per hour.
        /// </summary>
        decimal flowRatem3hr { get; set; }

        /// <summary>
        /// Gets or sets the date and time when the flow rate was last updated.
        /// </summary>
        DateTime flowRateUpdatedDateTime { get; set; }
    }
}
