﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.FlowRates
{
    [Table("ViewMetaFlowRates", Schema = "bolt_stage")]
    public class ViewMetaFlowRate
    {
        [JsonIgnore]  // Hides this property from the JSON response
        public int Id { get; set; }
        public DateTime? refFlowRateUpdatedDateTime { get; set; }
        public DateTime? userFlowRateUpdatedDateTime { get; set; }
        public DateTime? publishedFlowRateUpdatedDateTime { get; set; }
        public Guid? updatedByUserGUID { get; set; }
        public string? updatedByUserId { get; set; }
        public string? updatedByUsername { get; set; }
        public int? optimusUpdadateSuccessFlag { get; set; }
    }
}
