﻿using BOLTAPIServices.Models.Interfaces;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models.FlowRates
{   //draft data model
    public class DraftFlowRate
    {


        [Required]
        public string line { get; set; }

        [Required]
        public decimal draftFlowRatem3hr { get; set; }

    }
}
