﻿using Newtonsoft.Json;

namespace BOLTAPIServices.Models.FlowRates
{
    public class DraftFlowRateList
    {
        public List<DraftFlowRate> Data { get; set; }
    }
}
