﻿using Microsoft.OData;

namespace BOLTAPIServices.Models.FlowRates
{
    public class RootHistoryDetailFlowRate
    {
        // public int Id { get; set; }
        public ViewHistoryMetaFlowRate Meta { get; set; }
        public List<ViewHistoryDetailFlowRate> Data { get; set; }
    }
}
