﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.FlowRates
{
    [Table("ViewHistoryMetaFlowRates", Schema = "bolt_stage")]
    public class ViewHistoryMetaFlowRate
    {
        [Key]
        public int HistoryId { get; set; }
        public DateTime? refFlowRateUpdatedDateTime { get; set; }
        public DateTime? userFlowRateUpdatedDateTime { get; set; }
        public DateTime? publishedFlowRateUpdatedDateTime { get; set; }
        public string? updatedByUserGUID { get; set; }
        public string? updatedByUserId { get; set; }
        public string? updatedByUsername { get; set; }

    }
}
