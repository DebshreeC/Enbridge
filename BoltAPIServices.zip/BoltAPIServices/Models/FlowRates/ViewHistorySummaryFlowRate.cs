﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models.FlowRates
{
    [Table("ViewHistorySummaryFlowRates", Schema = "bolt_stage")]
    public class ViewHistorySummaryFlowRate
    {
        [Key]
        public int? HistoryID { get; set; }

        public DateTime? refFlowRateUpdatedDateTime { get; set; }
        public DateTime? userFlowRateUpdateDateTime { get; set; }
        public string? updatedByUserGUID { get; set; }


        public string? updatedByUserId { get; set; }


        public string? updatedByUsername { get; set; }
    }
}
