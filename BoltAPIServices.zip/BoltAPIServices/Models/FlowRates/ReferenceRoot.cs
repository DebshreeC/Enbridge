﻿namespace BOLTAPIServices.Models.FlowRates
{
    public class ReferenceRoot
    {
        public Guid Id { get; set; }
        public DateTime IssuedForDate { get; set; }
        public DateTime PublishDate { get; set; }
        public List<ReferenceLine> LineRows { get; set; }
    }
}
