﻿using BOLTAPIServices.Models.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models.FlowRates
{//published data model
    public class PublishedFlowRate : IFlowRate
    {
        [Key]
        public int id { get; set; }

        [Required]
        [StringLength(100)]
        public string region { get; set; }

        [Required]
        [StringLength(100)]
        public string line { get; set; }
        public decimal publishedFlowRatem3hr { get; set; }
        public DateTime publishedFlowRateUpdatedDateTime { get; set; }

        decimal IFlowRate.flowRatem3hr
        {
            get => publishedFlowRatem3hr;
            set => publishedFlowRatem3hr = value;
        }

        DateTime IFlowRate.flowRateUpdatedDateTime
        {
            get => publishedFlowRateUpdatedDateTime;
            set => publishedFlowRateUpdatedDateTime = value;
        }
    }
}
