﻿using BOLTAPIServices.Models.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models.FlowRates
{
    /// <summary>
    /// Represents a reference flow rate for a specific region, station, and line.
    /// </summary>
    [Table("ReferenceFlowRates", Schema = "bolt_stage")]
    public class ReferenceFlowRate : IFlowRate
    {
        /// <summary>
        /// Gets or sets the unique identifier for the reference flow rate.
        /// </summary>
        [Key]
        public int id { get; set; }

        /// <summary>
        /// Gets or sets the region associated with the reference flow rate.
        /// </summary>
        [Required]
        [StringLength(100)]
        public string region { get; set; }

        /// <summary>
        /// Gets or sets the station associated with the reference flow rate.
        /// </summary>
        //[Required]
        //[StringLength(100)]
        //public string Station { get; set; }

        /// <summary>
        /// Gets or sets the line associated with the reference flow rate.
        /// </summary>
        [StringLength(100)]
        public string? line { get; set; }

        /// <summary>
        /// Gets or sets the reference flow rate in cubic meters per hour.
        /// </summary>
        public decimal refFlowRatem3hr { get; set; }

        /// <summary>
        /// Gets or sets the date and time when the reference flow rate was last updated.
        /// </summary>
        public DateTime refFlowRateUpdatedDateTime { get; set; }

        decimal IFlowRate.flowRatem3hr
        {
            get => refFlowRatem3hr;
            set => refFlowRatem3hr = value;
        }

        DateTime IFlowRate.flowRateUpdatedDateTime
        {
            get => refFlowRateUpdatedDateTime;
            set => refFlowRateUpdatedDateTime = value;
        }
    }
}
