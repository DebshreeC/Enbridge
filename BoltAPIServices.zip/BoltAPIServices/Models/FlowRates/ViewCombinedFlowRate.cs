﻿using BOLTAPIServices.Repositories.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using BOLTAPIServices.Models.Interfaces;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.FlowRates
{
    /*
       data: {
                "Region": "Western",
                "Line": "1",
                "RefFlowRatem3hr": 600,
                "publishedFlowRatem3hr": 600,
                "draftFlowRatem3hr": 600
                } 
     */
    //model for flowrates data from bolt_stage.ViewCombinedFlowRates
    [Table("ViewCombinedFlowRates", Schema = "bolt_stage")]
    public class ViewCombinedFlowRate : IViewCombinedFlowRate
    {
        [JsonIgnore]  // Hides this property from the JSON response
        public long Id { get; set; }

        [StringLength(255)]
        [Unicode(false)]
        public string? Region { get; set; }

        [StringLength(255)]
        [Unicode(false)]
        public string? Line { get; set; }

        public int? RefFlowRatem3hr { get; set; }

        public int? PublishedFlowRatem3hr { get; set; }

        [Column("draftflowratem3hr")]
        public int? DraftFlowRatem3hr { get; set; }

    }
}
