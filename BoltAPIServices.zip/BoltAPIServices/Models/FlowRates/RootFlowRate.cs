﻿using Microsoft.OData;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.FlowRates
{
    public class RootFlowRate
    {
        [JsonIgnore]  // Hides this property from the JSON response
        public int Id { get; set; }
        public ViewMetaFlowRate Meta { get; set; }
        public List<ViewCombinedFlowRate> Data { get; set; }
    }
}
