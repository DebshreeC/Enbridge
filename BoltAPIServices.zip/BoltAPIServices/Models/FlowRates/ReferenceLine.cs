﻿using Newtonsoft.Json;

namespace BOLTAPIServices.Models.FlowRates
{
    public class ReferenceLine
    {
        [JsonIgnore]  // Hides this property from the JSON response
        public Guid Id { get; set; }
        public string LineId { get; set; }
        public string UnitOfMeasure { get; set; }
        public string LineInformation { get; set; }
        public List<decimal> Rates { get; set; }
    }
}
