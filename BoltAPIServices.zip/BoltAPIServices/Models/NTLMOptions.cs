﻿namespace BOLTAPIServices.Models
{
    public class NTLMOptions
    {
        public string BaseUrl { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Domain { get; set; }
    }
}
