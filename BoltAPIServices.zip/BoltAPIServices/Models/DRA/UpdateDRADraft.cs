﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateDRAdata
    {

       public  int draSummaryID {  get; set; }
        
        [StringLength(100)]
        public string title { get; set; }


        public DateTime? applicableDateStart { get; set; }

       
        public DateTime? applicableDateEnd { get; set; }

        public int? heavyPercentage {  get; set; }

        public int? lightPercentage { get; set; }

    }
    public class UpdateDRADraft
    {
    
        public List<UpdateDRAdata> data { get; set; }
    }
}
