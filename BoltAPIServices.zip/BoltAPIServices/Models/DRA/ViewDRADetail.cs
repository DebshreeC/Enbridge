﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
    [Table("viewDRADetail", Schema = "bolt_stage")]
    public class ViewDRADetail
    {


        [Key]
        [JsonIgnore]
        public long Id { get; set; }
        
        [JsonIgnore]
       
        public int draSummaryID { get; set; }
        [JsonIgnore]
        public string? line { get; set; }
        public string? station { get; set; }

        public int? publishedFlowRatem3hr { get; set; }


        public decimal? referenceUsageLbHr { get; set; }

       
        public decimal? userGivenUsageLbHr { get; set; }
        public string? draType { get; set; }


    }

}
