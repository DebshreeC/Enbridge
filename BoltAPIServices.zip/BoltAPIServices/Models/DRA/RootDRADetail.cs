﻿using BOLTAPIServices.DTO;
using Microsoft.OData;

namespace BOLTAPIServices.Models.PowerCurves
{
    public class RootDRADetail
    {
        
        public DRASummary? meta { get; set; }
        public List<ViewDRADetail> data { get; set; }
    }
}
