﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.DRA
{
    [Table("viewDRAfluidgroup", Schema = "bolt_stage")]
    public class DRA_fluidgroup
    {
        [Key]
        [JsonIgnore]
        public long Id {  get; set; }
        public string? region { get; set; }
        public string? line { get; set; }
        public int fluidGroup { get; set; }
        public int? fluidGroupPercentage { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? updatedByUserId { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public Guid? updatedByUserGUID { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? updatedByUserName { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public DateTime? updatedDateTime { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? createdByUserId { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public DateTime? createdDateTime { get; set; }
    }
    public class DRAfluidgroupMeta
    {
        public string? updatedByUserId { get; set; }
        public Guid? updatedByUserGUID { get; set; }
        public string? updatedByUserName { get; set; }
        public DateTime? updatedDateTime { get; set; }
    }
    public class DRAfluidgroupResponse
    {
        public DRAfluidgroupMeta meta { get; set; }
        public List<DRA_fluidgroup> data { get; set; }
    }
}
