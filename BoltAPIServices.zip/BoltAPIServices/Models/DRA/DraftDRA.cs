﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class DRAdata
    {

        //[Required]
        [StringLength(100)]
        public string? line { get; set; }

        [Required]
        [StringLength(100)]
        public string title { get; set; }


        [Required]
        public DateTime applicableDateStart { get; set; }

        [Required]
        public DateTime applicableDateEnd { get; set; }
     

    }
    public class DraftDRA
    {
    
        public DRAdata data { get; set; }
    }
}
