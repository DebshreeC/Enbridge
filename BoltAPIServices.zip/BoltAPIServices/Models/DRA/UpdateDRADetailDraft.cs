﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateDRADetail
    {
        
        public string station { get; set; }

        public int? flowRatem3hr { get; set; }

        public decimal? userGivenUsageLbHr {  get; set; }

        public string? DRAType { get; set; }

    }
    public class UpdateDRADetailDraft
    {
    
        public List<UpdateDRADetail> data { get; set; }
    }
}
