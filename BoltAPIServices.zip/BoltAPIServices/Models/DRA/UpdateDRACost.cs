﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateDRACost
    {

        public string DRAType { get; set; }
        public decimal Density { get; set; }
        public decimal CostPerGalCAD { get; set; }
        public decimal CostPerLBCAD { get; set; }

    }
    public class UpdateDRACostRequest
    {
    
        public List<UpdateDRACost> data { get; set; }
    }
}
