﻿using BOLTAPIServices.Models.PowerCurves;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.DRA
{
    [Table("DRA_Cost", Schema = "bolt_stage")]
    public class DRA_Cost
    {
        [JsonIgnore]// Hides this property from the JSON response
        [Key]
        public int ID { get; set; }
        public string? DRAType { get; set; }
        public double? density { get; set; }
        public double? costPerGalCAD { get; set; }
        public double? costPerLbCAD { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? updatedByUserId { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public Guid? updatedByUserGUID { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? updatedByUserName { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public DateTime? updatedDateTime { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public string? createdByUserId { get; set; }
        [JsonIgnore]// Hides this property from the JSON response
        public DateTime? createdDateTime { get; set; }
    }

    public class DRACostMeta
    {        
        public string? updatedByUserId { get; set; }
        public Guid? updatedByUserGUID { get; set; }
        public string? updatedByUserName { get; set; }
        public DateTime? updatedDateTime { get; set; }
    }
    public class DRACostResponse
    {
        public DRACostMeta meta { get; set; }
        public List<DRA_Cost> data { get; set; }
    }

}
