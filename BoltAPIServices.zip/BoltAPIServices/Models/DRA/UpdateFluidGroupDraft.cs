﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateFluidGroup
    {
        
        public int fluidGroup { get; set; }

        public int? value { get; set; }


    }
    public class UpdateFluidGroupDraft
    {
    
        public List<UpdateFluidGroup> data { get; set; }
    }
}
