﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateStationPowerCurve
    {
        public Data data { get; set; }

        public class Data
        {
            public DateTime? applicableDateStart { get; set; }

            public DateTime? applicableDateEnd { get; set; }
            //  public DateTime[] historicDates { get; set; }

         
            public List<HistoricDate>? historicDates { get; set; }
        }




    }

  
}
