﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class Updatedata
    {
        public string? title { get; set; }

        public DateTime? applicableDateStart { get; set; }

        public DateTime? applicableDateEnd { get; set; }
    
        public List<HistoricDate>? historicDates { get; set; }


    }

 

    public class UpdateDraftPowerCurve
    {
    
        public Updatedata data { get; set; }
    }
}
