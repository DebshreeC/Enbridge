﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class OverridePowerCurve
    {
        public Data data { get; set; }

        public class Data ()
        {

            [Required]
            [StringLength(100)]
            public string? selectedCurveFitMethod { get; set; }

            public float? userInputA { get; set; }
            public float? userInputB { get; set; }
            public float? userInputC { get; set; }
        }

    }

}
