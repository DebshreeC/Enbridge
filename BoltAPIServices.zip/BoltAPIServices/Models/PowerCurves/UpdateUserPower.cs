﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class UpdateUserPower
    {

        public class FlowDataModel
        {
            public List<FlowItem> flowData { get; set; }
        }


        
        public class FlowItem
        {
            public int flowRate { get; set; }
            public int userPowerKW { get; set; }
        }

        public class OverrideUserPower
        {
            [Required]
            public FlowDataModel data   { get; set; }
        }

    }

}
