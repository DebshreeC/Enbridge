﻿using BOLTAPIServices.Models.PowerCurves;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
    [Table("viewPowerCurveDetailForStation", Schema = "bolt_stage")]
    public class PowerCurveDetails
    {

        public string? station { get; set; }
        [Key]
        public int PowerCurveDetailID { get; set; }
        [JsonIgnore]
        public int powerCurveID { get; set; }
        [JsonIgnore]
        public string? line { get; set; }
     
  

        public DateTime? applicableDateRangeStart { get; set; }
        public DateTime? applicableDateRangeEnd { get; set; }


        [JsonIgnore]
        public string? historicalDateRange { get; set; }
        [NotMapped]
        public List<HistoricalDateRange> historicalDateRanges { get; set; }


        public string? selectedCurveFitMethod { get; set; }
        [Column(TypeName = "float")]
          public float? polynomialRSquare { get; set; }


        [Column(TypeName = "float")]
        public float? exponentialRSquare { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedA { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedB { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedC { get; set; }
        [Column(TypeName = "float")]
        public float? exponentialCalculatedA { get; set; }
        [Column(TypeName = "float")]
        public float? exponentialCalculatedB { get; set; }
        [Column(TypeName = "float")]
        public float? userInputA { get; set; }
        [Column(TypeName = "float")]
        public float? userInputB { get; set; }
        [Column(TypeName = "float")]
        public float? userInputC { get; set; }
        [JsonIgnore]
        public string? updatedByUsername { get; set; }
        [JsonIgnore]
        public Guid? updatedByUserGUID { get; set; }
        [JsonIgnore]
        public string? updatedByUserId { get; set; }

        [JsonIgnore]
        public DateTime? lastUpdatedDateTime { get; set; }
        public string? status { get; set; }
       
        [NotMapped]
        public int? stationOrder { get; set; }

        public List<PowerCurveStationDetails> PowerCurveStationDetails { get; set; }
       
    }
}
