﻿namespace BOLTAPIServices.Models.PowerCurves
{

    public class HistoricalDateRange
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
    }
}
