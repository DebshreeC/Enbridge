﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models.PowerCurves
{
    [Table("ViewPowerCurve", Schema = "bolt_stage")]
    public class ViewPowerCurveRegion
    {
        [Key]
        public int powerCurveID { get; set; }

        public string? line { get; set; }
        public string? region { get; set; }

        public string? title { get; set; }
      
        public DateTime? applicableDateStart { get; set; }
        public DateTime? applicableDateEnd { get; set; }
       
        public string? updatedByUserId { get; set; }
       
        public string? updatedByUsername { get; set; }
        
        public Guid? updatedByUserGUID { get; set; }
       
        public DateTime? lastUpdateDateTime { get; set; }
    
        public bool isFavourite { get; set; }

        public string? status { get; set; }


        [JsonIgnore]
        public int? lineOrder { get; set; }



        [JsonIgnore]
        public int? regionOrder { get; set; }


    }
}
