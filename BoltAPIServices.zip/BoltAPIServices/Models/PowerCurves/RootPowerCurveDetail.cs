﻿using BOLTAPIServices.DTO;
using Microsoft.OData;

namespace BOLTAPIServices.Models.PowerCurves
{
    public class RootPowerCurveDetail
    {
        // public int Id { get; set; }
        public MetaPowerCurveDTO meta { get; set; }
        public List<ViewPowerCurveDetail> data { get; set; }
    }
}
