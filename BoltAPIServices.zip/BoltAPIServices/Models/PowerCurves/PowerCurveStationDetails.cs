﻿using BOLTAPIServices.Models.PowerCurves;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
   
    [Table("viewPowerCurveStationDetails", Schema = "bolt_stage")]
    public class PowerCurveStationDetails
    {
        
        [Key]
        public int PowerCurveStationDetailsID { get; set; }
        [JsonIgnore]
        public int powerCurveDetailID { get; set; }
        [JsonIgnore]
        public int powerCurveID { get; set; }
        [JsonIgnore]
        public string? line { get; set; }
        [JsonIgnore]
        public string? station { get; set; }

        public int? flowRate { get; set; }
        public int? count{ get; set; }

        public double? referencePowerKwh { get; set; }
        public double? userPowerKwh { get; set; }
       
        [JsonIgnore]
        public string? updatedByUsername { get; set; }
        [JsonIgnore]
        public Guid? updatedByUserGUID { get; set; }
        [JsonIgnore]
        public string? updatedByUserId { get; set; }
        [JsonIgnore]
        public Guid? createdByUserGUID { get; set; }
        [JsonIgnore]
        public string? createdByUserId { get; set; }
        [JsonIgnore]
        public string? createdByUserName { get; set; }
        [JsonIgnore]
        public string? status { get; set; }

        public DateTime? lastUpdatedDateTime { get; set; }

    }


    public class PowerCurveResponse
    {
        public ViewPowerCurveRegion meta { get; set; }
        public List<PowerCurveDetails> data { get; set; }
    }




}
