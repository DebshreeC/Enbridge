﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class data
    {


        //[Required]
        [StringLength(100)]
        public string? line { get; set; }


        [Required]
        [StringLength(100)]
        public string title { get; set; }


        [Required]
        public DateTime applicableDateStart { get; set; }

        [Required]
        public DateTime applicableDateEnd { get; set; }
        //  public DateTime[] historicDates { get; set; }

    
        public List<HistoricDate>? historicDates { get; set; }


    }
    public class HistoricDate
    {
        
        public DateTime startDate { get; set; }

        public DateTime endDate { get; set; }
    }

    public class DraftPowerCurve
    {
    
        public data data { get; set; }
    }
}
