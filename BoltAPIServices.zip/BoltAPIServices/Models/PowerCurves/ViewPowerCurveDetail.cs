﻿using BOLTAPIServices.Models.PowerCurves;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
    [Table("viewPowerCurveDetail", Schema = "bolt_stage")]
    public class ViewPowerCurveDetail
    {
        [Key]
        public int PowerCurveDetailID { get; set; }
        public int PowerCurveID { get; set; }
        public string? line { get; set; }
        public string? station { get; set; }


        public string? region { get; set; }
        public string? title { get; set; }

        public DateTime? applicableDateStart { get; set; }
        public DateTime? applicableDateEnd { get; set; }

        [NotMapped]
        public List<HistoricalDateRange> historicalDateRanges { get; set; }

        [JsonIgnore]
        public string? historicalDateRange { get; set; }
        

        public string? selectedCurveFitMethod { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialRSquare { get; set; }
        [Column(TypeName = "float")]
        public float? exponentialRSquare { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedA { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedB { get; set; }
        [Column(TypeName = "float")]
        public float? polynomialCalculatedC { get; set; }
        [Column(TypeName = "float")]
        public float? exponentialCalculatedA { get; set; }
        [Column(TypeName = "float")]
        public float? exponentialCalculatedB { get; set; }
        [Column(TypeName = "float")]
        public float? userInputA { get; set; }
        [Column(TypeName = "float")]
        public float? userInputB { get; set; }
        [Column(TypeName = "float")]
        public float? userInputC { get; set; }
       
        public string? status { get; set; }

        public int? stationOrder { get; set; }


    }
}
