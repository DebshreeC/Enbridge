﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    public class Stationdata
    {



        [Required]
        [StringLength(100)]
        public string station { get; set; }


        [Required]
        public DateTime applicableDateStart { get; set; }

        [Required]
        public DateTime applicableDateEnd { get; set; }
        //  public DateTime[] historicDates { get; set; }

       // [Required]
        public List<HistoricDate>? historicDates { get; set; }


    }

   
    public class StationPowerCurveDraft
    {
       
        public Stationdata data { get; set; }
    }
}
