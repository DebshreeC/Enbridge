﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.Models
{
    [Table("PowerCurve", Schema = "bolt_stage")]
    public class PowerCurve
    {
        [Key]
        public int powerCurveID { get; set; }
        public string? line { get; set; }
        public string? title { get; set; }

        public DateTime? applicableDateStart { get; set; }
        public DateTime? applicableDateEnd { get; set; }
        public string? historicalDates { get; set; }

        public Guid? updatedByUserGUID { get; set; }

       
        public string? updatedByUserId { get; set; }

       
        public string? updatedByUserName { get; set; }
        public DateTime? lastUpdateDateTime { get; set; }
        public bool isFavourite {  get; set; }
        public string? status { get; set; }

        public Guid? createdByUserGUID { get; set; }

        public string? createdByUserId { get; set; }

        public string? createdByUserName { get; set; }



    }
}
