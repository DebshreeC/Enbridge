﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

namespace BOLTAPIServices.Models;

[Keyless]
[Table("LineStationReference", Schema = "bolt_stage")]
public partial class LineStationReference
{
    [Column("line")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Line { get; set; }

    [Column("optimusLineReferenceGUID")]
    [StringLength(50)]
    [Unicode(false)]
    public string? OptimusLineReferenceGuid { get; set; }

    [Column("station")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Station { get; set; }

    [Column("region")]
    [StringLength(255)]
    [Unicode(false)]
    public string? Region { get; set; }

    [JsonIgnore]
    [Column("regionOrder")]
    public int? RegionOrder { get; set; }

    [JsonIgnore]
    [Column("lineOrder")]
    public int? LineOrder { get; set; }

    [JsonIgnore]
    [Column("stationOrder")]
    public int? StationOrder { get; set; }


}
