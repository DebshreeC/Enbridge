﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.Models
{
    [Table("Comments", Schema = "bolt_stage")]
    public class Comments
    {
        [Key]
        [JsonIgnore]  // Hides this property from the JSON response
        public int CommentID { get; set; }
        public string Ref { get; set; }
        public int RefID { get; set; }
        public string Comment { get; set; }
        public string? UpdatedByUserId { get; set; }
        public Guid? UpdatedByUserGUID { get; set; }
        public string? UpdatedByUserName { get; set; }
        public DateTime LastUpdateDateTime { get; set; }
        public string? CreatedByUserId { get; set; }
        public Guid CreatedByUserGUID { get; set; }
        public string CreatedByUserName { get; set; }
      
    }

}
