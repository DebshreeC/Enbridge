using BOLTAPIServices.Models.Interfaces;
using BOLTAPIServices.Attributes;
using BOLTAPIServices.Repositories;
using BOLTAPIServices.Repositories.Contexts;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.OData;
using Microsoft.AspNetCore.OData.Batch;
using Microsoft.EntityFrameworkCore;
using Microsoft.OData.Edm;
using Microsoft.OData.ModelBuilder;
using Microsoft.OpenApi.Models;
using NSwag.AspNetCore;
using System.Reflection;
using Azure.Identity;
using Microsoft.Extensions.Options;
using BOLTAPIServices.Controllers;
using Microsoft.Data.SqlClient;
using BOLTAPIServices.Settings;
using System.Text.Json;
using System.Net;
using BOLTAPIServices.Repositories.Interfaces.FlowRates;
using BOLTAPIServices.Repositories.Interfaces.PowerCurves;
using BOLTAPIServices.Repositories.FlowRates;
using BOLTAPIServices.Repositories.PowerCurves;
using BOLTAPIServices.Models.FlowRates;
using BOLTAPIServices.Helpers.Interfaces;
using BOLTAPIServices.Helpers;
using BOLTAPIServices.DTO;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//builder.Services.AddDbContext<ApplicationContext>(options =>
//    options.UseSqlServer(builder.Configuration.GetConnectionString("SqlConnection")));



// Bind AppSettings configuration
builder.Services.Configure<BoltConfigSettings>(builder.Configuration);
// Register AutoMapper
builder.Services.AddAutoMapper(typeof(AutoMapperProfile));  // Register your profile


builder.Services.AddDbContext<BoltDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SqlConnection")));

//should be commented out later
//builder.Services.AddScoped<IFlowRateRepository, FlowRateRepository>();

builder.Services.AddScoped<IViewCombinedFlowRateRepository, ViewCombinedFlowRateRepository>();
builder.Services.AddScoped<IViewHistoryDetailFlowRateRepository, ViewHistoryDetailFlowRateRepository>();
builder.Services.AddScoped<IViewHistorySummaryFlowRateRepository, ViewHistorySummaryFlowRateRepository>();
builder.Services.AddScoped<IViewMetaFlowRateRepository, ViewMetaFlowRateRepository>();
builder.Services.AddScoped<IViewHistoryMetaFlowRateRepository, ViewHistoryMetaFlowRateRepository>();
builder.Services.AddScoped<ILineStationReferenceRepository, LineStationReferenceRepository>();
builder.Services.AddScoped<IReferenceFlowRateRepository, ReferenceFlowRateRepository>();
builder.Services.AddScoped<IDraftFlowRateRepository, DraftFlowRateRepository>();
builder.Services.AddScoped<IPublishedFlowRateRepository, PublishedFlowRateRepository>();
builder.Services.AddScoped<IDRARepository,DRARepository>();
builder.Services.AddScoped<IViewPowerCurveRegionRepository, ViewPowerCurveRegionRepository>();
builder.Services.AddScoped<IPowerCurveRepository, PowerCurveRepository>();
builder.Services.AddScoped<IPowerCurveDetailsRepository, PowerCurveDetailsRepository>();
builder.Services.AddScoped<ICommentRepository, CommentRepository>();
builder.Services.AddScoped<PowerCurveService>();
builder.Services.AddScoped<FlowRateService>();
builder.Services.AddScoped<CommentService>();
builder.Services.AddScoped<DRAService>();


    
builder.Services.AddControllers().AddJsonOptions(
        options =>
        {
            options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            options.JsonSerializerOptions.UnmappedMemberHandling =JsonUnmappedMemberHandling.Disallow; // Fail on unknown fields
        });

builder.Services.AddControllers().AddOData(options => options.Count().Filter().Expand().Select().OrderBy()
.AddRouteComponents("odata", GetEdmModelV1())
);
builder.Services.AddControllers(Options => Options.Filters.AddService<CustomEnableQueryAttributeFilterFactory>());
builder.Services.AddTransient<CustomEnableQueryAttributeFilterFactory>();
builder.Services.AddSingleton<CredentialService>();
builder.Logging.ClearProviders();
builder.Services.AddLogging();
builder.Logging.AddConsole();
builder.Logging.AddDebug();
builder.Logging.AddApplicationInsights();
builder.Services.AddScoped<IKeyVaultManager,KeyVaultManager>();

IEdmModel GetEdmModelV1()
{
    ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
    //add entity sets
    var entityset = builder.EntitySet<RootFlowRate>("FlowRates");
    entityset.EntityType.HasKey(x => x.Id);
    entityset.EntityType.ComplexProperty(x => x.Meta);
    entityset.EntityType.CollectionProperty(x => x.Data);


    // Add a second entity set: DRA

    var draDtoEntitySet = builder.EntitySet<DRADTO>("DRA");
    draDtoEntitySet.EntityType.HasKey(x => x.draSummaryID);
    


    return builder.GetEdmModel();
}
var cfgBuilder = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();
var configuration = cfgBuilder.Build();

string baseurl = configuration["NTLM:BaseUrl"];
// Replace with your Key Vault URL


builder.Services.AddHttpClient<FlowRatesController>("FlowRatesHttpClient", client =>
{
    client.BaseAddress = new Uri(baseurl);
}).ConfigurePrimaryHttpMessageHandler(provider =>
{
    var credentialService = provider.GetRequiredService<CredentialService>();
    return new HttpClientHandler
    {

        Credentials = credentialService.GetCredentials(),
        ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
    };
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApiDocument(configure =>
{
    configure.DocumentName = "v1";
    configure.Title = "Power Decision Aid API Services";
    // Set the comments path for the OpenAPI JSON and UI.
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    configure.PostProcess = document =>
    {
        document.Info.Contact = new NSwag.OpenApiContact
        {
            Name = "Rebecca Fung",
            Email = string.Empty
        };

        document.Info.ExtensionData = new Dictionary<string, object?>
        {
            { "x-xml-comments", File.ReadAllText(path: xmlPath) }
        };

    };
    configure.Version = "v1";
    configure.Description = "Power Decision Aid API Services";



});
builder.Services.AddApplicationInsightsTelemetry(new Microsoft.ApplicationInsights.AspNetCore.Extensions.ApplicationInsightsServiceOptions
{
    ConnectionString = builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"]
});



var app = builder.Build();

app.UseOpenApi(); // Serve OpenAPI/Swagger documents
app.UseSwaggerUi(settings =>
{
    settings.SwaggerRoutes.Add(item: new SwaggerUiRoute("Url", "/swagger/v1/swagger.json")
    );
});
app.UseHttpsRedirection();
app.UseMiddleware<HeaderInspectionMiddleware>();
app.UseRouting();
app.UseAuthorization();
app.MapControllers();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});
app.Run();
