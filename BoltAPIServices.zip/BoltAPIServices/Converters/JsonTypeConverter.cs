﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;

namespace BOLTAPIServices.Services

{
    /// <summary>
    /// Converts decimal values to integers for JSON serialization and deserialization.
    /// </summary>
    public class DecimalToIntJsonConverter : JsonConverter
    {
        private readonly string[] _fieldsToConvert;

       ///intialize
        public DecimalToIntJsonConverter(params string[] fieldsToConvert)
        {
            _fieldsToConvert = fieldsToConvert;
        }

        /// <summary>
        /// Determines if the specified object type can be converted.
        /// </summary>
        /// <param name="objectType"></param>
        /// <returns></returns>
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(decimal) || objectType == typeof(decimal?);

        }

        /// <summary>
        /// Reads the JSON representation of the object.
        /// </summary>
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Null)
            {
                return null;
            }

            var currentPath = reader.Path;
            if (Array.Exists(_fieldsToConvert, field => currentPath.EndsWith(field, StringComparison.OrdinalIgnoreCase)))
            {
                var value = JToken.Load(reader).Value<decimal>();
                Debug.WriteLine($"Converting {value} to int");
                return Convert.ToInt32(value);
            }

            return JToken.Load(reader).Value<decimal>();
        }

        /// <summary>
        /// Converts decimal values to integers for JSON serialization and deserialization.
        /// </summary>
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            Debug.WriteLine($"WriteJson called for value: {value}");
            if (value is decimal decimalValue)
            {
                writer.WriteValue(Convert.ToInt32(decimalValue));
            }
            else
            {
                writer.WriteNull();
            }
        }
    }
      
    
}
