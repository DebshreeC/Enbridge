﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using BOLTAPIServices.Helpers.Interfaces;
using System.Security.Cryptography;
using System.Text.Json;

namespace BOLTAPIServices.Helpers
{
    /// <inheritdoc/>>
    public class KeyVaultManager : IKeyVaultManager
    {
        const string APIKEY = "ApiKey";
        const string KEYVAULTURI = "KeyVaultUri";
        const string RUNMODE = "RunMode";
        const string DEBUG = "debug";
        bool debug = false;

        private readonly SecretClient _client;
        private string _apiKey = string.Empty;
        private readonly ILogger _logger;

        /// <summary>
        /// Key Vault Manager
        /// </summary>
        /// <param name="configuration"></param>

        /// <param name="logger"></param>
        public KeyVaultManager(IConfiguration configuration, ILogger<KeyVaultManager> logger)

        {
            string kvUri = configuration.GetValue<string>(KEYVAULTURI) + "";
            string runMode = configuration.GetValue<string>(RUNMODE) + "";
            debug = configuration.GetValue<bool>(DEBUG);

            _logger = logger;

            if (runMode.ToLower() != "local")
            {
                _client = new SecretClient(new Uri(kvUri), new DefaultAzureCredential());
            }
            else
            {
                _client = new SecretClient(new Uri(kvUri), new InteractiveBrowserCredential());
            }

        }

        /// <inheritdoc/>
        public async Task<string> GetApiKeyAsync()
        {
            if (string.IsNullOrEmpty(_apiKey))
            {
                var secretVersion = _client.GetPropertiesOfSecretVersions(APIKEY);
                if (!secretVersion.Any())
                {
                    //Create new secret
                    var newKey = GenerateApiKey();
                    await _client.SetSecretAsync(APIKEY, newKey);
                }
                var secret = await _client.GetSecretAsync(APIKEY);
                _apiKey = secret.Value.Value;
            }
            return _apiKey;
        }

        private string GenerateApiKey()
        {
            var key = new byte[32];

            using (var generator = RandomNumberGenerator.Create())
                generator.GetBytes(key);

            return Convert.ToBase64String(key);
        }
        public Dictionary<string, string> GetOptimusUserCreds()
        {
            if (debug)
                _logger.LogInformation("Getting Optimus User Creds");

            KeyVaultSecret secret = _client.GetSecret("OptimusSecret");
            string? creds = secret.Value.ToString() + "";
            creds = creds.Replace("\\\"", "\"");

            if (debug)
                _logger.LogInformation($"Credentials : {creds}");

            //const string Json1 = "{\"username\":\"svc_boltdev\",\"password\":\"<\\\\D5kdT=:$0%$qf\",\"domain\":\"enbridge\"}";
            var secretData = JsonSerializer.Deserialize<Dictionary<string, string>>(creds);


            return secretData;

        }
    }
}
