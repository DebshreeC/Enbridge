﻿namespace BOLTAPIServices.Helpers
{
    using Microsoft.AspNetCore.Http;
    using System.Threading.Tasks;

    /// <summary>
    /// Middleware to inspect and process custom headers in HTTP requests.
    /// </summary>
    public class HeaderInspectionMiddleware
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// Initializes a new instance of the <see cref="HeaderInspectionMiddleware"/> class.
        /// </summary>
        /// <param name="next">The next middleware in the pipeline.</param>
        public HeaderInspectionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invokes the middleware to inspect headers in the HTTP context.
        /// </summary>
        /// <param name="context">The HTTP context.</param>
        /// <returns>A task that represents the completion of request processing.</returns>
        public async Task InvokeAsync(HttpContext context)
        {
            // Check for the required header
            if (!context.Request.Headers.TryGetValue("X-Username", out var usernamevalue) || string.IsNullOrEmpty(usernamevalue) ||
                !context.Request.Headers.TryGetValue("X-UserID", out var userid) || string.IsNullOrEmpty(userid) ||
                !context.Request.Headers.TryGetValue("X-UserGUID", out var userguid) || string.IsNullOrEmpty(userguid))
            {
                // Return an access denied response if the header is missing or empty
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                await context.Response.WriteAsync("Access Denied: Missing or invalid header information.");
                return; // Stop further processing
            }
            else
            {
                Guid userGuidValue = Guid.Empty;
                if (userguid.ToString() != null && Guid.TryParse(userguid.ToString(), out var parsedGuid))
                {
                    userGuidValue = parsedGuid;
                    context.Items["X-Username"] = usernamevalue;
                    context.Items["X-UserID"] = userid;
                    context.Items["X-UserGUID"] = userGuidValue.ToString();
                }
            }
            // Call the next middleware in the pipeline
            await _next(context);
        }
    }

}
