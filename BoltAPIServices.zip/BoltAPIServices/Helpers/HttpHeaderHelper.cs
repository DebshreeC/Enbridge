﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Security;
using BOLTAPIServices.Services;

namespace BOLTAPIServices.Helpers
{

    /// <summary>>
    ///helper method to header information.
    public static class HttpHeaderHelper
    {
        /// <summary>>
        /// Creates a uri of the current request.
        /// </summary>
        /// <param name="request">The request object.</param>
        /// <returns>A uri string of the current request.</returns>
        public static string GenerateCurrentUri(HttpRequest request)
        {
            return string.Format("{0}://{1}{2}", request.Scheme, request.Host, request.Path);
        }

        /// <summary>
        /// Extract header information
        /// </summary>
        /// <remarks>
        ///     header keys:
        ///     X-Username - AssignedToUsername 
        /// </remarks>
        /// <param name="headers"></param>
        /// <returns>Username</returns>
        /// <exception cref="System.Security.SecurityException"></exception>
        public static string GetClientInformationFromHttpRequestHeader(IHeaderDictionary headers)
        {             // header keys:
            if (headers.TryGetValue("X-Username", out var userName))
            {
                if (string.IsNullOrEmpty(userName))
                {
                    throw new SecurityException("Username missing in header.");
                }
                return userName;
            }

            throw new SecurityException("X-Username key missing in header.");
        }

        /// <summary>
        /// Extract header information
        /// </summary>
        /// <remarks>
        ///     header keys:
        ///     X-Email 
        /// </remarks>
        /// <param name="headers"></param>
        /// <returns>email</returns>
        /// <exception cref="System.Security.SecurityException"></exception>
        public static string GetEmailFromHttpRequestHeader(IHeaderDictionary headers)
        {             // header keys:
            if (headers.TryGetValue("X-Email", out var email))
            {
                if (string.IsNullOrEmpty(email))
                {
                    throw new SecurityException("email missing in header.");
                }
                return email;
            }

            throw new SecurityException("X-Email key missing in header.");
        }

        /// <summary>
        /// Helper function to call an API
        /// </summary>
        /// <param name="apiPath"></param>
        /// <param name="query"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static async Task<string> CallAPI(string apiPath, Dictionary<string, string>? query, IConfiguration configuration)
        {
            var keyVaultManager = new KeyVaultManager(configuration);
            UriBuilder uriBuilder = new UriBuilder(apiPath);
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = uriBuilder.Uri;
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var apiKey = await keyVaultManager.GetApiKeyAsync();
                client.DefaultRequestHeaders.Add("ApiKey", apiKey);
                var url = "";
                if (query != null)
                    url = QueryHelpers.AddQueryString(apiPath, query);
                else
                    url = apiPath;

                var response = client.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    var dataObjects = response.Content.ReadAsStringAsync().Result;
                    var json = JsonConvert.DeserializeObject(dataObjects).ToString();

                    return json;
                }
                else
                {
                    return "Failed to connect APIs";
                }
            }
        }

        public static async Task<string> UploadAPI(string apiPath, string filename, Stream file, Dictionary<string, string>? query, IConfiguration configuration)
        {
            try
            {
                var resultValue = "";
                var keyVaultManager = new KeyVaultManager(configuration);
                UriBuilder uriBuilder = new UriBuilder(apiPath);
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = uriBuilder.Uri;
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var apiKey = await keyVaultManager.GetApiKeyAsync();
                    client.DefaultRequestHeaders.Add("ApiKey", apiKey);
                    var url = "";
                    if (query != null)
                        url = QueryHelpers.AddQueryString(apiPath, query);
                    else
                        url = apiPath;
                    using (var memStream = new MemoryStream())
                    {
                        await file.CopyToAsync(memStream);
                        using (var content = new ByteArrayContent(memStream.ToArray()))
                        {
                            content.Headers.Add("content-type", "application/octet-stream");
                            var result = client.PostAsync(url, content).Result;
                            if (result.IsSuccessStatusCode)
                            {
                                resultValue = result.Content.ReadAsStringAsync().Result;
                            }
                        }
                    }


                    //using (var content = new MultipartFormDataContent())
                    //{
                    //    var fileContent = new StreamContent(file);
                    //    fileContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                    //    {
                    //        FileName = filename
                    //    };
                    //    content.Add(fileContent);
                    //    var result = client.PostAsync(url, content).Result;
                    //    if (result.IsSuccessStatusCode)
                    //    {
                    //        resultValue = result.Content.ReadAsStringAsync().Result;
                    //    }
                    //}
                }
                return resultValue;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <summary>
        /// API call to download a file
        /// </summary>
        /// <param name="apiPath"></param>
        /// <param name="fileName"></param>
        /// <param name="query"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static async Task<FileStreamResult> DownloadAPI(string apiPath, string fileName, Dictionary<string, string>? query, IConfiguration configuration)
        {
            var keyVaultManager = new KeyVaultManager(configuration);
            UriBuilder uriBuilder = new UriBuilder(apiPath);
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = uriBuilder.Uri;
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var apiKey = await keyVaultManager.GetApiKeyAsync();
                client.DefaultRequestHeaders.Add("ApiKey", apiKey);
                var url = "";
                if (query != null)
                    url = QueryHelpers.AddQueryString(apiPath, query);
                else
                    url = apiPath;

                var response = client.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    var dataObjects = response.Content.ReadAsStreamAsync().Result;

                    string fileType;
                    var cTypeProver = new FileExtensionContentTypeProvider();
                    if (!cTypeProver.TryGetContentType(fileName, out fileType))
                    {
                        fileType = "application/octet-stream";
                    }

                    var fileStreamResult = new FileStreamResult(dataObjects, fileType)
                    {
                        FileDownloadName = fileName
                    };

                    return fileStreamResult;
                }
                else
                {
                    throw new Exception();
                }
            }
        }

    }
}
