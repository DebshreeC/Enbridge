﻿namespace BOLTAPIServices.Helpers.Interfaces
{
    /// <summary>
    /// Manages secrets in azure key vault
    /// </summary>>
    public interface IKeyVaultManager
    {
        /// <summary>
        /// Get API key from key vault
        /// Will generate a new key if secret does not exist
        /// </summary>
        /// <returns>API key for functions</returns>
        Task<string> GetApiKeyAsync();
        Dictionary<string, string> GetOptimusUserCreds();
    }
}
