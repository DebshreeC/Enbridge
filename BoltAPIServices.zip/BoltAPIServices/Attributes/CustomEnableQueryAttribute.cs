﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Logging;
using Microsoft.OData;
using System.Net;
namespace BOLTAPIServices.Attributes
{
       public class CustomEnableQueryAttribute : EnableQueryAttribute, IActionFilter
    {
        private ILogger<CustomEnableQueryAttribute> _logger;

        /*public CustomEnableQueryAttribute(ILogger<CustomEnableQueryAttribute> logger)
        {
            _logger = logger;
        }*/

        public void OnActionExecuting(ActionExecutingContext context)
        {
            // Log before the action executes
            _logger.LogInformation("Action executing: {ActionName}", context.ActionDescriptor.DisplayName);
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception != null)
            {
                // Log the exception
                _logger.LogError(context.Exception, "An error occurred in action: {ActionName}", context.ActionDescriptor.DisplayName);
                context.ExceptionHandled = true; // Mark the exception as handled
            }
            else
            {
                // Log after the action executes
                _logger.LogInformation("Action executed: {ActionName}", context.ActionDescriptor.DisplayName);
            }
        }
        public void SetLogger(ILogger<CustomEnableQueryAttribute> logger)
        {
            _logger = logger;
        }
        public override void ValidateQuery(HttpRequest request, ODataQueryOptions queryOptions)
        {
            try
            {
                base.ValidateQuery(request, queryOptions);
            }
            catch (ODataException ex)
            {
                _logger.LogError($"Odata Query Exception: {ex.Message}");
            }
        }
    }
    public class CustomEnableQueryAttributeFilterFactory : IFilterFactory
    {
        private readonly ILogger<CustomEnableQueryAttribute> _logger;

        public CustomEnableQueryAttributeFilterFactory(ILogger<CustomEnableQueryAttribute> logger)
        {
            _logger = logger;
        }

        public IFilterMetadata CreateInstance(IServiceProvider serviceProvider)
        {
            var filter = new CustomEnableQueryAttribute();
            filter.SetLogger(_logger);
            return filter;
        }

        public bool IsReusable => false;
    }


}
