﻿using BOLTAPIServices.Attributes;
using BOLTAPIServices.Models.Interfaces;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing;
using Microsoft.AspNetCore.OData.Routing.Attributes;
using Microsoft.EntityFrameworkCore;
using Microsoft.OData;
using Newtonsoft.Json;
using System.Net;
using NJsonSchema.Annotations;
using Namotion.Reflection;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using BOLTAPIServices.Models.FlowRates;
using Microsoft.ApplicationInsights;

namespace BOLTAPIServices.Controllers
{
    /// <summary>
    /// Exposes flowrate location data table
    /// </summary>
    [ODataRouteComponent("odata")]
    [Route("api/[controller]")]
    [ApiController]
    public class FlowRatesController : ControllerBase
    {
        private readonly FlowRateService? _flowrateservice;
        private readonly ILogger<ControllerBase>? _logger;
        private Boolean debug = false;
        private TelemetryClient _teleClient;
        /// <summary>
        /// Initializes a new instance of the <see cref="FlowRatesController"/> class.
        /// </summary>
        /// <param name="flowrateservice">The flowrate repository.</param>
        /// <param name="logger">The logger.</param>
        public FlowRatesController(FlowRateService flowrateservice, ILogger<ControllerBase> logger,IConfiguration config, TelemetryClient teleClient)
        {
            try
            {
                _flowrateservice = flowrateservice ?? throw new ArgumentNullException(nameof(flowrateservice));
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
                _teleClient = teleClient ?? throw new ArgumentNullException(nameof(teleClient));

                debug = config.GetValue<Boolean>("Debug");
                
            }
            catch (ODataException ex)
            {
                // Log the error details
                logger.LogError($"ODataException: {ex.Message}");
                logger.LogError($"Stack Trace: {ex.StackTrace}");
            }
        }

        /// <summary>
        /// Get list of flowrates
        /// </summary>
        /// <returns>list of flowrates</returns>
        // GET: api/flowrates
        [HttpGet]
        [CustomEnableQuery]
        public async Task<ActionResult<RootFlowRate>> GetFlowRates()
        {
            if (_flowrateservice == null)
            {
                return Problem("FlowRateService is not initialized.");
            }

            try
            {
                var items = await _flowrateservice.GetCombinedFlowRatesAsync();
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

        /// <summary>
        /// Get list of History detail flowrates
        /// </summary>
        /// <returns></returns>
        [HttpGet("history-detail/{HistoryID}")]
        [CustomEnableQuery]
        public async Task<ActionResult<RootHistoryDetailFlowRate>> GetHistoryDetailFlowRates(int HistoryID)
        {
            if (_flowrateservice == null)
            {
                return Problem("FlowRateService is not initialized.");
            }

            try
            {
                var items = await _flowrateservice.GetHistoryDetailFlowRatesAsync(HistoryID);
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }
        /// <summary>
        /// Reterive the History Summary FlowRate
        /// </summary>
        /// <returns></returns>

        [HttpGet("history-summary/{pageNumber}")]
        [CustomEnableQuery]
        public async Task<ActionResult<(IEnumerable<ViewHistorySummaryFlowRate>, int totalRecords)>> GetHistorySummaryFlowRates(int pageNumber = 1)
        {
            if (_flowrateservice == null)
            {
                return Problem("FlowRateService is not initialized.");
            }
            if (debug)
            {
                _teleClient.TrackEvent("GetHistorySummaryFlowRates", new Dictionary<string, string> { { "method start", pageNumber.ToString() } });
                _logger?.LogInformation($"GetHistorySummaryFlowRates: {pageNumber.ToString()} ");
            }
            try
            {


                var (items, totalrecords) = await _flowrateservice.GetHistorySummaryFlowRatesAsync(pageNumber);

                IEnumerable<ViewHistorySummaryFlowRate> items1 = items.ToList();
                if (items1.Count() == 0)

                {
                    return NotFound();
                }
                if (debug)
                { 
                    _teleClient.TrackEvent("GetHistorySummaryFlowRatesAsync", new Dictionary<string, string> { { "items.Count()", items1.Count().ToString() } });
                    _logger?.LogInformation($"GetHistorySummaryFlowRatesAsync: {items1.Count()} ");
                }

                return Ok(new
                {
                
                    meta = new { },
                    data = items
                });

            }
            catch (Exception ex)
            {
                _teleClient.TrackEvent("GetHistorySummaryFlowRatesAsync", new Dictionary<string, string> { { "Error", ex.ToString() } });
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

        /// <summary>
        /// Creates a draft of reference flow rates.
        /// </summary>
        /// <returns>Action result indicating the outcome of the operation.</returns>
        [HttpPost("Create-Draft/{refVal:int?}")]
        public async Task<ActionResult<RootFlowRate>> CreateDraft(int refVal = 0)
        {
            int successflag = 0;
            if (_flowrateservice == null)

            {
                return Problem("FlowRateService is not initialized.");
            }

            try
            {
                bool result = await _flowrateservice.CreateReferencetAsync(refVal);
                
                if (debug)
                {
                    _teleClient.TrackEvent("CreateDraft", new Dictionary<string, string> { { "Result in Controller", result.ToString() } });
                    _logger.LogInformation($"Result in controller: {result} ");
                }
                if (result)
                {
                    var result1 = await GetFlowRates();
                   
                    if (result1.Result is OkObjectResult okResult)
                    {
                        RootFlowRate? rootFlowRate = okResult.Value as RootFlowRate;
                        successflag= (result == true) ? 1 : 0;
                        if (debug)
                        {
                            _teleClient.TrackEvent("CreateDraft", new Dictionary<string, string> { { "Optimus success flag", successflag.ToString() } });
                            _logger.LogInformation($"Optimus success flag: {successflag} ");
                        }
                        rootFlowRate.Meta.optimusUpdadateSuccessFlag= successflag; 
                        return Ok(rootFlowRate);
                    }
                   
                    else
                    {
                    
                        return Problem("Failed to create draft of reference flow rates.");
                    }
                       
                }
                else
                
                {
                    var result1 = await GetFlowRates();
                    if (result1.Result is OkObjectResult okResult1)
                    {
                        RootFlowRate? rootFlowRate = okResult1.Value as RootFlowRate;
                        successflag = (result == true) ? 1 : 0;
                        if (debug)
                        {
                            _teleClient.TrackEvent("CreateDraft", new Dictionary<string, string> { { "Optimus success flag", successflag.ToString() } });
                            _logger.LogInformation($"Optimus success flag: {successflag} ");
                        }
                        rootFlowRate.Meta.optimusUpdadateSuccessFlag = successflag;
                        return Ok(rootFlowRate);
                    }
                    else
                        return Problem("Failed to create draft of reference flow rates.");
                }
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

        [HttpPut("Update-Draft")]
        public async Task<ActionResult> UpdateDraft([FromBody] DraftFlowRateList updatedlist)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    // Model is not valid; return the same view with the model to display errors
                    return BadRequest(ModelState);
                }


                var duplicates = updatedlist.Data
                                 .GroupBy(d => new { d.line,  d.draftFlowRatem3hr })
                                 .Where(g => g.Count() > 1)
                                 .Select(s => s.Key);

                if (duplicates.Count() > 0)
                {
                    return BadRequest("Dupicate Entries");
                }
                var settings = new JsonSerializerSettings { Converters = new List<JsonConverter> { new DecimalToIntJsonConverter(("DraftFlowRatem3hr")) } }; // Assuming default settings, adjust as needed
                var json = JsonConvert.SerializeObject(updatedlist, settings);
                var result = await _flowrateservice.UpdateDraftFlowRate(json, HttpContext);
                if (result)
                {
                    return new StatusCodeResult((int)HttpStatusCode.Created);
                }
                else
                {
                    return BadRequest("Please validate Json.");
                }

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }
        [HttpPost("publish")]
        public async Task<ActionResult> CreatePublishFlowRates()
        {
            try
            {
                var result = await _flowrateservice.PubslishedFlowRateTrans(HttpContext);
                return new StatusCodeResult((int)HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }

       
        }
    }
