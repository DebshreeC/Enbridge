﻿using BOLTAPIServices.Attributes;
using BOLTAPIServices.Models;
using BOLTAPIServices.Models.PowerCurves;
using BOLTAPIServices.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Attributes;
using Microsoft.OData;
using System.Net;

namespace BOLTAPIServices.Controllers
{
    
    [ApiController]
    [Route("api/comments")]
    public class CommentController : ControllerBase
    {
       private readonly CommentService? _commentservice;
        private readonly ILogger<ControllerBase>? _logger;


      /// <summary>
      /// 
      /// </summary>
      /// <param name="commentservice"></param>
      /// <param name="logger"></param>
        public CommentController(CommentService commentservice, ILogger<ControllerBase> logger)
        {
            try
            {
                _commentservice = commentservice;
                _logger = logger;
            }
            catch (Exception ex)
            {
                // Log the error details
              //  logger.LogError($"ODataException: {ex.Message}");
                logger.LogError($"Stack Trace: {ex.StackTrace}");
            }
        }

        /// <summary>
        /// To Add Comment
        /// </summary>
        /// <param name="commentInput"></param>
        /// <returns></returns>
        [HttpPost("add")]
        public async Task<IActionResult> AddComment([FromBody] CommentInput commentInput)
        {


            if (commentInput == null)
            {
                return BadRequest("Invalid data.");
            }


            try
            {

                HttpStatusCode result = await _commentservice.AddComment(commentInput, HttpContext);
                if (result == HttpStatusCode.OK)
                   
                {
                    return Ok("Comment added successfully.");
                }

                return NotFound("Not able to add comment to invalid power curve");
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
            // return true;
        }


        /// <summary>
        /// Get Comment details
        /// </summary>
        /// <returns></returns>
        [HttpGet("{reference}/{refId}")]
        [CustomEnableQuery]
        public async Task<ActionResult<IEnumerable<Comments>>> ViewComment(string reference, int refId )
        {
            if (_commentservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }

            try
            {
                var items = await _commentservice.ViewComment(reference,refId);
                // Create the response object
                return Ok(new
                {
                    meta = new { },
                    data = items
                });
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

    }
}
