﻿using BOLTAPIServices.Attributes;
using BOLTAPIServices.Helpers;
using BOLTAPIServices.Models.Interfaces;
using BOLTAPIServices.Models;
using BOLTAPIServices.Repositories.Interfaces;
using BOLTAPIServices.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing;
using Microsoft.AspNetCore.OData.Routing.Attributes;
using Microsoft.EntityFrameworkCore;
using Microsoft.OData;
using Newtonsoft.Json;
using System.Net;
using NJsonSchema.Annotations;
using Namotion.Reflection;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using BOLTAPIServices.Models.PowerCurves;
using static BOLTAPIServices.Models.UpdateUserPower;
using BOLTAPIServices.DTO;
using AutoMapper;
using Microsoft.AspNetCore.Http.HttpResults;

namespace BOLTAPIServices.Controllers
{
    /// <summary>
    /// Exposes PowerCurve  data table
    /// </summary>
    [Route("api/power-curve")]
    [ApiController]
    public class PowerCurveController : ControllerBase
    {
        private readonly PowerCurveService? _powercurveservice;
        private readonly ILogger<ControllerBase>? _logger;
        private readonly IMapper _mapper;



        /// <summary>
        /// Initializes a new instance of the <see cref="PowerCurveController"/> class.
        /// </summary>
        /// <param name="powercurveservice">The Powercurve repository.</param>
        /// <param name="logger">The logger.</param>
        public PowerCurveController(PowerCurveService powercurveservice, ILogger<ControllerBase> logger, IMapper mapper)
        {
            try
            {
                _powercurveservice = powercurveservice;
                _logger = logger;
                _mapper = mapper;
            }
            catch (ODataException ex)
            {
                // Log the error details
                logger.LogError($"ODataException: {ex.Message}");
                logger.LogError($"Stack Trace: {ex.StackTrace}");
            }
        }



        /// <summary>
        /// Get list of Power Curves Summary
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        
        public async Task<ActionResult<IEnumerable<ViewPowerCurveRegion>>> GetPowerCurve()
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }

            try
            {
                var items = await _powercurveservice.GetPowerCurveAsync();

                // Create the response object

                // Map items to DTOs
                var dtoItems = _mapper.Map<IEnumerable<PowerCurveRegionDTO>>(items);

                // Create the response object
                var response = new
                {
                    meta = new { }, // Add any additional metadata
                    data = dtoItems
                };

                return Ok(response);
                //return Ok(new
                //{
                //    meta = new { },
                //    data = items
                //});
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }


        [HttpPut("mark-favourite/{PowerCurveID}")]
        public async Task<ActionResult> MarkFavourite(int PowerCurveID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            try
            {
                var result = await _powercurveservice.MarkFavouriteAsync(PowerCurveID);
                

                if (result == null)
                {
                    return Problem(new { Message = "Power curve not found", PowerCurveID = PowerCurveID }.ToString(), HttpStatusCode.NotModified.ToString());
                }
                return StatusCode((int)HttpStatusCode.Accepted, result);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message,HttpStatusCode.NotModified.ToString());
            }

        }



        /// <summary>
        /// Get Power curve + Power Curve details based on power curve id
        /// </summary>
        /// <returns></returns>
        [HttpGet("{PowerCurveID}")]
        
        public async Task<ActionResult<RootPowerCurveDetail>> GetPowerCurveAndPowerCurveDtl(int PowerCurveID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }

            try
            {
                var result = await _powercurveservice.ViewPowerCurveDetailsAsync(PowerCurveID);

                return Ok(result);


            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }



        /// <summary>
        /// Get Power Curve Station details based on power curve id and station
        /// </summary>
        /// <returns></returns>
        [HttpGet("station-details/{PowerCurveID}/{Station?}")]
        
        public async Task<ActionResult<IEnumerable<PowerCurveResponse>>> GetPowerCurveDtlbasedonStation(int PowerCurveID, string?  Station)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }

            try
            {
                var items = await _powercurveservice.GetPowerCurveDtlbasedonStation(PowerCurveID,Station);

              return Ok(items); 
            

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }



        /// <summary>
        /// Get Power Curve details based on power curve id
        /// </summary>
        /// <returns></returns>
        [HttpGet("details/{PowerCurveID}")]
        
        public async Task<ActionResult<IEnumerable<PowerCurveDetails>>> GetPowerCurveDetail(int PowerCurveID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }

            try
            {
                var items = await _powercurveservice.GetPowerCurveDetailsAsync(PowerCurveID);
             
                return Ok(new
                {

                    meta = new { },
                    data = items
                });
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

        /// <summary>
        /// Create Power curve draft
        /// </summary>
        /// <param name="draftpowerCurve"></param>
        /// <returns></returns>


        [HttpPost("create-draft")]
        public async Task<IActionResult> CreatePowerCurveDraft([FromBody] DraftPowerCurve draftpowerCurve)
        {
           
            if (draftpowerCurve == null)
            {
                return BadRequest("Invalid data.");

            }
            if (draftpowerCurve.data.line == null || draftpowerCurve.data.line.Length == 0)
            {
                return BadRequest("line field is required.");
            }

            var (result, statusCode) = await _powercurveservice.SaveDraftPowerCurve(draftpowerCurve, HttpContext);
            //Calling  the service method...................
            if (statusCode == 201)
            {
                //return CreatedAtAction(nameof(CreatePowerCurveDraft), new { draftpowerCurve.data.line }, draftpowerCurve);
                return Ok(result);
            }
           
            else
            {
                return BadRequest(result.ToString());
            }
           
        }

        /// <summary>
        /// Update power Curve draft
        /// </summary>
        /// <param name="draftpowerCurve"></param>
        /// <param name="PowerCurveID"></param>
        /// <returns></returns>


        [HttpPut("update-draft/{PowerCurveID}")]
        public async Task<ActionResult> UpdatePowerCurveDraft([FromBody] UpdateDraftPowerCurve draftpowerCurve, int PowerCurveID)
        {

            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
         
            if (draftpowerCurve == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {
                var result = await _powercurveservice.UpdateDraftPowerCurve(draftpowerCurve, PowerCurveID,HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 201)
                {
                    //return CreatedAtAction(nameof(CreatePowerCurveDraft), new { draftpowerCurve.data.line }, draftpowerCurve);

                    return Ok("Data updated successfully");
                }
                else
                    return BadRequest(result.StatusMessage);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }

        /// <summary>
        /// To delete the power curve station
        /// </summary>
        /// <param name="PowerCurveDetailID"></param>
        /// <returns></returns>

        [HttpDelete("station/{PowerCurveDetailID}")]
        public async Task<ActionResult> DeletePowerCurveStation(int PowerCurveDetailID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            try
            {
                var (result, statusCode) = await _powercurveservice.DeletePowerCurveStation(PowerCurveDetailID);
                //var (result, statusCode) = await _powercurveservice.SaveDraftPowerCurve(draftpowerCurve);

                if (statusCode == 200)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound(new { Message = result, PowercurveDetailID = PowerCurveDetailID });
                }
                // return NotFound(new { Message = "Employee not found", EmployeeId = id });

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }


        /// <summary>
        /// To delete the power curve 
        /// </summary>
        /// <param name="PowerCurveID"></param>
        /// <returns></returns>

        [HttpDelete("delete/{PowerCurveID}")]
        public async Task<ActionResult> DeletePowerCurve(int PowerCurveID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            try
            {
                var (result, statusCode) = await _powercurveservice.DeletePowerCurve(PowerCurveID);
                if (statusCode == 200)
                {
                    return Ok(result);
                }
                else if( statusCode==400)
                {
                    return BadRequest(result);
                }
                else
                {
                    return NotFound(new { Message = result, PowercurveID = PowerCurveID });
                }

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }




        /// <summary>
        /// Generate Power Curve
        /// </summary>
        /// <param name="PowerCurveID"></param>
        /// <returns></returns>

        [HttpPut("generate/{PowerCurveID}")]
        public async Task<ActionResult> GeneratePowerCurve(int PowerCurveID)
        {
            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            try
            {
                var (result, StatusCode) = await _powercurveservice.GeneratePowerAsync(PowerCurveID);
                
                if (StatusCode == 200)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result.ToString());
                }

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }


        /// <summary>
        /// Add station to existing power curve draft
        /// </summary>
        /// <param name="stationPowerCurveDraft"></param>
        /// <param name="PowerCurverID"></param>
        /// <returns></returns>

        [HttpPost("station/{PowerCurveID}")]
        public async Task<IActionResult> AddStationToPowerCurveDraft([FromBody] StationPowerCurveDraft stationPowerCurveDraft, int PowerCurveID)
        {

            if (stationPowerCurveDraft == null)
            {
                return BadRequest("Invalid data.");

            }
            if (stationPowerCurveDraft.data.station == null)
            {
                return BadRequest("Station field is required.");
            }


            try
            {
                var (result, statusCode) = await _powercurveservice.StationPowerCurveDraft(stationPowerCurveDraft, PowerCurveID, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                //  return Ok(result);
                if (statusCode == 201)
                {
                    return CreatedAtAction(nameof(CreatePowerCurveDraft), new { stationPowerCurveDraft.data.station }, result);
                }
                if (statusCode == 200)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result.ToString());
                }


            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
            // return true;
        }

        /// <summary>
        /// Update the existing station for power curve
        /// </summary>
        /// <param name="updateStationPowerCurve"></param>
        /// <param name="PowerCurveDetailID"></param>
        /// <returns></returns>

        [HttpPut("station/{PowerCurveDetailID}")]
        public async Task<IActionResult> UpdateStationforPowerCurveDraft([FromBody] UpdateStationPowerCurve updateStationPowerCurve, int PowerCurveDetailID)
        {
            if (updateStationPowerCurve == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {
                var (result, statusCode) = await _powercurveservice.UpdateStationforPowerCurveDraft(updateStationPowerCurve, PowerCurveDetailID,HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                //  return Ok(result);
               
                if (statusCode == 200)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result.ToString());
                    
                }


            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }





        }



        [HttpPut("station/override-fit/{PowerCurveDetailID}")]
        public async Task<ActionResult> OverridePowerCurveDraft([FromBody] OverridePowerCurve overridepowerCurve, int PowerCurveDetailID)
        {

            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (overridepowerCurve == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {
                var result = await _powercurveservice.OverridePowerCurveDraft(overridepowerCurve, PowerCurveDetailID, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 200)
                {
                    // return (nameof(OveriridePowerCurveDraft), new { overridepowerCurve.selectedCurveFitMethod }, overridepowerCurve);
                    return Ok(result.StatusMessage);
                }
                else
                    return BadRequest(result.StatusMessage);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }



        [HttpPut("station/override-power/{PowerCurveDetailID}")]
        public async Task<ActionResult>  UpdateUserPowerforPowerCurveDraft([FromBody] OverrideUserPower overrideUserPower, int PowerCurveDetailID)
        {

            if (_powercurveservice == null)
            {
                return Problem("PowerCurveService is not initialized.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (overrideUserPower.data.flowData == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {

               var result = await _powercurveservice.UpdateUserPowerforPowerCurveStation(overrideUserPower, PowerCurveDetailID, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 200)
                {
                    // return (nameof(OveriridePowerCurveDraft), new { overridepowerCurve.selectedCurveFitMethod }, overridepowerCurve);
                    return Ok(result.StatusMessage);
                }
                else
                    return BadRequest(result.StatusMessage);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }



        [HttpPost("publish-draft/{PowerCurveID}")]
        public async Task<ActionResult> PublishPowerCurve( int PowerCurveID)
        {
            try
            {
                var result = await _powercurveservice.PublishPowerCurve(PowerCurveID, HttpContext);
                
                if (result.StatusCode == 200)
                {
                    return Ok(result.StatusMessage);
                }
                else
                    return StatusCode(StatusCodes.Status406NotAcceptable, new { message = result.StatusMessage });
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }

        /// <summary>
        /// Duplicate the Power Curve.
        /// </summary>
        /// <param name="PowerCurveID"></param>
        /// <returns></returns>

        [HttpPost("duplicate/{PowerCurveID}")]
        public async Task<ActionResult> DuplicatePowerCurve(int PowerCurveID)
        {
            try
            {
                var result = await _powercurveservice.DuplicatePowerCurve(PowerCurveID, HttpContext);
                if (result.StatusCode == 200)
                {
                    return Ok(result.StatusMessage);
                }
                else
                    return StatusCode(StatusCodes.Status406NotAcceptable, new { message = result.StatusMessage });
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }



    }

}