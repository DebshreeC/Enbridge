﻿using Azure.Core;
using BOLTAPIServices.Attributes;
using BOLTAPIServices.DTO;
using BOLTAPIServices.Models;
using BOLTAPIServices.Models.DRA;
using BOLTAPIServices.Models.PowerCurves;
using BOLTAPIServices.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Attributes;
using Microsoft.OData;
using System.Linq;
using System.Net;
using System.Net.WebSockets;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace BOLTAPIServices.Controllers
{
   
    [ODataRouteComponent("odata")]
    [ApiController]
    [Route("api/DRA")]
    public class DRAController : ControllerBase
    {
        private readonly DRAService? _DRAservice;
        private readonly ILogger<ControllerBase>? _logger;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="DRAservice"></param>
        /// <param name="logger"></param>
        public DRAController(DRAService DRAservice, ILogger<ControllerBase> logger)
        {
            try
            {
                _DRAservice = DRAservice;
                _logger = logger;
            }
            catch (Exception ex)
            {
                // Log the error details
                //  logger.LogError($"ODataException: {ex.Message}");
                logger.LogError($"Stack Trace: {ex.StackTrace}");
            }
        }


        /// <summary>
        /// create DRA draft
        /// </summary>
        /// <param name="draftDRA"></param>
        /// <returns></returns>
        [HttpPost("create")]
        public async Task<IActionResult> CreateDRADraft([FromBody] DraftDRA draftDRA)
        {
            if (draftDRA == null)
            {
                return BadRequest("Invalid data.");

            }
            if (draftDRA.data.line == null || draftDRA.data.line.Length == 0)
            {
                return BadRequest("line field is required.");
            }

            var (result, statusCode) = await _DRAservice.CreateDRADraft(draftDRA, HttpContext);
            //Calling  the service method...................
            if (statusCode == 201)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result.ToString());
            }
        }

        /// <summary>
        ///  To  duplicate the DRA
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>

        [HttpPost("duplicate/{DRASummaryID}")]
        public async Task<ActionResult> DuplicateDRA(int DRASummaryID)
        {
            try
            {
                var result = await _DRAservice.DuplicateDRA(DRASummaryID, HttpContext);
                if (result.StatusCode == 200)
                {
                    return Ok(result.StatusMessage);
                }
                else
                    return StatusCode(StatusCodes.Status406NotAcceptable, new { message = result.StatusMessage });
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }

        /// <summary>
        /// Get DRA Cost details
        /// </summary>
        /// <returns></returns>
        [HttpGet("dra-cost")]
        [CustomEnableQuery]
        public async Task<ActionResult<DRACostResponse>> GetDRACost()
        {
            if (_DRAservice == null)
            {
                return Problem("DRACostService is not initialized.");
            }
            try
            {
                var items = await _DRAservice.ViewDRACost();
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }


        /// <summary>
        /// Get DRA FluidGroup details
        /// </summary>
        /// <returns></returns>
        [HttpGet("fluid-groups")]
        [CustomEnableQuery]
        public async Task<ActionResult<DRAfluidgroupMeta>> GetDRAfluidgroup()
        {
            if (_DRAservice == null)
            {
                return Problem("DRAfluidgroupService is not initialized.");
            }

            try
            {
                var items = await _DRAservice.ViewDRAfluidgroup();
                // Create the response object
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }

/// <summary>
/// Get  DRA Summaruy
/// </summary>
/// <returns></returns>

        [HttpGet]
        [CustomEnableQuery] // Use OData's query processing.
        public async Task<IQueryable<DRADTO>> GetDRA()
        {
          
            if (_DRAservice == null)
            {
                return (IQueryable<DRADTO>)Problem("DRAService is not initialized.");
            }

            try
            {
                return await _DRAservice.ViewDRAAsync();
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return (IQueryable<DRADTO>)Problem(ex.Message);
            }
        }

        /// <summary>
        /// Get DRA Detail
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>
        [HttpGet("detail/{DRASummaryID}")]
        [CustomEnableQuery]
        public async Task<ActionResult<IEnumerable<RootDRADetail>>> GetDRADetail(int DRASummaryID)
        {
            if (_DRAservice == null)
            {
                return Problem("DRA Service is not initialized.");
            }

            try
            {
                var result = await _DRAservice.GetDRADetail(DRASummaryID);
                // Create the response object
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }
        }


        /// <summary>
        /// Update DRA Summary
        /// </summary>
        /// <param name="draftDRA"></param>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>
        [HttpPatch("update")]
        public async Task<ActionResult> UpdateDRASummaryDraft([FromBody] UpdateDRADraft draftDRA)
        {

            if (_DRAservice == null)
            {
                return Problem("DRAService is not initialized.");
            }

            if (draftDRA == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {
                
               var result = await _DRAservice.UpdateDRASummaryDraft(draftDRA, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 201)
                {
                    return Ok(new { wasSuccessful = true, message = "Data updated successfully" });
                }
                else
                    return BadRequest(new { wasSuccessful = false, message = result.StatusMessage });

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }

        /// <summary>
        /// Update DRA  Detail
        /// </summary>
        /// <param name="dRADetailDraft"></param>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>
        [HttpPatch("detail/{DRASummaryID}")]
        public async Task<ActionResult> UpdateDRADetailDraft([FromBody] UpdateDRADetailDraft dRADetailDraft, int DRASummaryID)
        {

            if (_DRAservice == null)
            {
                return Problem("DRAService is not initialized.");
            }

            if (dRADetailDraft == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {

                var result = await _DRAservice.UpdateDRADetailDraft(dRADetailDraft, DRASummaryID, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 201)
                {
                    return Ok( new { wasSuccessful = true, message = "Data updated successfully" });
                }
                else
                    return BadRequest(new { wasSuccessful = false, message = result.StatusMessage });

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }


        /// <summary>
        /// To delete the DRA
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>

        [HttpDelete("delete/{DRASummaryID}")]
        public async Task<ActionResult> DeleteDRA(int DRASummaryID)
        {
            if (_DRAservice == null)
            {
                return Problem("DRAService is not initialized.");
            }
            try
            {
                var (result, statusCode) = await _DRAservice.DeleteDRA(DRASummaryID);
                if (statusCode == 200)
                {
                    return Ok(new { wasSuccessful = true, message = result });
                }
                else if (statusCode == 400)
                {
                    return BadRequest(new { wasSuccessful = false, message = result });
                }
                else
                {
                    return NotFound(new { wasSuccessful = false, message = result, DRASummaryID = DRASummaryID });
                }

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }


        /// <summary>
        /// Mark favourite
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>

        [HttpPut("mark-favourite/{DRASummaryID}")]
        public async Task<ActionResult> MarkFavourite(int DRASummaryID)
        {
            if (_DRAservice == null)
            {
                return Problem("DRA Service is not initialized.");
            }
            try
            {
                var (result, statusCode) =  await _DRAservice.MarkFavouriteAsync(DRASummaryID);


                if (result == null)
                {
                    return Problem(new { Message = "DRA not found", DRASummaryID = DRASummaryID }.ToString(), HttpStatusCode.NotModified.ToString());
                }
                return StatusCode((int)HttpStatusCode.Accepted, result);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message, HttpStatusCode.NotModified.ToString());
            }

        }



        [HttpPatch("fluid-groups/{line}")]
        public async Task<ActionResult> UpdateFluidGroup([FromBody] UpdateFluidGroupDraft FluidGroupDraft, string line)
        {

            if (_DRAservice == null)
            {
                return Problem("DRAService is not initialized.");
            }

            if (FluidGroupDraft == null)
            {
                return BadRequest("Invalid data.");

            }

            try
            {

                var result = await _DRAservice.UpdateFluidGroup(FluidGroupDraft, line, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 201)
                {


                    return Ok("Data updated successfully");
                }
                else
                    return BadRequest(result.StatusMessage);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }



        /// <summary>
        /// archive DRA
        /// </summary>
        /// <param name="DRASummaryID"></param>
        /// <returns></returns>

        [HttpPut("archive/{DRASummaryID}")]
        public async Task<ActionResult> ArchiveDRA(int DRASummaryID)
        {
            if (_DRAservice == null)
            {
                return Problem("DRA Service is not initialized.");
            }
            try
            {
                var (result, statusCode) = await _DRAservice.ArchiveDRAAsync(DRASummaryID, HttpContext);


                if (result == null)
                {
                    // return Problem(new { Message = "DRA not found", DRASummaryID = DRASummaryID }.ToString(), HttpStatusCode.NotModified.ToString());
                    return BadRequest(new { wasSuccessful = false, message = "DRA not found" });

                }
                else
                {
                    if (statusCode == 400)
                    {

                        return BadRequest(new { wasSuccessful = false, message = result });
                    }

                    else

                        return Ok(new { wasSuccessful = true, message = result });
                }
			
		}
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message, HttpStatusCode.NotModified.ToString());
            }

        }



        [HttpPost("publish/{DRASummaryID}")]
        public async Task<ActionResult> PublishDRA(int DRASummaryID)
        {
            try
            {
                var result = await _DRAservice.PublishDRA(DRASummaryID, HttpContext);

                if (result.StatusCode == 200)
                {
					return Ok(new { wasSuccessful = true, message = result.StatusMessage });
				}
                else if(result.StatusCode == 202)
                {
                    return Accepted(new {wasSuccessful = false, message = result.StatusMessage });
                }
				else
					return BadRequest(new { wasSuccessful = false, message = result.StatusMessage });

			}
			catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }




        [HttpPatch("dra-cost/update/overwritecost")]
        public async Task<ActionResult> UpdateDRACost([FromBody] UpdateDRACostRequest dRACostRequest)
        {

            if (_DRAservice == null)
            {
                return Problem("DRAService is not initialized.");
            }

           
            // Validate input

            if (dRACostRequest?.data == null || dRACostRequest.data.Count > 2|| dRACostRequest.data.Count==0 )
            {
                return BadRequest("The request must contain either one or two records for 'LIGHT' and 'HEAVY'.");

            }

            // Validate DRA types
            var validTypes = new[] { "LIGHT", "HEAVY" };
            if (dRACostRequest.data.Select(d => d.DRAType.ToUpper()).Distinct().Except(validTypes).Any())
            {
                return BadRequest("Invalid DRAType. Only 'LIGHT' and 'HEAVY' are allowed.");
            }


            try
            {

                var result = await _DRAservice.UpdateDRACost(dRACostRequest, HttpContext);
                // return new StatusCodeResult((int)HttpStatusCode.Created);
                if (result.StatusCode == 201)
                {


                    return Ok("Data updated successfully");
                }
                else
                    return BadRequest(result.StatusMessage);

            }
            catch (Exception ex)
            {
                _logger?.LogError(GetType().Name, ex);
                return Problem(ex.Message);
            }

        }






    }
}
