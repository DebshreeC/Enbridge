﻿namespace BOLTAPIServices.Settings
{

    public class PaginationSettings
    {
        public int PageSize { get; set; }
    }
}
