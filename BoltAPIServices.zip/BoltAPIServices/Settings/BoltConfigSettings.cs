﻿namespace BOLTAPIServices.Settings
{
    public class BoltConfigSettings
    {
        public NTLMSettings NTLM { get; set; }
        public PaginationSettings Pagination { get; set; }

    

    }
}
