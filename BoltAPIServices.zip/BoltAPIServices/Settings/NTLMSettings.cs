﻿namespace BOLTAPIServices.Settings
{
    public class NTLMSettings
    {
        public string BaseUrl { get; set; }
        public string Domain { get; set; }
    }
}
