﻿using AutoMapper;
using BOLTAPIServices.Models;
using BOLTAPIServices.Models.PowerCurves;

namespace BOLTAPIServices.DTO
{
    public class AutoMapperProfile : Profile
    {

        public AutoMapperProfile()
        {
            
            CreateMap<ViewPowerCurveRegion, PowerCurveRegionDTO>();
            CreateMap<ViewPowerCurveRegion, MetaPowerCurveDTO>();
            CreateMap<DRASummary,DRASummaryDTO>();
            CreateMap<DRASummary,DRADTO>();
        }
    }
}
