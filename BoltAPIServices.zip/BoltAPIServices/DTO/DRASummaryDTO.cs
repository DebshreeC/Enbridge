﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.DTO
{
    public class DRASummaryDTO

    {
        public string? line { get; set; }

        public string? region { get; set; }
        public DateTime? applicableDateStart { get; set; }
        public DateTime? applicableDateEnd { get; set; }
        public string? title { get; set; }
        public int? heavyPercentage { get; set; }
        public int? lightPercentage { get; set; }



    }



}
