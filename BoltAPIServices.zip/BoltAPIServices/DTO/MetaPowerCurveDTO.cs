﻿namespace BOLTAPIServices.DTO
{
    public class  MetaPowerCurveDTO
    {
        public int PowerCurveID { get; set; }
        public string? Line { get; set; }
        public string? Region { get; set; }
      /// <summary>
      ///  public string? Title { get; set; }
      /// </summary>
        public DateTime? ApplicableDateStart { get; set; }
        public DateTime? ApplicableDateEnd { get; set; }

        public Guid? UpdatedByUserGUID { get; set; }

        public string? UpdatedByUserId { get; set; }
        public string? UpdatedByUsername { get; set; }
       

    }
}
