﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BOLTAPIServices.DTO
{
    public class DRADTO
    {
        [Key]
        public int draSummaryID { get; set; }
        public string? line { get; set; }
        public string? region { get; set; }


        public DateTime? applicableDateStart { get; set; }
        public DateTime? applicableDateEnd { get; set; }
        public string? title { get; set; }
       

        public Guid? updatedByUserGUID { get; set; }


        public string? updatedByUserId { get; set; }


        public string? updatedByUserName { get; set; }

        public DateTime? updatedDateTime { get; set; }
        // public bool isFavourite {  get; set; }

        public string? status { get; set; }


        public bool? isFavourite { get; set; }
        public int? regionOrder { get; set; }

        public int? lineOrder { get; set; }
      

    }
    

}
