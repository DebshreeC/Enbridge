﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BOLTAPIServices.DTO
{
    public class PowerCurveRegionDTO

    {
        public int PowerCurveID { get; set; }
        public string? Line { get; set; }
        public string? Region { get; set; }
        public string? Title { get; set; }
        public DateTime? ApplicableDateStart { get; set; }
        public DateTime? ApplicableDateEnd { get; set; }
        public string? UpdatedByUserId { get; set; }
        public string? UpdatedByUsername { get; set; }
        public Guid? UpdatedByUserGUID { get; set; }
        public DateTime? LastUpdateDateTime { get; set; }
        public bool IsFavourite { get; set; }
        public string? Status { get; set; }


        public int? regionOrder { get; set; }
        public int? lineOrder { get; set; }


    }



}
