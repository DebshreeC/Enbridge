﻿ALTER TABLE testing_table
DROP COLUMN line;
