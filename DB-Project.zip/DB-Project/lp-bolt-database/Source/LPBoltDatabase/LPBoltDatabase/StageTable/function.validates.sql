﻿CREATE FUNCTION [STAGE].[ValidateDates](
    @HistoricDates VARCHAR(MAX),
    @ApplicableDateStart DATETIME,
    @ApplicableDateEnd DATETIME,
	@flag bit 
)
RETURNS @ReturnStatus TABLE (
    StatusCode INT,
    StatusMessage NVARCHAR(255)
)
AS
 /*Declare @HistoricDates VARCHAR(MAX),
    @ApplicableDateStart DATETIME,
    @ApplicableDateEnd DATETIME,
	@flag bit ;
Declare	@ReturnStatus TABLE (
    StatusCode INT,
    StatusMessage NVARCHAR(255)
);


SEt @HistoricDates ='[{"startDate":"2023-01-01T00:00:00","endDate":"2023-06-30T00:00:00"},{"startDate":"2023-07-01T00:00:00","endDate":"2023-12-30T00:00:00"}]';
set @ApplicableDateStart='Dec  1 2024 12:00AM';
set @ApplicableDateEnd='Dec 31 2024 12:00AM';
set @flag=1;*/

BEGIN
    DECLARE @StatusCode INT = 200;
    DECLARE @StatusMessage NVARCHAR(255) = 'Success';

    -- Temporary table to hold parsed historic dates
    DECLARE @HistoricDatesTable TABLE (StartDate DATETIME, EndDate DATETIME);

    -- Parse and insert historic dates into the table variable
    IF @HistoricDates IS NULL OR @HistoricDates = '[]'
    BEGIN
        INSERT INTO @HistoricDatesTable (StartDate, EndDate) VALUES (NULL, NULL);
    END
    ELSE
    BEGIN
        INSERT INTO @HistoricDatesTable (StartDate, EndDate)
        SELECT 
            TRY_CAST(JSON_VALUE(value, '$.startDate') AS DATETIME) AS StartDate,
            TRY_CAST(JSON_VALUE(value, '$.endDate') AS DATETIME) AS EndDate
        FROM OPENJSON(@HistoricDates);
    END

	--Select * from @HistoricDatesTable;
	 IF @HistoricDates IS NOT NULL OR @HistoricDates != '[]'
    BEGIN
    -- Validate historic dates within last two years and not in future
    IF EXISTS (
        SELECT 1
        FROM @HistoricDatesTable hd
        --WHERE hd.StartDate IS NULL 
        --   OR hd.EndDate IS NULL 
           Where hd.StartDate < DATEADD(YEAR, -2, GETDATE())
           OR hd.EndDate < DATEADD(YEAR, -2, GETDATE())
           OR hd.StartDate > GETDATE()
           OR hd.EndDate > GETDATE()
    )
    BEGIN
        SET @StatusCode = 400;
        SET @StatusMessage = 'Historical dates must be within the last 2 years and cannot be in the future.';
      
        -- Return error
        INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
        VALUES (@StatusCode, @StatusMessage);
        RETURN;
    END


	-- Validate historic dates: Check for duplicates and date range
		IF EXISTS (
			SELECT 1 
			FROM @HistoricDatesTable hd
			GROUP BY StartDate, EndDate
			HAVING COUNT(*) > 1
			)
		BEGIN
			--RAISERROR('Duplicate historic dates found.', 16, 1);
			SET @StatusCode = 400;-- Indicate Bad Data
				SET @StatusMessage = 'Duplicate historic dates found.';
				INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
				VALUES (@StatusCode, @StatusMessage);
			RETURN;
		END
	END

	IF  @flag=1 and (  @HistoricDates IS NULL OR @HistoricDates = '[]')
	BEGIN
	 SET @StatusCode = 400;
        SET @StatusMessage = 'Historical dates cannot be blank.';
      
        -- Return error
        INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
        VALUES (@StatusCode, @StatusMessage);
        RETURN;
	END


    -- Validate applicable dates
    IF @ApplicableDateStart < GETDATE()
    BEGIN
        SET @StatusCode = 400;
        SET @StatusMessage = 'ApplicableDateStart must be greater than the current date.';

        INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
        VALUES (@StatusCode, @StatusMessage);
        RETURN;
    END

    IF @ApplicableDateEnd < @ApplicableDateStart
    BEGIN
        SET @StatusCode = 400;
        SET @StatusMessage = 'ApplicableDateEnd must be greater than ApplicableDateStart.';


        INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
        VALUES (@StatusCode, @StatusMessage);
        RETURN;
    END



    -- If all validations pass, return success
    INSERT INTO @ReturnStatus (StatusCode, StatusMessage)
    VALUES (@StatusCode, @StatusMessage);

    RETURN;
END;
GO