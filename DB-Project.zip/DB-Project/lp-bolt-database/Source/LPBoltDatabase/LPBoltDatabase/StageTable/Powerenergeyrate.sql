﻿CREATE TABLE STAGE.PowerEnergyRate (
    StationID INT IDENTITY(1,1) NOT NULL,   -- StationID as an auto-incrementing Identity column
    Region VARCHAR(255) NOT NULL,
    Line VARCHAR(255) NOT NULL,
    Station VARCHAR(255) NOT NULL,
    District INT NOT NULL,
    Year INT NOT NULL,
    Month INT NOT NULL,
    MillRate DECIMAL(18, 10) NOT NULL,  
    Vlookup VARCHAR(255) NOT NULL,
    PRIMARY KEY (StationID)
);
