﻿CREATE PROCEDURE [STAGE].[usp_UpdatePowerCurveDraft] 
@PowerCurveId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

AS
/*Declare @PowerCurveId int,@DraftPowerCurveData NVARCHAR(max),@StatusMessage NVARCHAR(4000),@StatusCode INT 
set @PowerCurveId=167;
set @DraftPowerCurveData ='{
    "data": {
        "line":"1",
        "title":"Titlee for Testing line 1 via SP",
        "applicableDateStart":"2024-11-07T00:00:00",
        "applicableDateEnd":"2024-11-30T00:00:00",
        "historicDates":[
            {"startDate":"2023-01-01",
            "endDate": "2023-06-30"
            },
            {"startDate":"2023-07-01",
            "endDate": "2023-12-31"
            }
        ]
    }
}';*/
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION

        DECLARE @Title NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.title');
        DECLARE @ApplicableDateStart DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
        DECLARE @ApplicableDateEnd DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
        DECLARE @HistoricDates NVARCHAR(MAX),@mindate varchar(20), @maxdate varchar(20);

        SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
        
        -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM [STAGE].[PowerCurve] WHERE powerCurveID = @PowerCurveId AND status = 'Draft') < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END

		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
		FROM [STAGE].[ValidateDates](@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,0);
		If(@StatusCode=400)
		BEGIN
			ROLLBACK TRANSACTION;
		Return;
		END


        -- Temporary table to hold historic dates
        CREATE TABLE #HistoricDates (StartDate DATETIME, EndDate DATETIME);

        IF @HistoricDates IS NULL OR @HistoricDates = '[]'
        BEGIN
            INSERT INTO #HistoricDates (StartDate, EndDate) VALUES (NULL, NULL);
        END
        ELSE
        BEGIN
            INSERT INTO #HistoricDates (StartDate, EndDate)
            SELECT 
                TRY_CAST(JSON_VALUE(value, '$.startDate') AS DATETIME) AS StartDate,
                TRY_CAST(JSON_VALUE(value, '$.endDate') AS DATETIME) AS EndDate
            FROM OPENJSON(@HistoricDates) AS HistoricDates;
        END
		
		select @mindate = Cast(min(StartDate) as varchar(20)), @maxdate = cast(max(EndDate) as varchar(20)) from #HistoricDates
        -- Update PowerCurve
		UPDATE [STAGE].[PowerCurve]
        SET 
            [title] = @Title,
            [applicableDateStart] = @ApplicableDateStart,
            [applicableDateEnd] = @ApplicableDateEnd,
            [historicalDates] =  '' + @mindate + ',' + @maxdate +'' ,
			[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
		
	--		 FROM [STAGE].[PowerCurve]
        WHERE powerCurveID = @PowerCurveId;

     
		UPDATE PD
			SET 
				PD.applicableDateRangeStart = @ApplicableDateStart,
				PD.applicableDateRangeEnd = @ApplicableDateEnd,
				PD.historicalDateRange=	REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),

					--PD.historicDateRangeStart = TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 2)), 
					--PD.historicDateRangeEnd = TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 1)), 
					PD.lastUpdatedDateTime = GETDATE(),
					PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
				FROM [STAGE].[PowerCurveDetails] PD
				INNER JOIN [STAGE].PowerCurve PC ON PD.powerCurveID = PC.powerCurveID
				INNER JOIN [STAGE].LineStationReference LR ON PC.line = LR.line
				WHERE PC.STATUS = 'Draft' AND PD.powerCurveID = @PowerCurveId;

		UPDATE PD
		SET 
			PD.applicableDateRangeStart = '1900-01-01',
			PD.applicableDateRangeEnd = '1900-01-01',
			PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
		FROM [STAGE].[PowerCurveDetails] PD
		JOIN (
			SELECT line, station
			FROM [STAGE].[PowerCurveDetails]
			GROUP BY line, station
			HAVING COUNT(*) > 1
		) AS Subquery
		ON PD.line = Subquery.line AND PD.station = Subquery.station;

		



  /* DELETE FROM PowerCurveDetails WHERE powerCurveID = @PowerCurveId AND status = 'Draft';
        INSERT INTO [STAGE].[PowerCurveDetails] (
            [powerCurveID], [line], [station], [applicableDateRangeStart],
            [applicableDateRangeEnd], [historicDateRangeStart], [historicDateRangeEnd],
            [lastUpdated], [status]
        )
        SELECT PC.powerCurveID, LR.Line, LR.station, 
               @ApplicableDateStart, @ApplicableDateEnd,
               TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 2)), 
               TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 1)), 
               GETDATE(), 'Draft'
        FROM PowerCurve PC
        INNER JOIN LineStationReference LR ON PC.line = LR.line
        WHERE PC.STATUS = 'Draft' AND PC.title = @Title;*/







        SET @StatusCode = 201; 
        SET @StatusMessage = 'Draft updated successfully.';

        -- Clean up temporary table
        DROP TABLE #HistoricDates;

        COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
GO