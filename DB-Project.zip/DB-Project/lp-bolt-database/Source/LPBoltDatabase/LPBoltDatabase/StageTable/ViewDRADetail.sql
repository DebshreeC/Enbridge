﻿CREATE VIEW [STAGE].[viewDRADetail] AS
Select   D.draSummaryID,station,publishedFlowRatem3hr,referenceUsageLbHr,userGivenUsageLbHr,draType
from
[STAGE].DRASummary S 
inner join [STAGE].DRA_Details D on S.draSummaryID=D.draSummaryID
GO