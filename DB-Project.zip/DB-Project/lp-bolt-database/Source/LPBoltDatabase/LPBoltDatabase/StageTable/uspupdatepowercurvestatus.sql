﻿CREATE PROCEDURE [STAGE].[usp_UpdatePowerCurveStatus] 
AS
BEGIN
	BEGIN TRY
		
			
						BEGIN
							DECLARE @CompareDate DATE; 
							SET @CompareDate =  GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Mountain Standard Time';


									UPDATE stage.PowerCurve
									SET STATUS = 'ARCHIVED',
									lastUpdateDateTime=@CompareDAte
									WHERE applicableDateEnd < @CompareDAte
										AND STATUS = 'PUBLISHED';

						END	
			
						
		
	END TRY

	BEGIN CATCH
		-- Handle the error
		ROLLBACK TRANSACTION

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
