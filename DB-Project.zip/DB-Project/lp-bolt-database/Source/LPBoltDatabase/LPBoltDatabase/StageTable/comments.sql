﻿CREATE TABLE [STAGE].[Comments](
	[commentID] [int] IDENTITY(1,1) NOT NULL,
	[ref] [varchar](50) NOT NULL,
	[refID] [int] NOT NULL,
	[comment] [varchar](255) NOT NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[lastUpdateDateTime] [datetime2](7) NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [varchar](255) NULL
) ON [PRIMARY]
GO