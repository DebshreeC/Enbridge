﻿ALTER TABLE [STAGE].[PowerCurveDetails]
ALTER COLUMN historicDateRangeStart VARCHAR(max);