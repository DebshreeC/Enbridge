﻿CREATE TABLE [STAGE].[DRASummary](
	[draSummaryID] [int] IDENTITY(1,1) NOT NULL,
	[line] [varchar](255) NULL,
	[applicableDateStart] [datetime2](7) NOT NULL,
	[applicableDateEnd] [datetime2](7) NOT NULL,
	[title] [varchar](255) NULL,
	[heavyPercentage] [decimal](5, 2) NULL,
	[lightPercentage] [decimal](5, 2) NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[updatedDateTime] [datetime2](7) NULL,
	[createdDateTime] [datetime2](7) NULL,
	[status] [varchar](255) NULL
) ON [PRIMARY]
GO
