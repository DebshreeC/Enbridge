﻿CREATE PROCEDURE [STAGE].[usp_PublishFlowRateTransactions] 
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier
AS
BEGIN
	BEGIN TRY
		Begin
			Begin Transaction
			 IF((select count(1) from [STAGE].[DraftFlowRates]) >0 )
			 BEGIN
				Declare @historyid int;
				Select @historyid = max(historyID) + 1 from [STAGE].HistoricFlowRates

				INSERT INTO [STAGE].[HistoricFlowRates]
				([historyID],[publishedID],[region],[line],[publishedFlowRatem3hr],[publishedFlowRateUpdatedDateTime],[updatedByUserID]
				,[updatedByUserGUID],[updatedByUserName],[refFlowRateUpdatedDateTime])
				SELECT @historyid, P.[ID],P.[Region],P.[Line],[publishedFlowRatem3hr],[publishedFlowRateUpdatedDateTime]
					   ,[updatedbyUserId],[updatedbyUserGUID],[updatedbyUserName],R.refFlowRateUpdatedDateTime FROM [STAGE].[PublishedFlowRates] P
				LEFT JOIN [STAGE].ReferenceFlowRates R on R.Line = P.Line and R.Region = P.Region and R.refFlowRatem3hr = P.publishedFlowRatem3hr ;

				TRUNCATE Table [STAGE].[PublishedFlowRates];

				INSERT INTO [STAGE].[PublishedFlowRates]
				([Region],[line],[publishedFlowRatem3hr],[publishedFlowRateUpdatedDateTime],[updatedByUserID]
				,[updatedByUserGUID],[updatedByUserName])
				SELECT [Region],[Line],[draftFlowRatem3hr],GetDate(),COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) FROM [STAGE].[DraftFlowRates] ;
				
				TRUNCATE Table [STAGE].[DraftFlowRates];
				END

			Commit Transaction
		End
		
		
	END TRY
	BEGIN CATCH
		-- Handle the error
		Rollback Transaction
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
		VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
	


GO