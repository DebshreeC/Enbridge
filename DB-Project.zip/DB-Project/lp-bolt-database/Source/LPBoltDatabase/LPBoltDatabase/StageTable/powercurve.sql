﻿CREATE TABLE [STAGE].[PowerCurve](
	[powerCurveID] [int] IDENTITY(1,1) NOT NULL,
	[line] [varchar](255) NULL,
	[title] [varchar](255) NULL,
	[applicableDateStart] [datetime2](7) NOT NULL,
	[applicableDateEnd] [datetime2](7) NOT NULL,
	[historicalDates] [varchar](255) NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[lastUpdateDateTime] [datetime2](7) NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [varchar](255) NULL,
	[isFavourite] [bit] NULL,
	[status] [varchar](255) NULL,
 CONSTRAINT [PK_PowerCurve] PRIMARY KEY CLUSTERED 
(
	[powerCurveID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
