﻿CREATE TABLE [STAGE].[TotalStationPowerDRACosts](
	[Line] [nvarchar](50) NULL,
	[Station] [nvarchar](50) NULL,
	[applicableDate] [date] NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[PowerConsumptionkW] [float] NULL,
	[PowerEnergyRateCADPerkW] [float] NULL,
	[PowerConsumptionCostCADperday] [float] NULL,
	[DRAConsumptionLightlbPerhr] [float] NULL,
	[DRAConsumptionHeavylbPerhr] [float] NULL,
	[DRACostCADPerday] [float] NULL
) ON [PRIMARY]
GO