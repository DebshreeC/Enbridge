﻿CREATE VIEW [STAGE].[viewHistoryMetaFlowRates] AS
SELECT 
	p.[historyID] ,
    MAX(R.refFlowRateUpdatedDateTime) AS refFlowRateUpdatedDateTime,
    MAX(D.draftFlowRateUpdatedDateTime) AS userFlowRateUpdatedDateTime,
    MAX(P.publishedFlowRateUpdatedDateTime) AS publishedFlowRateUpdatedDateTime,
    MAX(P.updatedbyUserId) AS updatedbyUserId,
    MAX(P.updatedbyUserName) AS updatedbyUserName, 
    MAX(P.updatedbyUserGUID) AS updatedbyUserGUID
FROM 
    [STAGE].[HistoricFlowRates] as P
LEFT OUTER JOIN 
    [STAGE].[ReferenceFlowRates] AS R ON R.Line = P.Line and R.Region = P.Region and R.refFlowRatem3hr=p.publishedFlowRatem3hr
LEFT OUTER JOIN 
    [STAGE].[DraftFlowRates] AS D ON R.Line = D.Line and R.Region = D.Region and R.refFlowRatem3hr=D.draftFlowRatem3hr

	group by p.historyID;
GO