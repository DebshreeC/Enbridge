﻿CREATE PROCEDURE [STAGE].[UpsertDraftFlowRates]
    @DraftFlowRateData NVARCHAR(MAX)
AS
BEGIN
  BEGIN TRY
		-- Parse the JSON data into a table
		DECLARE @TempTable TABLE (
			Region VARCHAR(255),
			Line VARCHAR(255),
			draftFlowRatem3hr INT,
			draftFlowRateUpdatedDateTime DATETIME2(7)
		);
		BEGIN TRANSACTION
		INSERT INTO @TempTable ( Line, draftFlowRatem3hr, draftFlowRateUpdatedDateTime)
		SELECT 
			---JSON_VALUE(value, '$.region') AS Region,
			JSON_VALUE(value, '$.line') AS Line,
			JSON_VALUE(value, '$.draftFlowRatem3hr') AS draftFlowRatem3hr,
			GETDATE() AS draftFlowRateUpdatedDateTime
		FROM OPENJSON(@DraftFlowRateData, '$.Data') AS value;

		update T   set Region=LR.region
		from [STAGE].[LineStationReference]  LR inner join @TempTable as T
		on  LR.line=T.line


		DELETE target FROM [STAGE].[DraftFlowRates] as target 
		JOIN @TempTable as Source on target.Line = source.line and target.Region=source.Region;
		
		INSERT INTO [STAGE].[DraftFlowRates] (Region, Line, draftFlowRatem3hr, draftFlowRateUpdatedDateTime)
			SELECT region, line, draftFlowRatem3hr,draftFlowRateUpdatedDateTime from @TempTable;
		COMMIT TRANSACTION	
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		ROLLBACK TRANSACTION
		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
		VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END
GO