﻿CREATE PROCEDURE [STAGE].[usp_AddStationPowerCurveDraft] 
@PowerCurveId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

AS
/*Declare @PowerCurveId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) ,
@StatusCode INT ,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

set @DraftPowerCurveData= N'{"data":{"station":"BB","applicableDateStart":"2024-12-01T00:00:00","applicableDateEnd":"2024-12-31T00:00:00","historicDates":[{"startDate":"2023-01-01T00:00:00","endDate":"2023-06-30T00:00:00"},{"startDate":"2023-07-01T00:00:00","endDate":"2023-12-30T00:00:00"}]}}';
set @PowerCurveId=197;
set @username='swami siva'
set @userid = '1234rt'*/

BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @Station NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.station');
        DECLARE @ApplicableDateStart DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
        DECLARE @ApplicableDateEnd DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
        DECLARE @HistoricDates NVARCHAR(MAX);

        SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
        
        -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM PowerCurve WHERE powerCurveID = @PowerCurveId AND status = 'Draft') < 1
        BEGIN
            SET @StatusCode = 400; 
			SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            COMMIT TRANSACTION;
            RETURN;
        END

		
		  -- Validate Station
        IF (SELECT COUNT(1) FROM LineStationReference line INNER JOIN POWERCURVE pwr on pwr.line = line.line and pwr.powerCurveID=@PowerCurveId WHERE line.station = @Station ) < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid Station.';
            INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            COMMIT TRANSACTION;
            RETURN;
        END
		print @HistoricDates;
		print @ApplicableDateStart;
		print @ApplicableDateEnd;
		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
		FROM [STAGE].ValidateDates(@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,1); ---passing the flag value 1
		If(@StatusCode=400)
		BEGIN
		COMMIT transaction;
		Return;
		END
		--print @Station;
 
        INSERT INTO [STAGE].[PowerCurveDetails] (
            [powerCurveID], [line], [station], [applicableDateRangeStart],
            [applicableDateRangeEnd], [historicalDateRange],
            [lastUpdatedDatetime], [status],
			[createdByUserId],[createdByUserGUID],[createdByUserName],
			UpdatedByUserId,[updatedByUserGUID],[updatedByUserName])
        SELECT PC.powerCurveID, LR.Line, @Station,
               @ApplicableDateStart, @ApplicableDateEnd,
			   	REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),
				GETDATE(), 'New',COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()),
				COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 
        FROM PowerCurve PC
        INNER JOIN LineStationReference LR ON PC.line = LR.line  and LR.station=@Station
        WHERE PC.STATUS = 'Draft' and PC.powerCurveID=@PowerCurveId

		declare @PowerCurveDetailID as int 
		set @PowerCurveDetailID=SCOPE_IDENTITY();
		--print @PowerCurveDetailID;


        SET @StatusCode = 201; 
        SET @StatusMessage = '{"powercurveDetailID": "' + Cast (@PowerCurveDetailID as varchar(50)) + '","status": "success"} ' ;

        -- Clean up temporary table
       -- print @StatusMessage;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
GO