﻿CREATE TABLE [STAGE].[DRA_Cost](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DRAType] [varchar](255) NULL,
	[density] [float] NULL,
	[costPerGalCAD] [float] NULL,
	[costPerLbCAD] [float] NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[UpdatedDateTime] [datetime2](7) NOT NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdDateTime] [datetime2](7) NULL
) ON [PRIMARY]
GO