﻿CREATE TABLE [STAGE].[DRA_Reference](
	[Line] [varchar](10) NULL,
	[Station] [varchar](10) NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[FluidGroup] [int] NULL,
	[DRARate] [decimal](18, 9) NULL,
	[DRAType] [varchar](10) NULL,
	[ID] [int] NULL,
	[FileDate] [datetime] NULL
) ON [PRIMARY]
GO