﻿CREATE PROCEDURE [STAGE].[usp_PublishPowerCurve] @PowercurveID INT
	,@StatusMessage NVARCHAR(4000) OUTPUT
	,@StatusCode INT OUTPUT
	,@username VARCHAR(255)
	,@userid VARCHAR(255)
	,@userguid UNIQUEIDENTIFIER
AS
BEGIN
	BEGIN TRY
		BEGIN
			BEGIN TRANSACTION

			--validate Power curveID
			IF EXISTS (
					SELECT 1
					FROM PowerCurve
					WHERE powerCurveID = @PowercurveID
					)
			BEGIN
				-- validate power curve status should be in 'Draft'
				IF EXISTS (
						SELECT 1
						FROM PowerCurve
						WHERE powerCurveID = @PowercurveID
							AND STATUS = 'Draft'
						)
				BEGIN
					DECLARE @Line AS VARCHAR(20);

					SELECT @Line = line
					FROM PowerCurve
					WHERE powerCurveID = @PowercurveID
						AND STATUS = 'Draft'

					---check if all stations from line ref are in PowerCurveDetail min 1 count and should be stauts=completed
					IF  EXISTS (
							SELECT station
							FROM [STAGE].[LineStationReference]
							WHERE line = @line
								AND station NOT IN (
									SELECT station
									FROM [STAGE].[PowerCurveDetails]
									WHERE powerCurveID = @PowercurveID
										AND STATUS = 'Completed'
										AND line = @Line
									)
							)
					BEGIN
					print 2;
						SET @StatusCode = 406;---Http Not accepted
						SET @StatusMessage = 'All station corresponding to line ''' + @Line + ''' not in PowerCurver details with completed status';
						Rollback Tran;
						Return;
					END
					ELSE
					BEGIN
						--check for each PowerCurveDetailID should have at least 3 flow rates present
						IF EXISTS (
								SELECT PowerCurveDetailID
								FROM [STAGE].[PowerCurveStationDetails]
								WHERE powerCurveID = @PowercurveID
								GROUP BY PowerCurveDetailID
								HAVING COUNT(DISTINCT flowRate) < 3
								)
						BEGIN
							SET @StatusCode = 406;---Http Not accepted
							SET @StatusMessage = 'All station do not have at least 3 flow rate';
							Rollback TRAN;
							RETURN;
						END
						ELSE
						BEGIN
							---To check if applicableDate in PowerCurve is in past
							IF EXISTS (
									SELECT 1
									FROM [STAGE].[PowerCurve]
									WHERE applicableDateEnd < GETDATE()
										AND powerCurveID = @PowercurveID
									)
							BEGIN
								SET @StatusCode = 406;---Http Not accepted
								SET @StatusMessage = 'Applicable date  belongs to past date';
								Rollback Tran;

								RETURN;
							END
							ELSE
							BEGIN
								--Validate  if applicableDate for any station in PowerCurveDetails with-in  applicableDate of PowerCurve 
								IF EXISTS (
										SELECT 1
										FROM [STAGE].[PowerCurveDetails] PCD
										INNER JOIN [STAGE].[PowerCurve] PC ON PCD.PowerCurveID = PC.PowerCurveID
											AND PC.powerCurveID = @PowercurveID
										WHERE PCD.applicableDateRangeEnd > PC.applicableDateEnd
											AND PCD.applicableDateRangeStart < PC.applicableDateStart
										)
								BEGIN
									SET @StatusCode = 406;---Http Not accepted
									SET @StatusMessage = 'Applicable date of PowerCurveDetails not in range of Applicable Dates of PowerCurve';
									Rollback TRAN;
									RETURN;
								END
								ELSE
								BEGIN
									-----find all published powercurves where applicableEndDate <= today and mark them as archive
									UPDATE [STAGE].[PowerCurve]
									SET STATUS = 'Archive'
									WHERE applicableDateEnd <= GETDATE()
										AND STATUS = 'Published';

									---find all published  powercurves where Period overlaps with current powerCurveId period and mark them as archive
									-- Find the period of the current power curve
									DECLARE @CurrentStartDate DATE;
									DECLARE @CurrentEndDate DATE;

									SELECT @CurrentStartDate = applicableDateStart
										,@CurrentEndDate = applicableDateEnd
									FROM [STAGE].[PowerCurve]
									WHERE PowerCurveID = @PowercurveID;

									-- Update overlapping published power curves to "archived" status
									UPDATE [STAGE].[PowerCurve]
									SET STATUS = 'archived'
									WHERE STATUS = 'published' -- Only consider published power curves
										AND PowerCurveID <> @PowercurveID -- Exclude the current power curve
										AND applicableDateEnd >= @CurrentStartDate -- Check for overlapping periods
										AND applicableDateStart <= @CurrentEndDate;

									---set status=PUBLISHE  where powerCurveId=x
									UPDATE [STAGE].[PowerCurve]
									SET STATUS = 'Published',
								    [updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
									[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
									[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()),
									lastUpdateDateTime= getdate()
									WHERE powerCurveID = @PowercurveID

									SET @StatusCode = 200;---Http  ok successfull
									SET @StatusMessage = 'Published Successfully.';
									COMMIT TRANSACTION
								END
							END
						END
					END
				END
				ELSE
				BEGIN
					SET @StatusCode = 406;---Http Not accepted
					SET @StatusMessage = 'Power Curve not in draft Status.';
					Rollback Tran;

					RETURN;
				END
			END
			ELSE
			BEGIN
				SET @StatusCode = 406;---Http Not accepted
				SET @StatusMessage = 'Invalid Power Curve Id.';
				Rollback tran;

				RETURN;
			END

			
		END
	END TRY

	BEGIN CATCH
		-- Handle the error
		ROLLBACK TRANSACTION

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO [STAGE].[ErrorLog] (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
GO