﻿CREATE VIEW [STAGE].[viewPowerCurveDetailForStation] AS
Select   PCD.station, PCD.PowerCurveDetailID, PC.powerCurveID,PC.line,
applicableDateRangeStart,
applicableDateRangeEnd,
  historicalDateRange,selectedCurveFitMethod,
 case  when (isnull(polynomialRSquare,0)=0) then -1  else     CAST(polynomialRSquare AS FLOAT) end AS polynomialRSquare,
 case  when (isnull(exponentialRSquare ,0)=0)  then -1 else  CAST(exponentialRSquare AS FLOAT) end AS exponentialRSquare,
 case  when (isnull (polynomialCalculatedA,0)=0) then -1  else CAST(polynomialCalculatedA AS FLOAT) end AS polynomialCalculatedA,
 case  when (isnull(polynomialCalculatedB ,0)=0) then -1  else CAST(polynomialCalculatedB AS FLOAT) end AS polynomialCalculatedB,
 case  when (isnull(polynomialCalculatedC ,0)=0) then -1  else CAST(polynomialCalculatedC AS FLOAT) end AS polynomialCalculatedC,
 case  when (isnull(exponentialCalculatedA ,0)=0) then -1  else CAST(exponentialCalculatedA AS FLOAT)end  AS exponentialCalculatedA,
 case  when (isnull(exponentialCalculatedB ,0)=0) then -1  else CAST(exponentialCalculatedB AS FLOAT)end  AS exponentialCalculatedB,
 case  when (isnull(userInputA ,0)=0) then -1  else CAST(userInputA AS FLOAT)  end userInputA,
 case  when (isnull(userInputB ,0)=0) then -1  else CAST(userInputB AS FLOAT)  end userInputB,
 case  when (isnull(userInputC ,0)=0) then -1  else CAST(userInputC AS FLOAT)  end userInputC,
 PCD.updatedByUsername,PCD.updatedByUserGUID,PCD.updatedByUserId,PCD.lastUpdatedDateTime,PCD.status
--LR.stationOrder
from
[STAGE].[PowerCurve] PC 
inner join [STAGE].PowerCurveDetails PCD  on PC.powerCurveID =PCD.powerCurveID
inner join [STAGE].[LineStationReference] LR
on PCD.Line=LR.line   and PCD.station=LR.station
---order by LR.regionOrder,LR.lineOrder,LR.stationOrder
GO
