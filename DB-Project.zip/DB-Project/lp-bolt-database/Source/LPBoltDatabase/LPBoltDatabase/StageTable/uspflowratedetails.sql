﻿create procedure stage.usp_FlowRatesDetails
as
begin

    with new_NFR as
	(
	select line,Natural_Flow_Rates_CCO_Requested_rates as flowrate,Lastupdate,
	       row_number()over(partition by line,cast(LastUpdate as date) order by len(Natural_Flow_Rates_CCO_Requested_rates) desc) as r
	from stage.SourceNFR
	where cast(LastUpdate as date) = (select max(cast(LastUpdate as date)) from stage.SourceNFR)
	),bolt_NFRs as 
	 (select Line,Flowrate,LastUpdate
	  from new_NFR
	  where r = 1
	  ),cte0 as
		(
		select line,value as Flowrate ,LastUpdate
		from bolt_NFRs
		cross apply string_split(flowrate,',')
		), cte1 as
		(select c1.line,c1.Flowrate
         ------,c1.LastUpdate,f1.line as line_fr,f1.FlowRateFinal_m3hr ,f1.LastUpdateDateTime
		 from cte0 c1
		 left join (select * from stage.FlowRatesDetails
		            where cast(LastUpdateDateTime as date) = (select max(cast(LastUpdateDateTime as date)) from stage.FlowRatesDetails)) f1
		 on c1.line = f1.line and c1.Flowrate = f1.FlowRateFinal_m3hr
		       and  cast(c1.LastUpdate as date) = cast(f1.LastUpdateDateTime as date)
		where f1.line is null and f1.FlowRateFinal_m3hr is null
	    ),cte2 as
		(
		select distinct line,region from stage.REFERENCE_TABLE
		)select c1.line,c2.region,c1.flowrate
		 into #temp
		 from cte1 c1
		 inner join cte2 c2
		 on c1.line = c2.line;

		 ----select * from  #temp
 
		with cte0 as
		(select line,region,cast(flowrate as int) as flowrate
		  from #temp
		),cte1 AS
		(SELECT *,LAG(flowrate) OVER (PARTITION BY line ORDER BY flowrate) AS prev_rate,
				   LEAD(flowrate) OVER (PARTITION BY line ORDER BY flowrate) AS next_rate,
				   ROW_NUMBER() OVER (PARTITION BY line ORDER BY flowrate) AS row_num
			FROM cte0
		),cte2 AS
		(SELECT *,MAX(row_num) OVER (PARTITION BY line) AS max_row_num
		 FROM cte1
		),cte3 as
		(SELECT *,
				CASE 
				   WHEN row_num = 1 THEN flowrate + ((next_rate - flowrate) / 2)
				   WHEN row_num = max_row_num THEN flowrate + ((flowrate - prev_rate) / 2)
				   ELSE next_rate
			   END AS MaxRangeCalc
		 from cte2
		 )insert into stage.FlowRatesDetails(Line,Region,FlowRateFinal_m3hr,MinRangeCalc,MaxRangeCalc,LastUpdateDateTime) 
		  select  line, region, flowrate as FlowRateFinal_m3hr ,CASE 
				   WHEN row_num = 1 THEN flowrate - ((next_rate - flowrate) / 2)
				   WHEN row_num = max_row_num THEN flowrate - ((flowrate - prev_rate) / 2)
				   ELSE lag(MaxRangeCalc)over(order by flowrate) 
			   END AS MinRangeCalc,MaxRangeCalc ,
			   getdate() as LastUpdateDateTime
		from cte3;

		drop table #temp;

		----------select * from  stage.FlowRatesDetails;

end