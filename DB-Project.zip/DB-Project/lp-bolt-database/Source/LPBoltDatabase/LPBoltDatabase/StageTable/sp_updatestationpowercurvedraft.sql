﻿CREATE PROCEDURE [STAGE].[usp_UpdateStationPowerCurveDraft] 
@PowerCurveDetailId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

       --DECLARE @Station NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.station');
        DECLARE @ApplicableDateStart DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
        DECLARE @ApplicableDateEnd DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
        DECLARE @HistoricDates NVARCHAR(MAX);

        SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
        
        -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM PowerCurve PC inner join PowerCurveDetails PCD on PC.powerCurveID=PCD.powerCurveID WHERE PCD.PowerCurveDetailID = @PowerCurveDetailId AND PC.status = 'Draft') < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            COMMIT TRANSACTION;
            RETURN;
        END

		-- need to validate only applicable dates;
		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
		FROM [STAGE].[ValidateDates](@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,1);
		If(@StatusCode=400)
		BEGIN
		COMMIT TRANSACTION;
		Return;
		END

		Begin
				-- Update PowerCurve
			UPDATE [STAGE].[PowerCurveDetails]
			SET 
				applicableDateRangeStart = @ApplicableDateStart,
				applicableDateRangeEnd = @ApplicableDateEnd,
				[historicalDateRange] = REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),
				[lastUpdatedDateTime] = GETDATE(),
				[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
				[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()),
				status = 'New'
			WHERE PowerCurveDetailID=@PowerCurveDetailId


     
			SET @StatusCode = 200; 
			SET @StatusMessage = '{"status":"success"}';

        
			COMMIT TRANSACTION;

		END
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
GO