﻿CREATE PROCEDURE [STAGE].[usp_DraftPowerCurveLoadTransactions] 
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

/*Declare @DraftPowerCurveData NVARCHAR(max),
		@StatusMessage NVARCHAR(max),
		@StatusCode INT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier;
		
set @DraftPowerCurveData='{
    "data": {
        "line":"93",
        "title":"Titlee for Testing line 1 via SP",
        "applicableDateStart":"2024-11-16T00:00:00",
        "applicableDateEnd":"2024-11-30T00:00:00",
        "historicDates":[
            {"startDate":"2023-01-01",
            "endDate": "2023-06-30"
            },
            {"startDate":"2023-07-01",
            "endDate": "2023-12-31"
            }
        ]
    }
}';
set  @username ='swami siva';
set @userid = '12345t';*/
	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		DECLARE @Line NVARCHAR(50) = JSON_VALUE(@DraftPowerCurveData, '$.data.line');
		DECLARE @Title NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.title');
		DECLARE @ApplicableDateStart NVARCHAR(10) = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
		DECLARE @ApplicableDateEnd NVARCHAR(10) = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
		DECLARE @HistoricDates NVARCHAR(MAX);

		SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
		print @Line;
		print @ApplicableDateStart;
		print @ApplicableDateEnd;
		print @HistoricDates;
		--Validate line-----------
		IF (
				(
					SELECT count(1)
					FROM [STAGE].[LineStationReference] 
					WHERE Line = @Line
					) < 1
			)
		BEGIN
			SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Invalid Line number.';

			INSERT INTO [STAGE].[ErrorLog] (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
			
			RETURN;
		END

		
		--select * from #HistoricDates
		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
			FROM [STAGE].[ValidateDates](@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,0);---passing the flag value 1

		If(@StatusCode=400)
		BEGIN
		
			print @StatusCode;
			print @StatusMessage;
			RollBack Transaction;
		Return;
		END
		
		-- Check if records already exist
		IF NOT EXISTS (
				SELECT 1
				FROM [STAGE].[PowerCurve]
				WHERE [line] = @Line
					AND STATUS = 'Draft'
					-- AND [title] = @Title
					AND [applicableDateStart] = @ApplicableDateStart
					AND [applicableDateEnd] = @ApplicableDateEnd
				)
		BEGIN
			print 'not exists';
		-- Temporary table to hold historic dates
			CREATE TABLE #HistoricDates (StartDate DATE, EndDate DATE);
			IF @HistoricDates IS NULL OR @HistoricDates = '[]'
			BEGIN
				-- If null or empty, insert a record with NULL values for historic dates
				INSERT INTO #HistoricDates (StartDate, EndDate)
				VALUES (NULL, NULL);
			END
			ELSE
			BEGIN
				-- Insert historic dates into temporary table
				INSERT INTO #HistoricDates (StartDate, EndDate)
				SELECT 
					JSON_VALUE(value, '$.startDate') AS StartDate,
					JSON_VALUE(value, '$.endDate') AS EndDate
					FROM OPENJSON(@DraftPowerCurveData, '$.data.historicDates') AS HistoricDates;
			END

			INSERT INTO [STAGE].[PowerCurve] (
				[line]
				,[title]
				,[applicableDateStart]
				,[applicableDateEnd]
				,[historicalDates]
				,[lastUpdateDateTime]
				,[isFavourite]
				,[status]
				,createdByUserId
				,createdByUserGUID
				,createdByUserName
				)
			SELECT @Line
				,@Title
				,@ApplicableDateStart
				,@ApplicableDateEnd
				,'' + Cast(min(StartDate) as varchar(20))+ ',' + cast(max(EndDate) as varchar(20))+'' AS historicDates
			-- Directly use the value for historicDates
			
				,GETDATE() AS lastUpdateDateTime
				,0 AS isFavourite
				-- Assuming 0 for false
				,'Draft' AS STATUS -- Change as necessary
				,COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 

			--FROM OPENJSON(@HistoricDates) WITH (value NVARCHAR(MAX) '$');-- This retrieves the array items correctly
			FROM #HistoricDates
			--GROUP BY StartDate, EndDate;  -- Ensure only unique dates are inserted

			--print 'nidhi'
			INSERT INTO [STAGE].[PowerCurveDetails] (
				[powerCurveID]
				,[line]
				,[station]
				,[applicableDateRangeStart]
				,[applicableDateRangeEnd]
				,[historicalDateRange]
				,[lastUpdatedDatetime]
				,[status],[createdByUserId],[createdByUserGUID],[createdByUserName]
			

				)
			SELECT PC.powerCurveID
				,LR.Line
				,LR.station
				,@ApplicableDateStart
				,@ApplicableDateEnd,
				--,PC.historicDates
				--, TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 2) ) AS Value1,
				--TRIM(PARSENAME(REPLACE(PC.historicDates, ',', '.'), 1) ) AS Value2
				REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', '')
				 , GETDATE(), 'Draft',
				  COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME())

			FROM [STAGE].[PowerCurve] PC
			INNER JOIN [STAGE].[LineStationReference] LR ON PC.line = LR.line
				AND PC.STATUS = 'Draft'
				AND pc.title = @Title
				AND PC.Line = @Line
			SET @StatusCode = 201;-- Indicate success--data inserted
			SET @StatusMessage = 'Draft created successfully.';
				-- Clean up temporary table
			DROP TABLE #HistoricDates;

			COMMIT TRANSACTION
		END
		ELSE
		BEGIN
			SET @StatusCode = 200;-- Indicate failure
			SET @StatusMessage = 'Draft data for this line already exists.';
			print @StatusMessage;
			INSERT INTO [STAGE].[ErrorLog] (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
		END
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO [STAGE].[ErrorLog] (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
GO