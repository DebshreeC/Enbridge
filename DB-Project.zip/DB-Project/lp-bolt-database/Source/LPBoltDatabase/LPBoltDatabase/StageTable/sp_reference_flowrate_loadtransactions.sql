﻿CREATE PROCEDURE [STAGE].[usp_ReferenceFlowRateLoadTransactions] 
@OptimusUpdateSuccessFlag BIT, @ReferenceFlowRateData NVARCHAR(MAX), @Ref BIT = 0
AS
BEGIN
	BEGIN TRY
		Begin Transaction
		if (@OptimusUpdateSuccessFlag = 1)
		Begin
			
			TRUNCATE Table [STAGE].[ReferenceFlowRates];
			INSERT INTO [STAGE].[ReferenceFlowRates]
				([Region]
				,[Line]
				,[refFlowRatem3hr]
				,[refFlowRateUpdatedDateTime])
			
				SELECT
				JSON_VALUE(value,'$.region') AS Region,
				JSON_VALUE(value,'$.line') AS Line,
				JSON_VALUE(value,'$.refFlowRatem3hr') AS refFlowRatem3hr,
				JSON_VALUE(value,'$.refFlowRateUpdatedDateTime') AS refFlowRateUpdatedDateTime
				FROM OPENJSON (@ReferenceFlowRateData); 

		End
		if (@Ref = 0)
				Begin
					IF (SELECT COUNT(1) FROM [STAGE].[DraftFlowRates])  < 1
						INSERT INTO [STAGE].[DraftFlowRates]
						([Region]
						,[Line]
						,[draftFlowRatem3hr]
						,[draftFlowRateUpdatedDateTime])
        				SELECT 
								[Region]
								,[Line]
								,[publishedFlowRatem3hr]
								,[publishedFlowRateUpdatedDateTime]
						FROM [STAGE].[PublishedFlowRates]
				End
		Else
			Begin
				TRUNCATE TABLE [STAGE].[DraftFlowRates];
				INSERT INTO [STAGE].[DraftFlowRates]
				([Region]
				,[Line]
				,[draftFlowRatem3hr]
				,[draftFlowRateUpdatedDateTime])
        		SELECT 
						[Region]
						,[Line]
						,[refFlowRatem3hr]
						,GetDate()
				FROM [STAGE].[ReferenceFlowRates]
			End
			--else display existing data
		Commit Transaction
	END TRY
	BEGIN CATCH
		-- Handle the error
		Commit Transaction
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
		VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
	


GO