﻿CREATE TABLE [STAGE].[ReferenceFlowRates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Region] [varchar](255) NOT NULL,
	[Line] [varchar](255) NULL,
	[refFlowRatem3hr] [int] NULL,
	[refFlowRateUpdatedDateTime] [datetime2](7) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UC_ReferenceFlowRates] UNIQUE NONCLUSTERED 
(
	[Region] ASC,
	[Line] ASC,
	[refFlowRatem3hr] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO