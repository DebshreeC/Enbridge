﻿CREATE TABLE [STAGE].[PowerCurve](
	[powerCurveID] [int] IDENTITY(1,1) NOT NULL,
	[line] [varchar](255) NULL,
	[title] [varchar](255) NULL,
	[applicableDateStart] [datetime2](7) NOT NULL,
	[applicableDateEnd] [datetime2](7) NOT NULL,
	[historicDates] [datetime2](7) NULL,
	[updatedbyUserId] [varchar](255) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[updatedbyUserName] [varchar](255) NULL,
	[lastUpdateDateTime] [datetime2](7) NULL,
	[isFavourite] [bit] NULL,
	[status] [varchar](255) NULL,
 CONSTRAINT [PK_PowerCurve] PRIMARY KEY CLUSTERED 