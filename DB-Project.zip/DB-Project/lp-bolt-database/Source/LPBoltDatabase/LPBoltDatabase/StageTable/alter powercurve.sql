﻿GO
ALTER TABLE [STAGE].[PowerCurveDetails]  WITH CHECK ADD  CONSTRAINT [FK_PowerCurveDetails_PowerCurve] FOREIGN KEY([powerCurveID])
REFERENCES [STAGE].[PowerCurve] ([powerCurveID])
GO
ALTER TABLE [STAGE].[PowerCurveDetails] CHECK CONSTRAINT [FK_PowerCurveDetails_PowerCurve]
GO
ALTER TABLE [STAGE].[PowerCurveStationDetails]  WITH CHECK ADD  CONSTRAINT [FK_PowerCurveStationDetails_PowerCurve] FOREIGN KEY([powerCurveID])
REFERENCES [STAGE].[PowerCurve] ([powerCurveID])
GO
ALTER TABLE [STAGE].[PowerCurveStationDetails] CHECK CONSTRAINT [FK_PowerCurveStationDetails_PowerCurve]
GO