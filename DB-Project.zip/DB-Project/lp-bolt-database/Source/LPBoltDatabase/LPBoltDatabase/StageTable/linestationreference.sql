﻿CREATE TABLE [STAGE].[LineStationReference](
	[line] [varchar](255) NOT NULL,
	[optimusLineReferenceGUID] [varchar](50) NULL,
	[station] [varchar](255) NOT NULL,
	[region] [varchar](255) NULL,
	[RegionOrder] [int] NULL,
	[LineOrder] [int] NULL,
	[StationOrder] [varchar](255) NULL,
 CONSTRAINT [UC_LineStationReference] UNIQUE NONCLUSTERED 
(
	[line] ASC,
	[station] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

