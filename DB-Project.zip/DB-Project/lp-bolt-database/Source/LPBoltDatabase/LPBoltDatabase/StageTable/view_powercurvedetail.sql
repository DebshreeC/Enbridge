﻿CREATE VIEW [STAGE].[viewPowerCurveDetail] AS
Select distinct  PC.powerCurveID, title, LR.region, PC.line,
applicableDateStart,
applicableDateEnd,
--isFavourite, 
PCD.PowerCurveDetailID, PCD.station, historicalDateRange,selectedCurveFitMethod
,CAST(polynomialRSquare AS FLOAT) AS polynomialRSquare,
CAST(exponentialRSquare AS FLOAT) AS exponentialRSquare,
CAST(polynomialCalculatedA AS FLOAT) AS polynomialCalculatedA,
CAST(polynomialCalculatedB AS FLOAT) AS polynomialCalculatedB,
CAST(polynomialCalculatedC AS FLOAT) AS polynomialCalculatedC,
CAST(exponentialCalculatedA AS FLOAT) AS exponentialCalculatedA,
CAST(exponentialCalculatedB AS FLOAT) AS exponentialCalculatedB,
CAST(userInputA AS FLOAT) AS userInputA,
CAST(userInputB AS FLOAT) AS userInputB,
CAST(userInputC AS FLOAT) AS userInputC,
PC.status
from
[STAGE].[PowerCurve] PC inner join [STAGE].[LineStationReference] LR
on PC.Line=LR.line 
inner join [STAGE].PowerCurveDetails PCD  on PC.powerCurveID =PCD.powerCurveID
GO