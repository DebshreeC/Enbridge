﻿CREATE TABLE [STAGE].[PowerCurveStationDetails](
	[PowerCurveStationDetailsID] [int] IDENTITY(1,1) NOT NULL,
	[powerCurveDetailID] [int] NULL,
	[powerCurveID] [int] NULL,
	[line] [varchar](255) NULL,
	[station] [varchar](255) NULL,
	[flowRate] [int] NULL,
	[count] [int] NULL,
	[referencePowerKwh] [int] NULL,
	[userPowerKwh] [int] NULL,
	[status] [varchar](50) NULL,
	[lastUpdatedDateTime] [datetime] NULL,
	[updatedByUsername] [varchar](255) NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [varchar](255) NULL,
 CONSTRAINT [PK_PowerCurveStationDetails] PRIMARY KEY CLUSTERED 
(
	[PowerCurveStationDetailsID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [STAGE].[PowerCurveStationDetails]  WITH CHECK ADD  CONSTRAINT [FK_PowerCurveStationDetails_PowerCurve] FOREIGN KEY([powerCurveID])
REFERENCES [STAGE].[PowerCurve] ([powerCurveID])
GO

ALTER TABLE [STAGE].[PowerCurveStationDetails] CHECK CONSTRAINT [FK_PowerCurveStationDetails_PowerCurve]
GO