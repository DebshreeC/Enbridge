﻿CREATE TABLE [STAGE].[PublishedFlowRates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Region] [varchar](255) NOT NULL,
	[Line] [varchar](255) NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[minpublishedFlowRatem3hr] [int] NULL,
	[maxpublishedFlowRatem3hr] [int] NULL,
	[publishedFlowRateUpdatedDateTime] [datetime2](7) NOT NULL,
	[updatedbyUserId] [varchar](255) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[updatedbyUserName] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO