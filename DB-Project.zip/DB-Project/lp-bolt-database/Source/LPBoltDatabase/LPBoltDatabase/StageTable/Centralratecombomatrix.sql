﻿CREATE TABLE [STAGE].[CentralRateComboMatrix](
	[combinationId] [int] IDENTITY(1,1) NOT NULL,
	[date] [date] NULL,
	[line14FlowRate] [float] NULL,
	[line14PowerCost] [decimal](10, 2) NULL,
	[line14DRACost] [decimal](10, 2) NULL,
	[line5FlowRate] [float] NULL,
	[line5PowerCost] [decimal](10, 2) NULL,
	[line5DRACost] [decimal](10, 2) NULL,
	[line61FlowRate] [float] NULL,
	[line61PowerCost] [decimal](10, 2) NULL,
	[line61DRACost] [decimal](10, 2) NULL,
	[line6AFlowRate] [float] NULL,
	[line6APowerCost] [decimal](10, 2) NULL,
	[line6ADRACost] [decimal](10, 2) NULL,
	[line78AFlowRate] [float] NULL,
	[line78APowerCost] [decimal](10, 2) NULL,
	[line78ADRACost] [decimal](10, 2) NULL,
	[line78BFlowRate] [float] NULL,
	[line78BPowerCost] [decimal](10, 2) NULL,
	[line78BDRACost] [decimal](10, 2) NULL,
	[combinedVolumeM3Day] [int] NULL,
	[combinedVolumeM3Hr] [int] NULL,
	[totalPowerConsumptionCost] [decimal](10, 2) NULL,
	[totalDRACost] [decimal](10, 2) NULL,
	[totalPowerDRACost] [decimal](10, 2) NULL,
	[costPerM3] [decimal](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[combinationId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


