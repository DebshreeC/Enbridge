﻿CREATE PROCEDURE [STAGE].[usp_DeletePowerCurveStation] 
@PowerCurveDetailId int,
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT

AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
		
		BEGIN

			IF (SELECT COUNT(1) FROM [STAGE].[PowerCurve] pc INNER JOIN [STAGE].[PowerCurveDetails] pd
				on pc.powercurveid = pd.powercurveid  WHERE pd.powerCurveDetailID = @PowerCurveDetailId and pc.status='Draft')<1
			BEGIN
				SET @StatusCode = 400; 
				SET @StatusMessage = 'Power curve not in draft status.';
			END
			ELSE
			BEGIN
				  delete from [STAGE].[PowerCurveStationDetails] where powerCurveDetailID=@PowerCurveDetailId
				  delete from [STAGE].[PowerCurveDetails] where powerCurveDetailID=@PowerCurveDetailId
				  SET @StatusCode = 200; 
				  SET @StatusMessage = 'Power curve Id deleted successfully.';
			END
		END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO [STAGE].[ErrorLog] (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
GO