﻿CREATE TABLE [STAGE].[DRA_Details](
	[draDetailID] [int] IDENTITY(1,1) NOT NULL,
	[draSummaryID] [int] NULL,
	[station] [varchar](255) NOT NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[referenceUsageLbHr] [int] NULL,
	[userGivenUsageLbHr] [int] NULL,
	[draType] [varchar](255) NULL
) ON [PRIMARY]
GO
