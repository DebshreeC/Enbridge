﻿ALTER TABLE [STAGE].[Testingtable]
ADD lastname VARCHAR(50);