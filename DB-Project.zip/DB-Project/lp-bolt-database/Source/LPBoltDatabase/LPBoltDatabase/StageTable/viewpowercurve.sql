﻿CREATE VIEW [STAGE].[viewPowerCurve] AS
Select distinct  powerCurveID, title, LR.region, PC.line, 
applicableDateStart,
applicableDateEnd,
updatedbyUserId	   ,
updatedbyUserGUID  ,
updatedbyUserName  ,
lastUpdateDateTime ,
isFavourite,
status
from
[STAGE].[PowerCurve] PC inner join [STAGE].[LineStationReference] LR
on PC.Line=LR.line