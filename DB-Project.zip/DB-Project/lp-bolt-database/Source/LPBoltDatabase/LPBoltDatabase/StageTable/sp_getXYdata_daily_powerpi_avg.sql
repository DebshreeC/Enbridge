﻿CREATE PROCEDURE [STAGE].[usp_getXYData_Daily_PowerPI_Avg] 
@PowerCurveId INT, @PowerCurveDetaild int
AS
BEGIN
    BEGIN TRY    
       /*
            SELECT   cast( dp.FlowRateFinal_m3hr as float)  XValue, cast( sum(AveragePowerDefault_kW * DataPointsCount )/sum(DataPointsCount) as float) as YValue
            FROM [STAGE].[Daily_PowerPI_Avg] dp
            JOIN [STAGE].[PowerCurveDetails] pcd ON 
			dp.line=pcd.line and dp.Station=pcd.station
            JOIN [STAGE].[PowerCurve] pc ON pcd.powerCurveID = pc.powerCurveID
            WHERE pc.status = 'draft' AND pcd.status = 'new' and AveragePowerDefault_kW>0 AND pc.powerCurveID=@PowerCurveId and pcd.PowerCurveDetailID=@PowerCurveDetaild
			and dp.Date between pcd.historicDateRangeStart and pcd.historicDateRangeEnd
			group by dp.line,dp.station,FlowRateFinal_m3hr order by FlowRateFinal_m3hr;*/
SELECT   
    CAST(dp.FlowRateFinal_m3hr AS FLOAT) AS XValue,  
   --- CAST(SUM(AveragePowerDefault_kW * DataPointsCount) / SUM(DataPointsCount) AS FLOAT) AS YValue
	    CAST(SUM(COALESCE(psd.userPowerKwh, dp.AveragePowerDefault_kW) * dp.DataPointsCount) / SUM(dp.DataPointsCount) AS FLOAT) AS YValue

FROM 
    [STAGE].[Daily_PowerPI_Avg] dp
JOIN 
    [STAGE].[PowerCurveDetails] pcd 
    ON dp.line = pcd.line 
    AND dp.Station = pcd.station
JOIN 
    [STAGE].[PowerCurve] pc 
    ON pcd.powerCurveID = pc.powerCurveID
	LEFT JOIN 
    [STAGE].[PowerCurveStationDetails] psd
    ON psd.powerCurveDetailID = pcd.PowerCurveDetailID 
    AND psd.line = dp.line 
    AND psd.flowRate = dp.FlowRateFinal_m3hr

-- Use CROSS APPLY to parse startDate and endDate from historicalDateRange JSON array
CROSS APPLY 
    OPENJSON(pcd.historicalDateRange) 
    WITH (
        startDate DATE '$.startDate',
        endDate DATE '$.endDate'
    ) AS DateRanges
WHERE 
    pc.status = 'draft' 
   AND pcd.status = 'new' 
    AND AveragePowerDefault_kW > 0 
    AND pc.powerCurveID = @PowerCurveId 
    AND pcd.PowerCurveDetailID = @PowerCurveDetaild
    -- Check if dp.Date is between any startDate and endDate from the JSON array
    AND dp.Date BETWEEN DateRanges.startDate AND DateRanges.endDate
GROUP BY 
    dp.line, dp.station, FlowRateFinal_m3hr
ORDER BY 
    FlowRateFinal_m3hr;

    END TRY
    BEGIN CATCH
        -- Optionally, you can log the error or return an error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO