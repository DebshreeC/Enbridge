﻿CREATE VIEW [STAGE].[viewHistorySummaryFlowRates] AS
Select    
 HistoryID, max(H.refFlowRateUpdatedDateTime) as  refFlowRateUpdatedDateTime, max(H.publishedFlowRateUpdatedDateTime) as UserFlowRateUpdateDateTime, 
 max(H.updatedByUserName) as updatedByUserName, max(H.updatedByUserID) as updatedByUserID, max(H.updatedByUserGUID) as UpdatedByUserGUID
	FROM 
    	[STAGE].[HistoricFlowRates] AS H group by historyID
