﻿CREATE VIEW [STAGE].[viewMetaFlowRates] AS
SELECT 
    COUNT(*) AS Id,
    MAX(R.refFlowRateUpdatedDateTime) AS refFlowRateUpdatedDateTime,
    MAX(D.draftFlowRateUpdatedDateTime) AS userFlowRateUpdatedDateTime,
    MAX(P.publishedFlowRateUpdatedDateTime) AS publishedFlowRateUpdatedDateTime,
    MAX(P.updatedbyUserId) AS updatedbyUserId,
    0 AS optimusUpdadateSuccessFlag,
    MAX(P.updatedbyUserName) AS updatedbyUserName, 
    MAX(P.updatedbyUserGUID) AS updatedbyUserGUID
FROM 
    STAGE.ReferenceFlowRates AS R
FULL OUTER JOIN 
    STAGE.DraftFlowRates AS D ON R.Line = D.Line and R.Region = D.Region and R.refFlowRatem3hr=D.draftFlowRatem3hr
FULL OUTER JOIN 
    STAGE.PublishedFlowRates AS P ON R.Line = P.Line and R.Region = P.Region and R.refFlowRatem3hr=p.publishedFlowRatem3hr;