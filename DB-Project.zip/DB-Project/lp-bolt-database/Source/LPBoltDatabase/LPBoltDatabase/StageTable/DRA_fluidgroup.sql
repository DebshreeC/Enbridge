﻿CREATE TABLE [STAGE].[DRA_fluidgroup](
	[region] [varchar](50) NULL,
	[line] [varchar](10) NULL,
	[fluidGroup] [int] NULL,
	[fluidGroupPercentage] [int] NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[updatedDateTime] [datetime2](7) NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdDateTime] [datetime2](7) NULL
) ON [PRIMARY]
GO