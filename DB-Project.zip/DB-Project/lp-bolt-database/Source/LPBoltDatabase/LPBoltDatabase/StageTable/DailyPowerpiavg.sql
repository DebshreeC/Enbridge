﻿
CREATE TABLE STAGE.Daily_PowerPI_Avg(
	[PowerAvgID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[StationID] [int] NULL,
	[Line] [varchar](10) NULL,
	[Station] [varchar](50) NULL,
	[FlowRateFinal_m3hr] [int] NULL,
	[AveragePowerDefault_kW] [int] NULL,
	[DataPointsCount] [int] NULL,
	[Date] [date] NULL
	)