﻿CREATE PROCEDURE [STAGE].[Naturalflowrate]
AS
BEGIN
    select * from [STAGE].[REFERENCE_TABLE]
	END