﻿CREATE TABLE [STAGE].[PowerCurveDetails](
	[PowerCurveDetailID] [int] IDENTITY(100,1) NOT NULL,
	[powerCurveID] [int] NULL,
	[line] [varchar](255) NULL,
	[station] [varchar](255) NULL,
	[applicableDateRangeStart] [datetime2](7) NULL,
	[applicableDateRangeEnd] [datetime2](7) NULL,
	[historicalDateRange] [varchar](max) NULL,
	[selectedCurveFitMethod] [varchar](255) NULL,
	[polynomialCalculatedA] [float] NULL,
	[polynomialCalculatedB] [float] NULL,
	[polynomialCalculatedC] [float] NULL,
	[polynomialRSquare] [float] NULL,
	[exponentialCalculatedA] [float] NULL,
	[exponentialCalculatedB] [float] NULL,
	[exponentialRSquare] [float] NULL,
	[userInputA] [float] NULL,
	[userInputB] [float] NULL,
	[userInputC] [float] NULL,
	[updatedByUsername] [varchar](255) NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[lastUpdatedDateTime] [datetime] NULL,
	[status] [varchar](255) NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [varchar](255) NULL,
 CONSTRAINT [PK_PowerCurveDetails] PRIMARY KEY CLUSTERED 
(
	[PowerCurveDetailID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [STAGE].[PowerCurveDetails]  WITH CHECK ADD  CONSTRAINT [FK_PowerCurveDetails_PowerCurve] FOREIGN KEY([powerCurveID])
REFERENCES [STAGE].[PowerCurve] ([powerCurveID])
GO

ALTER TABLE [STAGE].[PowerCurveDetails] CHECK CONSTRAINT [FK_PowerCurveDetails_PowerCurve]
GO