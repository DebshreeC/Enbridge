﻿CREATE VIEW [STAGE].[viewDRASummary] AS
Select distinct   S.draSummaryID,S.applicableDateStart,S.applicableDateEnd,S.heavyPercentage, S.lightPercentage,S.line,S.status,S.title,S.updatedByUserGUID,
S.updatedByUserId,S.updatedByUserName,S.createdDateTime,L.region,S.updatedDateTime
from
[STAGE].DRASummary S 
inner join [STAGE].LineStationReference L on S.line=L.line 
GO