﻿CREATE TABLE [STAGE].[WesternRateComboMatrix](
	[combinationId] [int] IDENTITY(1,1) NOT NULL,
	[date] [date] NULL,
	[line1FlowRate] [float] NULL,
	[line1PowerCost] [decimal](10, 2) NULL,
	[line1DRACost] [decimal](10, 2) NULL,
	[line2AFlowRate] [float] NULL,
	[line2APowerCost] [decimal](10, 2) NULL,
	[line2ADRACost] [decimal](10, 2) NULL,
	[line2BFlowRate] [float] NULL,
	[line2BPowerCost] [decimal](10, 2) NULL,
	[line2BDRACost] [decimal](10, 2) NULL,
	[line4FlowRate] [float] NULL,
	[line4PowerCost] [decimal](10, 2) NULL,
	[line4DRACost] [decimal](10, 2) NULL,
	[line65FlowRate] [float] NULL,
	[line65PowerCost] [decimal](10, 2) NULL,
	[line65DRACost] [decimal](10, 2) NULL,
	[line67FlowRate] [float] NULL,
	[line67PowerCost] [decimal](10, 2) NULL,
	[line67DRACost] [decimal](10, 2) NULL,
	[line93FlowRate] [float] NULL,
	[line93PowerCost] [decimal](10, 2) NULL,
	[line93DRACost] [decimal](10, 2) NULL,
	[combinedVolumeM3Day] [int] NULL,
	[combinedVolumeM3Hr] [int] NULL,
	[totalPowerConsumptionCost] [decimal](10, 2) NULL,
	[totalDRACost] [decimal](10, 2) NULL,
	[totalPowerDRACost] [decimal](10, 2) NULL,
	[costPerM3] [decimal](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[combinationId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
