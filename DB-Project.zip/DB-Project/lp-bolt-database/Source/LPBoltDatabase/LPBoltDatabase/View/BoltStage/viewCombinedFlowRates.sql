﻿CREATE VIEW [bolt_stage].[viewCombinedFlowRates] AS
Select   ROW_NUMBER() OVER (Order by Region,Line,RefFlowRatem3hr,PublishedFlowRatem3hr,DraftFlowRatem3hr ) as Id,Region,Line,RefFlowRatem3hr,PublishedFlowRatem3hr,DraftFlowRatem3hr
from (SELECT 
    COALESCE(R.Region, P.Region, D.Region) AS Region, 
    COALESCE(R.Line, P.Line, D.Line) AS Line, 
    COALESCE(R.RefFlowRatem3hr,-1) AS RefFlowRatem3hr, 
    COALESCE(P.publishedFlowRatem3hr,-1) AS PublishedFlowRatem3hr,
    COALESCE(D.draftFlowRatem3hr,-1) AS DraftFlowRatem3hr
	FROM 
    	--bolt_stage.PublishedFlowRates AS P 
		bolt_stage.ReferenceFlowRates AS R
	FULL OUTER JOIN 
    	bolt_stage.PublishedFlowRates AS P 
		--bolt_stage.DraftFlowRates AS D 
    	ON R.Region = P.Region AND R.Line = P.Line AND R.refFlowRatem3hr = P.PublishedFlowRatem3hr
		--ON D.Region = P.Region AND D.Line = P.Line AND D.draftFlowRatem3hr = P.PublishedFlowRatem3hr
	FULL OUTER JOIN 
    	bolt_stage.DraftFlowRates AS D 
		--bolt_stage.ReferenceFlowRates AS R
    	ON (P.Region = D.Region AND P.Line = D.Line AND P.PublishedFlowRatem3hr = D.draftFlowRatem3hr) OR 
		(R.Region = R.Region AND R.Line = D.Line AND R.refFlowRatem3hr = D.draftFlowRatem3hr)) as sub1;
		--ON R.Region = D.Region AND R.Line = D.Line AND R.refFlowRatem3hr = D.draftFlowRatem3hr) as sub1;
GO