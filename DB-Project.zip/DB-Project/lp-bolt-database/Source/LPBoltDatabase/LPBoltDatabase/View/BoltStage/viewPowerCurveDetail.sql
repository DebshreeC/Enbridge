﻿CREATE VIEW [bolt_stage].[viewPowerCurveDetail] AS
Select distinct  PC.powerCurveID, title, LR.region, PC.line,
applicableDateStart,
applicableDateEnd,
--isFavourite, 
PCD.PowerCurveDetailID, PCD.station, historicalDateRange,selectedCurveFitMethod
,CAST(polynomialRSquare AS FLOAT) AS polynomialRSquare,
CAST(exponentialRSquare AS FLOAT) AS exponentialRSquare,
CAST(polynomialCalculatedA AS FLOAT) AS polynomialCalculatedA,
CAST(polynomialCalculatedB AS FLOAT) AS polynomialCalculatedB,
CAST(polynomialCalculatedC AS FLOAT) AS polynomialCalculatedC,
CAST(exponentialCalculatedA AS FLOAT) AS exponentialCalculatedA,
CAST(exponentialCalculatedB AS FLOAT) AS exponentialCalculatedB,
CAST(userInputA AS FLOAT) AS userInputA,
CAST(userInputB AS FLOAT) AS userInputB,
CAST(userInputC AS FLOAT) AS userInputC,
PC.status, LR.stationOrder
from
[bolt_stage].[PowerCurve] PC inner join [bolt_stage].[LineStationReference] LR
on PC.Line=LR.line 
inner join [bolt_stage].PowerCurveDetails PCD  on PC.powerCurveID =PCD.powerCurveID
GO