﻿CREATE VIEW [bolt_stage].[viewMetaFlowRates] AS
SELECT 
    COUNT(*) AS Id,
    MAX(R.refFlowRateUpdatedDateTime) AS refFlowRateUpdatedDateTime,
    MAX(D.draftFlowRateUpdatedDateTime) AS userFlowRateUpdatedDateTime,
    MAX(P.publishedFlowRateUpdatedDateTime) AS publishedFlowRateUpdatedDateTime,
     Case when max(D.updatedbyUserId) is not null then  max(D.updatedbyUserId) else MAX(P.updatedbyUserId) end AS updatedbyUserId,
    0 AS optimusUpdadateSuccessFlag,
   Case when max(D.updatedbyUserName) is not null then  max(D.updatedbyUserName) else MAX(P.updatedbyUserName) end AS updatedbyUserName, 
    Case when max(D.updatedbyUserGUID) is not null then  max(D.updatedbyUserGUID) else  MAX(P.updatedbyUserGUID)end  AS updatedbyUserGUID
FROM 
    bolt_stage.ReferenceFlowRates AS R
FULL OUTER JOIN 
    bolt_stage.DraftFlowRates AS D ON R.Line = D.Line and R.Region = D.Region and R.refFlowRatem3hr=D.draftFlowRatem3hr
FULL OUTER JOIN 
    bolt_stage.PublishedFlowRates AS P ON R.Line = P.Line and R.Region = P.Region and R.refFlowRatem3hr=p.publishedFlowRatem3hr;
GO