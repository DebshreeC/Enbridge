﻿CREATE VIEW [bolt_stage].[viewDRAfluidgroup] AS
Select   ROW_NUMBER() OVER (Order by region,line,fluidGroup) as 
Id,region,line,fluidGroup,fluidGroupPercentage,updatedByUserId,updatedByUserGUID,updatedByUserName,
updatedDateTime,createdByUserId,createdDateTime
from (
SELECT   
    a.[region],
    a.[line],
	--b.station,
    a.[fluidGroup],
    a.[fluidGroupPercentage],
    a.[updatedByUserId],
    a.[updatedByUserGUID],
    a.[updatedByUserName],
    a.[updatedDateTime],
	a.[createdByUserId],
	a.[createdDateTime]
FROM 
    [bolt_stage].[DRA_fluidgroup] a)b
	

GO