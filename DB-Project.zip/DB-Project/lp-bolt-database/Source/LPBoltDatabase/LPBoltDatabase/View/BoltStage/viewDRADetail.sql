﻿CREATE VIEW [bolt_stage].[viewDRADetail] AS
Select ROW_NUMBER() OVER (Order by S.draSummaryID) as Id,
D.draSummaryID,line,station,publishedFlowRatem3hr,isnull(referenceUsageLbHr,0) referenceUsageLbHr,isnull(userGivenUsageLbHr,0) userGivenUsageLbHr,draType
from
[bolt_stage].DRASummary S 
inner join [bolt_stage].DRA_Details D on S.draSummaryID=D.draSummaryID
GO