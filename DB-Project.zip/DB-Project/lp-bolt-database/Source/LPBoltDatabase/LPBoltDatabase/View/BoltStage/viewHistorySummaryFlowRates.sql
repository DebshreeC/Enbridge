﻿CREATE VIEW [bolt_stage].[viewHistorySummaryFlowRates] AS
Select    
 HistoryID, max(H.refFlowRateUpdatedDateTime) as  refFlowRateUpdatedDateTime, max(H.publishedFlowRateUpdatedDateTime) as UserFlowRateUpdateDateTime, 
 max(H.updatedByUserName) as updatedByUserName, max(H.updatedByUserID) as updatedByUserID, max(H.updatedByUserGUID) as UpdatedByUserGUID

 
	FROM 
    	
    	bolt_stage.HistoricFlowRates AS H group by historyID
    	
GO