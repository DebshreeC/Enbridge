﻿CREATE VIEW [bolt_stage].[viewHistoryDetailFlowRates] AS
Select   ROW_NUMBER() OVER (Order by Region,Line,RefFlowRatem3hr,PublishedFlowRatem3hr,DraftFlowRatem3hr ) as Id,
HistoryID,
Region,Line,RefFlowRatem3hr,
PublishedFlowRatem3hr,DraftFlowRatem3hr
from (SELECT  H.historyID as HistoryID,
    COALESCE(H.Region, R.Region, D.Region) AS Region, 
    COALESCE(H.Line, R.Line, D.Line) AS Line, 
    COALESCE(R.RefFlowRatem3hr,-1) AS RefFlowRatem3hr, 
    COALESCE(H.publishedFlowRatem3hr,-1) AS PublishedFlowRatem3hr,
    COALESCE(D.draftFlowRatem3hr,-1) AS DraftFlowRatem3hr
	FROM 
	bolt_stage.HistoricFlowRates AS H 
    	
	left JOIN 
    	bolt_stage.ReferenceFlowRates AS R
    	ON R.Region = H.Region AND R.Line = H.Line AND R.refFlowRatem3hr = H.publishedFlowRatem3hr
	left JOIN 
    	bolt_stage.DraftFlowRates AS D 
    	ON R.Region = D.Region AND R.Line = D.Line AND R.refFlowRatem3hr = D.draftFlowRatem3hr
		) as sub1;
GO