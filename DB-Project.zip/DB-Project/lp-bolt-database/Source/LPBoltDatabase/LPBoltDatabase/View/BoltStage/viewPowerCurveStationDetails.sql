﻿CREATE VIEW [bolt_stage].[viewPowerCurveStationDetails] AS
SELECT [PowerCurveStationDetailsID]
      ,[powerCurveDetailID]
      ,[powerCurveID]
      ,[line]
      ,[station]
      ,[flowRate]
      , isnull([count],0) as [count]
	  , case  when (isnull([referencePowerKwh],0)=0) then -1  else     CAST([referencePowerKwh] AS FLOAT) end AS [referencePowerKwh]
 ,case  when (isnull([userPowerKwh],0)=0) then -1  else     CAST([userPowerKwh] AS FLOAT) end AS [userPowerKwh]

    
      ,[status]
      ,[lastUpdatedDateTime]
      ,[updatedByUsername]
      ,[updatedByUserId]
      ,[updatedbyUserGUID]
      ,[createdByUserId]
      ,[createdByUserGUID]
      ,[createdByUserName]
  FROM [bolt_stage].[PowerCurveStationDetails]

GO