﻿CREATE VIEW [bolt_stage].[viewDRASummary] AS
Select distinct   S.draSummaryID,S.applicableDateStart,S.applicableDateEnd,S.heavyPercentage, S.lightPercentage,S.line,S.status,S.title,S.updatedByUserGUID,
S.updatedByUserId,S.updatedByUserName,S.createdDateTime,L.region,S.updatedDateTime,isnull(s.isFavourite,0) as isFavourite
, L.regionOrder,L.lineOrder
from
[bolt_stage].DRASummary S 
inner join [bolt_stage].LineStationReference L on S.line=L.line 
GO