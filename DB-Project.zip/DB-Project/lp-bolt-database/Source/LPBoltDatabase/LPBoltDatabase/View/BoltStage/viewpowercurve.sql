﻿CREATE VIEW [bolt_stage].[viewPowerCurve] AS
SELECT DISTINCT 
	PC.powerCurveID
	, PC.title
	, LR.region
	, PC.line
	, PC.applicableDateStart
	, PC.applicableDateEnd
	, PC.updatedByUserId
	, PC.updatedByUserGUID
	, PC.updatedByUserName
	, PC.lastUpdateDateTime
	, PC.isFavourite
	, PC.status
	, LR.regionOrder
	, LR.lineOrder
FROM   
	bolt_stage.PowerCurve AS PC INNER JOIN bolt_stage.LineStationReference AS LR ON PC.line = LR.line