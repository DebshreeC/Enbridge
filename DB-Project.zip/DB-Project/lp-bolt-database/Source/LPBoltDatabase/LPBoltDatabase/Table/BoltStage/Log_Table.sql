﻿CREATE TABLE [bolt_stage].[Log_Table](
	[Identity_Column] [int] NOT NULL,
	[Execution_StartDateTime] [datetime] NULL,
	[Execution_EndDateTime] [datetime] NULL,
	[PipelineName] [varchar](100) NULL,
	[Status] [varchar](20) NULL,
	[Created_Date] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[ErrorMessage] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[Identity_Column] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [bolt_stage].[Log_Table] ADD  DEFAULT (NULL) FOR [ErrorMessage]
GO

ALTER TABLE [bolt_stage].[Log_Table]  WITH CHECK ADD CHECK  (([Status]='Failed' OR [Status]='Succeeded' OR [Status]='Started'))
GO

