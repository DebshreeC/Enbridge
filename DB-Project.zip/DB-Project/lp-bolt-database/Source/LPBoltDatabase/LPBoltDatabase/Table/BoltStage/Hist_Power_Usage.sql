﻿CREATE TABLE [bolt_stage].[Hist_Power_Usage](
	[Pipeline] [int] NULL,
	[Station_Name] [varchar](50) NULL,
	[Callsign] [varchar](10) NULL,
	[Province_State] [varchar](2) NULL,
	[Utility] [varchar](100) NULL,
	[Power_Method_1_KW] [float] NULL,
	[Power_Method_2_KW] [float] NULL,
	[Power_Method_3_KW] [float] NULL,
	[Power_Default_KW] [float] NULL,
	[Flow_Rate_M3_HR] [float] NULL,
	[DateTime] [datetime] NULL
) ON [PRIMARY]
GO

