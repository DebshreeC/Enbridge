﻿CREATE TABLE [bolt_stage].[PowerEnergyRate](
	[StationID] [int] IDENTITY(1,1) NOT NULL,
	[Region] [varchar](255) NOT NULL,
	[Line] [varchar](255) NOT NULL,
	[Station] [varchar](255) NOT NULL,
	[District] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[Month] [int] NOT NULL,
	[MillRate] [decimal](18, 10) NOT NULL,
	[Vlookup] [varchar](255) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[StationID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

