﻿CREATE TABLE [bolt_stage].[Daily_PowerPI_Avg](
	[StationID] [int] NULL,
	[Line] [varchar](10) NULL,
	[Station] [varchar](50) NULL,
	[FlowRateFinal_m3hr] [int] NULL,
	[AveragePowerDefault_kW] [float] NULL,
	[DataPointsCount] [int] NULL,
	[Date] [date] NULL,
	[PowerAvgID] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK__Daily_Po__B9777A5D2F48C279] PRIMARY KEY CLUSTERED 
(
	[PowerAvgID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

