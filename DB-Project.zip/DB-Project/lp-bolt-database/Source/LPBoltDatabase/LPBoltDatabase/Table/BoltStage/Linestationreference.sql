﻿CREATE TABLE [bolt_stage].[LineStationReference](
	[region] [varchar](255) NULL,
	[line] [varchar](255) NOT NULL,
	[powerPILineMapping] [int] NULL,
	[optimusLineReferenceGUID] [varchar](50) NULL,
	[regionOrder] [int] NULL,
	[lineOrder] [int] NULL,
	[stationOrder] [int] NULL,
	[station] [varchar](255) NOT NULL,
 CONSTRAINT [UC_LineStationReference] UNIQUE NONCLUSTERED 
(
	[line] ASC,
	[station] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

