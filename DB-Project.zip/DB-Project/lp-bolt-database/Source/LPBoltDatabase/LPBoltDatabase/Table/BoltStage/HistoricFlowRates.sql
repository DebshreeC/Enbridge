﻿CREATE TABLE [bolt_stage].[HistoricFlowRates](
	[historyID] [int] NOT NULL,
	[publishedID] [int] NOT NULL,
	[region] [varchar](255) NULL,
	[line] [varchar](255) NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[publishedFlowRateUpdatedDateTime] [datetime2](7) NULL,
	[updatedByUserID] [varchar](255) NULL,
	[updatedByUserGUID] [varchar](255) NULL,
	[updatedByUserName] [varchar](255) NULL,
	[refFlowRateUpdatedDateTime] [datetime2](7) NULL
) ON [PRIMARY]
GO

