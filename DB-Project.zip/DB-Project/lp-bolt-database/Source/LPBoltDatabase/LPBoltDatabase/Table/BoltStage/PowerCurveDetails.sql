﻿CREATE TABLE [bolt_stage].[PowerCurveDetails](
	[PowerCurveDetailID] [int] IDENTITY(8415,1) NOT NULL,
	[powerCurveID] [int] NOT NULL,
	[line] [nvarchar](max) NULL,
	[station] [nvarchar](max) NULL,
	[applicableDateRangeStart] [datetime] NULL,
	[applicableDateRangeEnd] [datetime] NULL,
	[historicalDateRange] [nvarchar](max) NULL,
	[selectedCurveFitMethod] [nvarchar](max) NULL,
	[polynomialCalculatedA] [float] NULL,
	[polynomialCalculatedB] [float] NULL,
	[polynomialCalculatedC] [float] NULL,
	[polynomialRSquare] [float] NULL,
	[exponentialCalculatedA] [float] NULL,
	[exponentialCalculatedB] [float] NULL,
	[exponentialRSquare] [float] NULL,
	[userInputA] [float] NULL,
	[userInputB] [float] NULL,
	[userInputC] [float] NULL,
	[updatedByUsername] [nvarchar](max) NULL,
	[updatedByUserId] [nvarchar](max) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[lastUpdatedDateTime] [datetime] NULL,
	[status] [nvarchar](max) NULL,
	[createdByUserId] [nvarchar](max) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [nvarchar](max) NULL
 CONSTRAINT [PK_PowerCurveDetails] PRIMARY KEY CLUSTERED 
(
	[PowerCurveDetailID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [bolt_stage].[PowerCurveDetails]  WITH CHECK ADD  CONSTRAINT [FK_PowerCurveDetails_PowerCurve] FOREIGN KEY([powerCurveID])
REFERENCES [bolt_stage].[PowerCurve] ([powerCurveID])
GO

ALTER TABLE [bolt_stage].[PowerCurveDetails] CHECK CONSTRAINT [FK_PowerCurveDetails_PowerCurve]
GO

