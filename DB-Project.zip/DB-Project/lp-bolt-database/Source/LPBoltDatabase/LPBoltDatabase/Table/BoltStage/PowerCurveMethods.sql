﻿CREATE TABLE [bolt_stage].[PowerCurveMethods](
	[curveFitMethodID] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](255) NULL,
	[formula] [nvarchar](255) NULL
) ON [PRIMARY]
GO

