﻿CREATE TABLE [bolt_stage].[DraftFlowRates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Region] [varchar](255) NOT NULL,
	[Line] [varchar](255) NULL,
	[draftFlowRatem3hr] [int] NULL,
	[draftFlowRateUpdatedDateTime] [datetime2](7) NOT NULL,
	[updatedbyUserId] [varchar](255) NULL,
	[updatedbyUserGUID] [uniqueidentifier] NULL,
	[updatedbyUserName] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [Unique_DraftFlowRates] UNIQUE NONCLUSTERED 
(
	[Line] ASC,
	[Region] ASC,
	[draftFlowRatem3hr] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

