﻿CREATE TABLE [bolt_stage].[WesternRateComboMatrix](
	[date] [date] NULL,
	[line1FlowRate] [int] NULL,
	[line1PowerCost] [decimal](25, 5) NULL,
	[line1DRACost] [float] NULL,
	[line2AFlowRate] [int] NULL,
	[line2APowerCost] [decimal](25, 5) NULL,
	[line2ADRACost] [float] NULL,
	[line4FlowRate] [int] NULL,
	[line4PowerCost] [decimal](25, 5) NULL,
	[line4DRACost] [float] NULL,
	[line67FlowRate] [int] NULL,
	[line67PowerCost] [decimal](25, 5) NULL,
	[line67DRACost] [float] NULL,
	[line93FlowRate] [int] NULL,
	[line93PowerCost] [decimal](25, 5) NULL,
	[line93DRACost] [float] NULL,
	[combinedVolumeM3perDay] [int] NULL,
	[combinedVolumeM3perHr] [float] NULL,
	[totalPowerConsumptionCost] [decimal](30, 5) NULL,
	[totalDRACost] [float] NULL,
	[totalPowerDRACostCADperDay] [float] NULL,
	[costPerM3] [float] NULL,
	[combinationId] [int] NOT NULL
) ON [PRIMARY]
GO

