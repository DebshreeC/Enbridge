﻿CREATE TABLE [bolt_stage].[CentralRateComboMatrix](
	[date] [date] NULL,
	[line5FlowRate] [int] NULL,
	[line5PowerCost] [decimal](25, 5) NULL,
	[line5DRACost] [float] NULL,
	[line6AFlowRate] [int] NULL,
	[line6APowerCost] [decimal](25, 5) NULL,
	[line6ADRACost] [float] NULL,
	[line14FlowRate] [int] NULL,
	[line14PowerCost] [decimal](25, 5) NULL,
	[line14DRACost] [float] NULL,
	[line61FlowRate] [int] NULL,
	[line61PowerCost] [decimal](25, 5) NULL,
	[line61DRACost] [float] NULL,
	[combinedVolumeM3perDay] [int] NULL,
	[combinedVolumeM3perHr] [float] NULL,
	[totalPowerConsumptionCost] [decimal](29, 5) NULL,
	[totalDRACost] [float] NULL,
	[totalPowerDRACostCADperDay] [float] NULL,
	[costPerM3] [float] NULL,
	[combinationId] [int] NOT NULL
) ON [PRIMARY]
GO

