﻿CREATE TABLE [bolt_stage].[DRA_Details](
	[draDetailID] [int] IDENTITY(1,1) NOT NULL,
	[draSummaryID] [int] NULL,
	[station] [varchar](255) NOT NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[referenceUsageLbHr] [decimal](18, 9) NULL,
	[userGivenUsageLbHr] [decimal](18, 9) NULL,
	[draType] [varchar](255) NULL,
	[updatedByUserId] [varchar](255) NULL,
	[updatedByUserGUID] [uniqueidentifier] NULL,
	[updatedByUserName] [varchar](255) NULL,
	[lastUpdateDateTime] [datetime2](7) NULL,
	[createdByUserId] [varchar](255) NULL,
	[createdByUserGUID] [uniqueidentifier] NULL,
	[createdByUserName] [varchar](255) NULL
) ON [PRIMARY]
GO

