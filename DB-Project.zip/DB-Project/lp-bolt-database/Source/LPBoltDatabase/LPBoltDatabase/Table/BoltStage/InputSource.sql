﻿CREATE TABLE [bolt_stage].[InputSource](
	[pi_tag] [varchar](255) NULL,
	[Station] [varchar](255) NULL,
	[Line] [varchar](255) NULL,
	[Date] [date] NULL,
	[flowrate] [decimal](10, 2) NULL,
	[bucket] [varchar](50) NULL,
	[average] [decimal](10, 2) NULL
) ON [PRIMARY]
GO

