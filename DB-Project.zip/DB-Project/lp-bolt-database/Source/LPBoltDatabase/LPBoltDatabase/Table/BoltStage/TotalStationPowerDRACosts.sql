﻿CREATE TABLE [bolt_stage].[TotalStationPowerDRACosts](
	[Line] [nvarchar](max) NULL,
	[Station] [nvarchar](max) NULL,
	[applicableDate] [date] NULL,
	[publishedFlowRatem3hr] [int] NULL,
	[PowerConsumptionkW] [decimal](15, 5) NULL,
	[PowerEnergyRateCADPerkW] [float] NULL,
	[PowerConsumptionCostCADperday] [decimal](15, 5) NULL,
	[DRAConsumptionLightlbPerhr] [float] NULL,
	[DRAConsumptionHeavylbPerhr] [float] NULL,
	[DRACostCADPerday] [float] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

