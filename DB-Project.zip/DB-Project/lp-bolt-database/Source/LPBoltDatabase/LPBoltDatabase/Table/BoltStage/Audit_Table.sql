﻿CREATE TABLE [bolt_stage].[Audit_Table](
	[Identity_Column] [int] NOT NULL,
	[Execution_StartDateTime] [datetime] NULL,
	[Execution_EndDateTime] [datetime] NULL,
	[PipelineName] [varchar](100) NULL,
	[WaterMarkColumn] [varchar](100) NULL,
	[WaterMarkValue_From] [varchar](100) NULL,
	[WaterMarkValue_To] [varchar](100) NULL,
	[Created_Date] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[Identity_Column] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

