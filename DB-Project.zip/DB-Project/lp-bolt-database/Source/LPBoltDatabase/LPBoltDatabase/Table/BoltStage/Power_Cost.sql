﻿CREATE TABLE [bolt_stage].[Power_Cost](
	[Line] [varchar](50) NULL,
	[Station] [varchar](50) NULL,
	[Hour] [int] NULL,
	[Date] [date] NULL,
	[EnergyRate] [float] NULL,
	[DemandRate] [float] NULL
) ON [PRIMARY]
GO

