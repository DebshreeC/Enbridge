﻿SET IDENTITY_INSERT [bolt_stage].[DRA_Cost] ON 

INSERT [bolt_stage].[DRA_Cost] ([ID], [DRAType], [density], [costPerGalCAD], [costPerLbCAD], [updatedByUserId], [updatedByUserGUID], [updatedByUserName], [UpdatedDateTime], [createdByUserId], [createdDateTime]) 
SELECT 6, N'Heavy', 8.42, 30.92, 3.67220902612827, N'miguelff', N'00000000-0000-0000-0000-000000000000', N'Fabio Cruz', CAST(N'2025-01-20T14:38:37.8833333' AS DateTime2), NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM [bolt_stage].[DRA_Cost] WHERE [ID] = 6);

INSERT [bolt_stage].[DRA_Cost] ([ID], [DRAType], [density], [costPerGalCAD], [costPerLbCAD], [updatedByUserId], [updatedByUserGUID], [updatedByUserName], [UpdatedDateTime], [createdByUserId], [createdDateTime]) 
SELECT 7, N'Light', 8, 18.24, 2.28, N'miguelff', N'00000000-0000-0000-0000-000000000000', N'Fabio Cruz', CAST(N'2025-01-20T14:38:11.7766667' AS DateTime2), NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM [bolt_stage].[DRA_Cost] WHERE [ID] = 7);

SET IDENTITY_INSERT [bolt_stage].[DRA_Cost] OFF