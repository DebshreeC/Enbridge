﻿CREATE PROCEDURE [bolt_stage].[usp_UpdatePowerCurveDraft] 
@PowerCurveId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

AS
/*Declare @PowerCurveId int,@DraftPowerCurveData NVARCHAR(max),@StatusMessage NVARCHAR(4000),@StatusCode INT 
set @PowerCurveId=167;
set @DraftPowerCurveData ='{
    "data": {
        "line":"1",
        "title":"Titlee for Testing line 1 via SP",
        "applicableDateStart":"2024-11-07T00:00:00",
        "applicableDateEnd":"2024-11-30T00:00:00",
        "historicDates":[
            {"startDate":"2023-01-01",
            "endDate": "2023-06-30"
            },
            {"startDate":"2023-07-01",
            "endDate": "2023-12-31"
            }
        ]
    }
}';*/
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION

        DECLARE @Title NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.title');
        DECLARE @ApplicableDateStart DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
        DECLARE @ApplicableDateEnd DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
        DECLARE @HistoricDates NVARCHAR(MAX),@mindate varchar(20), @maxdate varchar(20);
        SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
		


		   -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM bolt_stage.PowerCurve WHERE powerCurveID = @PowerCurveId AND status = 'Draft') < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END

		---case 1 When user want to update title only
	IF( @Title is not null)
	BEGIN
	----
	 if(@Title='')
	 BEGIN
	   SET @StatusCode = 400; 
            SET @StatusMessage = 'Title cannot be blank.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
			Return;
	 END

		UPDATE [bolt_stage].[PowerCurve]
        SET 
            [title] = @Title,
			[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
        WHERE powerCurveID = @PowerCurveId;

        
	 END

		----case 2 when historic date want to update historic date only
		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
		FROM bolt_stage.ValidateDates(@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,'UPDATE');
		If(@StatusCode=400)
		BEGIN
			ROLLBACK TRANSACTION;
		Return;
		END


        
		IF(@HistoricDates is not null  )
		BEGIN
		
		     CREATE TABLE #HistoricDates (StartDate DATETIME, EndDate DATETIME);
		
    -- Parse and insert historic dates into the table variable
    IF  @HistoricDates = '[]'
    BEGIN
        INSERT INTO #HistoricDates (StartDate, EndDate) VALUES (NULL, NULL);
    END
    ELSE
    BEGIN
       
  

        -- Temporary table to hold historic dates
   
		INSERT INTO #HistoricDates (StartDate, EndDate)
            SELECT 
                TRY_CAST(JSON_VALUE(value, '$.startDate') AS DATETIME) AS StartDate,
                TRY_CAST(JSON_VALUE(value, '$.endDate') AS DATETIME) AS EndDate
            FROM OPENJSON(@HistoricDates) AS HistoricDates;


			  END

				
		select @mindate = Cast(min(StartDate) as varchar(20)), @maxdate = cast(max(EndDate) as varchar(20)) from #HistoricDates

		
		UPDATE [bolt_stage].[PowerCurve]
        SET 
            [historicalDates] =  '' + @mindate + ',' + @maxdate +'' ,
			[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
        WHERE powerCurveID = @PowerCurveId;

		UPDATE PD
			SET 
		        PD.historicalDateRange=	REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),
				PD.selectedCurveFitMethod=null,
				PD.polynomialCalculatedA=null,
				pd.polynomialCalculatedB=null,
				pd.polynomialCalculatedC=null,
				pd.exponentialCalculatedA=null,
				pd.exponentialCalculatedB=null,
				pd.exponentialRSquare=null,
				pd.polynomialRSquare=null,
				pd.status='DRAFT'
				FROM [bolt_stage].[PowerCurveDetails] PD
				INNER JOIN [bolt_stage].PowerCurve PC ON PD.powerCurveID = PC.powerCurveID
				INNER JOIN [bolt_stage].LineStationReference LR ON PC.line = LR.line
				WHERE PC.STATUS = 'DRAFT' AND 
				PD.powerCurveID = @PowerCurveId;

			DELETE FROM PowerCurveStationDetails WHERE powerCurveID = @PowerCurveId;
	
     
        -- Clean up temporary table
        DROP TABLE #HistoricDates;

	    END


     
	IF(@ApplicableDateStart  is not null  and @ApplicableDateEnd  is not null)
	BEGIN
       
	
		UPDATE [bolt_stage].[PowerCurve]
        SET 
           --- [title] = @Title,
            [applicableDateStart] = @ApplicableDateStart,
            [applicableDateEnd] = @ApplicableDateEnd,
			[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
        WHERE powerCurveID = @PowerCurveId;

     
		UPDATE PD
			SET 
				PD.applicableDateRangeStart = @ApplicableDateStart,
				PD.applicableDateRangeEnd = @ApplicableDateEnd,
					PD.lastUpdatedDateTime = GETDATE(),
					PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
				FROM [bolt_stage].[PowerCurveDetails] PD
				INNER JOIN [bolt_stage].PowerCurve PC ON PD.powerCurveID = PC.powerCurveID
				INNER JOIN [bolt_stage].LineStationReference LR ON PC.line = LR.line
				WHERE PC.STATUS = 'DRAFT' AND 
				PD.powerCurveID = @PowerCurveId;

		UPDATE PD
		SET 
			PD.applicableDateRangeStart = '1900-01-01',
			PD.applicableDateRangeEnd = '1900-01-01',
			PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
		FROM [bolt_stage].[PowerCurveDetails] PD
		JOIN (
			SELECT line, station
			FROM [bolt_stage].[PowerCurveDetails]
			WHERE  powerCurveID = @PowerCurveId
			GROUP BY line, station
			HAVING COUNT(*) > 1
		) AS Subquery
		ON PD.line = Subquery.line AND PD.station = Subquery.station
		WHERE  PD.powerCurveID = @PowerCurveId;

	END



        SET @StatusCode = 201; 
        SET @StatusMessage = 'Draft updated successfully.';
        COMMIT TRANSACTION;


    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
