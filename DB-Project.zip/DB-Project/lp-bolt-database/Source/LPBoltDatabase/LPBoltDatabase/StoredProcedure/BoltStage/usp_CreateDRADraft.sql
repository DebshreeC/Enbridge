﻿
CREATE PROCEDURE [bolt_stage].[usp_CreateDRADraft] 
@DraftDRAData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

/*Declare @DraftDRAData NVARCHAR(max),
		@StatusMessage NVARCHAR(max),
		@StatusCode INT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier;
		
set @DraftDRAData='{
    "data": {
        "line":"93",
        "title":"Titlee for Testing line 1 via SP",
        "applicableDateStart":"2024-11-16T00:00:00",
        "applicableDateEnd":"2024-11-30T00:00:00"
       
    }
}';
set  @username ='swami siva';
set @userid = '12345t';*/
	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		DECLARE @Line NVARCHAR(50) = JSON_VALUE(@DraftDRAData, '$.data.line');
		DECLARE @Title NVARCHAR(100) = JSON_VALUE(@DraftDRAData, '$.data.title');
		DECLARE @ApplicableDateStart NVARCHAR(10) = JSON_VALUE(@DraftDRAData, '$.data.applicableDateStart');
		DECLARE @ApplicableDateEnd NVARCHAR(10) = JSON_VALUE(@DraftDRAData, '$.data.applicableDateEnd');
	
		DECLARE  @DRASummaryID as int;
		
		print @Line;
		print @ApplicableDateStart;
		print @ApplicableDateEnd;
		--Validate line-----------
		IF (
				(
					SELECT count(1)
					FROM bolt_stage.LineStationReference 
					WHERE Line = @Line
					) < 1
			)
		BEGIN
			SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Invalid Line number.';

			INSERT INTO bolt_stage.ErrorLog (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
			
			RETURN;
		END

		
		

	IF(@ApplicableDateStart is not null and @ApplicableDateEnd is not null)
	BEGIN
    -- Validate applicable dates
    IF @ApplicableDateStart < cast(GETDATE() as date)
    BEGIN
        SET @StatusCode = 400;
        SET @StatusMessage = 'ApplicableDateStart must be greater than the current date.';
		Rollback Tran;
        RETURN;
    END

    IF @ApplicableDateEnd < @ApplicableDateStart
    BEGIN
        SET @StatusCode = 400;
        SET @StatusMessage = 'ApplicableDateEnd must be greater than ApplicableDateStart.';
		Rollback Tran;
        RETURN;
    END

	END
	
	
   --- select  DRAType from bolt_stage.DRA_Reference  where line=@Line
 DECLARE @HeavyPer AS int = 0;
DECLARE @LightPer AS  int = 0;

-- Common Table Expression to check DRATYPE counts
WITH DRA_Count AS (
    SELECT 
        DRATYPE,
        COUNT(*) AS TotalCount
    FROM bolt_stage.DRA_Reference
    WHERE Line = @Line
    GROUP BY DRATYPE
)
-- Assign percentages based on the count of DRATYPEs
SELECT 
    @HeavyPer = CASE 
                    WHEN EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Heavy' AND NOT EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Light')) 
                    THEN 100
                    WHEN EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Heavy' AND EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Light'))
                    THEN 50
                    ELSE 0
                END,
    @LightPer = CASE 
                    WHEN EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Light' AND NOT EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Heavy')) 
                    THEN 100
                    WHEN EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Light' AND EXISTS (SELECT 1 FROM DRA_Count WHERE DRATYPE = 'Heavy'))
                    THEN 50
                    ELSE 0
                END;




	INSERT INTO [bolt_stage].[DRASummary]
           (
           [line]
           ,[applicableDateStart]
           ,[applicableDateEnd]
           ,[title]
		   ,[heavyPercentage]
		   ,[lightPercentage]
           ,[updatedByUserId]
           ,[updatedByUserGUID]
           ,[updatedByUserName]
           ,[updatedDateTime]
           ,[createdDateTime]
		   ,[createdByUserId]
		   ,[createdByUserGUID]
           ,[createdByUserName]
           ,[status])
     
			SELECT @Line
				,@ApplicableDateStart
				,@ApplicableDateEnd
			    ,@Title,@HeavyPer,@LightPer
				,COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 
					,GETDATE(),  GETDATE(),
					COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 
					,'DRAFT' AS STATUS -- Change as necessary

			set @DRASummaryID=SCOPE_IDENTITY();

			
INSERT INTO [bolt_stage].[DRA_Details]
           ([draSummaryID]
           ,[station]
           ,[publishedFlowRatem3hr]
          ,[referenceUsageLbHr]
          ,[userGivenUsageLbHr]
           ,[draType]
		     ,[updatedByUserId]
           ,[updatedByUserGUID]
           ,[updatedByUserName]
           ,[lastupdateDateTime]
		   ,[createdByUserId]
		   ,[createdByUserGUID]
           ,[createdByUserName])
		   select @DRASummaryID,  station, publishedFlowRatem3hr,  sum(isnull(DRARate,0))/Count(publishedFlowRatem3hr) as referenceUsageLbHr,
		    sum(isnull(DRARate,0))/Count(publishedFlowRatem3hr) as  userGivenUsageLbHr ,DRAType 
			,COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 
					,GETDATE(),  
					COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) 
			from  bolt_stage.DRA_Reference where line=@Line
			--and drarate is not null
		   group by
		    station,publishedFlowRatem3hr,DRAType

		
			SET @StatusCode = 201;-- Indicate success--data inserted
			set @StatusMessage= Cast(@DRASummaryID as varchar(10));


			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
