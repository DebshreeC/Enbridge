﻿CREATE PROCEDURE [bolt_stage].[usp_UpdateDRADetail] 
@DraftDRAData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,@DRASummaryID int,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

	
		--Validate DRA Summary-----------
		IF (
				(
					SELECT count(1)
					FROM bolt_stage.DRASummary 
					WHERE draSummaryID = @DRASummaryID
					) < 1
			)
		BEGIN
			SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Invalid DRA.';

			INSERT INTO bolt_stage.ErrorLog (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
			
			RETURN;
		END

	   IF (SELECT COUNT(1) FROM bolt_stage.DRASummary WHERE draSummaryID = @DRASummaryID and status ='Draft')<1
		BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'DRA not in draft status.';
			Rollback TRANSACTION;-- Rollback on failure
			RETURN;
		END

		
  
-- Declare a table variable to hold the parsed JSON data
DECLARE @ParsedData TABLE (
    station NVARCHAR(50),
    flowRatem3hr FLOAT,
    userGivenUsageLbHr FLOAT,
    DRAType NVARCHAR(50)
);

-- Insert JSON data into the table variable
INSERT INTO @ParsedData (station, flowRatem3hr, userGivenUsageLbHr, DRAType)
SELECT 
    JSON_VALUE(value, '$.station') AS station,
    TRY_CAST(JSON_VALUE(value, '$.flowRatem3hr') AS FLOAT) AS flowRatem3hr,
    TRY_CAST(JSON_VALUE(value, '$.userGivenUsageLbHr') AS FLOAT) AS userGivenUsageLbHr,
    JSON_VALUE(value, '$.DRAType') AS DRAType
FROM OPENJSON(@DraftDRAData, '$.data');

-- Check if any record in the JSON data does not exist in the main table
IF EXISTS (
    SELECT 1
    FROM @ParsedData pd
    WHERE NOT EXISTS (
        SELECT 1
        FROM bolt_stage.DRA_Details  mt
        WHERE mt.station = pd.station AND mt.DRAType = pd.DRAType and mt.publishedFlowRatem3hr=Pd.flowRatem3hr  and mt.draSummaryID=@DRASummaryID
    )
)
BEGIN
    -- Raise an error if any record does not exist
	SET @StatusCode = 400;-- Indicate faliure--
   SET @StatusMessage =  'One or more  records do not exist in the DRA Detail  table.';
   Rollback tran;
   return;

END;


	update   D  set  D.userGivenUsageLbHr=P.userGivenUsageLbHr,
	[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
	 FROM bolt_stage.DRA_Details  D
    INNER JOIN @ParsedData P
        ON D.station = P.station and D.publishedFlowRatem3hr=P.flowRatem3hr  and d.draType=p.DRAType
    WHERE D.DRASummaryID = @DRASummaryID;

		
			SET @StatusCode = 201;-- Indicate success--data inserted
			   SET @StatusMessage = 'DRA Details updated successfully.';


			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
