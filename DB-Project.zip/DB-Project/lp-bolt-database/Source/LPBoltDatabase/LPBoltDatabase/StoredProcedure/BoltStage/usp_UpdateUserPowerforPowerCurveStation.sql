﻿
CREATE PROCEDURE [bolt_stage].[usp_UpdateUserPowerforPowerCurveStation] @PowerCurveDetailID INT
	,@UserPowerCurveData  NVARCHAR(max)
	,@StatusMessage NVARCHAR(4000) OUTPUT
	,@StatusCode INT OUTPUT
	,@username VARCHAR(255)
	,@userid VARCHAR(255)
	,@userguid UNIQUEIDENTIFIER
AS

/*Declare @PowerCurveDetailID INT
	,@UserPowerCurveData  NVARCHAR(max)
	,@StatusMessage NVARCHAR(4000) 
	,@StatusCode INT 
	,@username VARCHAR(255)
	,@userid VARCHAR(255)
	,@userguid UNIQUEIDENTIFIER

	set @PowerCurveDetailID = 1708
	set @UserPowerCurveData = N'{"data":{"flowData":[{"flowRate":2980,"userPowerKW":4050},{"flowRate":3400,"userPowerKW":4030},{"flowRate":4000,"userPowerKW":4000},{"flowRate":4250,"userPowerKW":4020},{"flowRate":4500,"userPowerKW":4040},{"flowRate":4750,"userPowerKW":4010},{"flowRate":5000,"userPowerKW":-1},{"flowRate":5150,"userPowerKW":4070},{"flowRate":5300,"userPowerKW":35000},{"flowRate":5450,"userPowerKW":4080},{"flowRate":5600,"userPowerKW":4090}]}}'
	set @userid = '12345re'*/

BEGIN
	BEGIN TRY
		BEGIN TRANSACTION;

		--DECLARE @FlowRate NVARCHAR(100) = JSON_VALUE(@UserPowerCurveData, '$.data.flowRate');
		--DECLARE @userPowerKW FLOAT = JSON_VALUE(@UserPowerCurveData, '$.data.userPowerKW');
		
		 DECLARE @FlowRateData NVARCHAR(MAX);

        SET @FlowRateData = JSON_QUERY(@UserPowerCurveData, '$.data.flowData');

		 -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM PowerCurve PC inner join PowerCurveDetails PCD on PC.powerCurveID=PCD.powerCurveID 
		and PowerCurveDetailID=@PowerCurveDetailID AND Pc.status = 'DRAFT') < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END


		
        -- Temporary table to hold FlowRate Data
        CREATE TABLE #FlowRateData (FlowRate float, UserPowerKWH float);
		  INSERT INTO #FlowRateData (FlowRate, UserPowerKWH)
           SELECT flowRate, userPowerKWH
				FROM OPENJSON(@UserPowerCurveData, '$.data.flowData')
				WITH (
					flowRate INT '$.flowRate',
					userPowerKWH INT '$.userPowerKW'
				);


			---If record exists in Power curve station detail corresponding to flow rate and power curve detail id.
			If  (SELECT  CASE 
						WHEN (SELECT COUNT(*) FROM #FlowRateData) = (SELECT COUNT(*) from powercurvestationdetails where powercurvedetailid =@PowerCurveDetailID) 
						AND NOT EXISTS (
										 SELECT FlowRate FROM #FlowRateData
										 EXCEPT
										 SELECT FlowRate FROM powercurvestationdetails where powercurvedetailid =@PowerCurveDetailID
										)
						AND NOT EXISTS (
										  SELECT FlowRate FROM powercurvestationdetails where powercurvedetailid =@PowerCurveDetailID
										 EXCEPT
										 SELECT FlowRate FROM #FlowRateData
										)
						THEN 'Match' ELSE 'No Match' END AS Result ) = 'No Match' 
			BEGIN
				SET @StatusCode = 400; 
				SET @StatusMessage = 'Flow Rates don''t match.';
				INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
				VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
				ROLLBACK TRANSACTION;
				RETURN;
			END
			ELSE
			BEGIN
			 update S set  S.userPowerKwh=F.UserPowerKWH,
			 [updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()),
			status='USERPOWERKWH_CHANGED'
			 from #FlowRateData  F inner join PowerCurveStationDetails S on S.flowRate=F.FlowRate and S.powerCurveDetailID=@PowerCurveDetailID

			 --also need to update satus in power curve detail , so that can recalculate the polynomial/exponentil	based on the userpower KWH
			 update PowerCurveDetails set status='NEW',
			 ---update  details------
			selectedCurveFitMethod=null,
				polynomialCalculatedA=null,
				polynomialCalculatedB=null,
				polynomialCalculatedC=null,
				exponentialCalculatedA=null,
				exponentialCalculatedB=null,
				exponentialRSquare=null,
				polynomialRSquare=null,
			 [updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
			 where PowerCurveDetailID=@PowerCurveDetailID;

			END

			drop table #FlowRateData;
			SET @StatusCode = 200;
			SET @StatusMessage = 'User Power kwh updated successfully for Power curve detailId is ' + Cast(@PowerCurveDetailID AS VARCHAR(50));
		

		COMMIT TRANSACTION;
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;

		SET @StatusCode = 0;
		SET @StatusMessage = ERROR_MESSAGE();

		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@StatusMessage
			,ERROR_SEVERITY()
			,ERROR_STATE()
			,GETDATE()
			);

		THROW;
	END CATCH
END;


