﻿CREATE PROCEDURE [bolt_stage].[usp_PublishDRA] @DRASummaryID INT
	,@StatusMessage NVARCHAR(4000) OUTPUT
	,@StatusCode INT OUTPUT
	,@username VARCHAR(255)
	,@userid VARCHAR(255)
	,@userguid UNIQUEIDENTIFIER
AS
BEGIN
	BEGIN TRY
		BEGIN
			BEGIN TRANSACTION

			--validate DRA
			IF EXISTS (
					SELECT 1
					FROM bolt_stage.DRASummary
					WHERE DRASummaryID = @DRASummaryID
					)
			BEGIN
				-- validate DRA status should be in 'Draft'
				IF EXISTS (
						SELECT 1
						FROM bolt_stage.DRASummary
						WHERE DRASummaryID = @DRASummaryID
							AND STATUS = 'DRAFT'
						)
				BEGIN
					DECLARE @Line AS VARCHAR(20);

					SELECT @Line = line
					FROM bolt_stage.DRASummary
					WHERE DRASummaryID = @DRASummaryID
						AND STATUS = 'DRAFT'



						---To check if applicablesatrtDate in DRA is belongs to future
							IF EXISTS (
									SELECT 1
									FROM bolt_stage.DRASummary
									WHERE cast(applicableDateStart as date) <cast(GETDATE() as date)
										AND DRASummaryID = @DRASummaryID
									)
							BEGIN
								SET @StatusCode = 406;---Http Not accepted
								SET @StatusMessage = 'Applicable start date  belongs to past date';
								Rollback Tran;

								RETURN;
							END

							ELSE
							BEGIN
								
								
									
									---find all published  DRA where Period overlaps with current DRASummaryID period 								
									DECLARE @CurrentStartDate DATE;
									DECLARE @CurrentEndDate DATE;

									SELECT @CurrentStartDate = applicableDateStart---20 Dec 2024
										,@CurrentEndDate = applicableDateEnd---20 jan 2025
									FROM bolt_stage.DRASummary
									WHERE DRASummaryID = @DRASummaryID;

									-- Update overlapping published power curves to "archived" status
									IF exists ( select 1 from bolt_stage.DRASummary
									WHERE STATUS = 'PUBLISHED' -- Only consider published DRA
										AND DRASummaryID <> @DRASummaryID and line=@Line -- Exclude the current DRA
										-- Check for overlapping periods
									AND	applicableDateStart <= @CurrentEndDate and (applicableDateEnd >= @CurrentStartDate or applicableDateEnd >= @CurrentEndDate))
									BEGIN
										SET @StatusCode = 202;---Http Not accepted

									  SET @StatusMessage='The record could not be published because the dates overlap with another Published record';
								    Rollback Tran;
								RETURN;
	
									END

									--for all flowrates for all stations userGiven cannot be null

									IF exists ( select 1 from bolt_stage.DRASummary S inner join bolt_stage.DRA_Details D on S.draSummaryID=D.draSummaryID
										AND S.DRASummaryID= @DRASummaryID and line=@Line and D.userGivenUsageLbHr is null)
										BEGIN
									SET @StatusCode = 406;---Http Not accepted
								     SET @StatusMessage = 'For all flowrates for all stations userGivenUsageLbHr cannot be null';
								    Rollback Tran;
								   RETURN;
										END
										
									---set status=PUBLISHE  where DRASummaryID=x
									UPDATE bolt_stage.DRASummary
									SET STATUS = 'PUBLISHED',
								    [updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
									[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
									[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()),
									updatedDateTime= getdate()
									WHERE DRASummaryID = @DRASummaryID

									SET @StatusCode = 200;---Http  ok successfull
									SET @StatusMessage = 'Published Successfully.';
									COMMIT TRANSACTION
								
							
						END
					
				END
				ELSE
				BEGIN
					SET @StatusCode = 406;---Http Not accepted
					SET @StatusMessage = 'DRA not in draft Status.';
					Rollback Tran;

					RETURN;
				END
			END
			ELSE
			BEGIN
				SET @StatusCode = 406;---Http Not accepted
				SET @StatusMessage = 'Invalid DRA Id.';
				Rollback tran;

				RETURN;
			END

			
		END
	END TRY

	BEGIN CATCH
		-- Handle the error
		ROLLBACK TRANSACTION

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;


