﻿CREATE PROCEDURE [bolt_stage].[usp_DuplicatePowerCurveData]
    @PowerCurveID INT,
    @StatusMessage NVARCHAR(4000) OUTPUT,
    @StatusCode INT OUTPUT,
    @username VARCHAR(255),
    @userid VARCHAR(255),
    @userguid UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Variables for date calculations
        DECLARE @StartDate DATE = DATEADD(DAY, 1, GETDATE());
        DECLARE @EndDate DATE = DATEADD(DAY, 46, GETDATE());
        DECLARE @NewPowerCurveID INT;




			--validate Power curveID
			IF not EXISTS (
					SELECT 1
					FROM PowerCurve
					WHERE powerCurveID = @PowercurveID
					)
			BEGIN
			   SET @StatusMessage = 'Power Curve ID ' +Cast( @PowerCurveID as varchar(10))+ ' not exists in the system';
        SET @StatusCode = 400;
		Return;
			END
        -- Temporary table to store old and new IDs mapping
        DECLARE @DetailIDMapping TABLE (
            OldPowerCurveDetailID INT,
            NewPowerCurveDetailID INT
        );

        -- Duplicate PowerCurve data
        INSERT INTO [bolt_stage].[PowerCurve] (
            [line],
            [title],
            [applicableDateStart],
            [applicableDateEnd],
            [historicalDates],
            [updatedByUserId],
            [updatedByUserGUID],
            [updatedByUserName],
            [lastUpdateDateTime],
            [createdByUserId],
            [createdByUserGUID],
            [createdByUserName],
            [isFavourite],
            [status]
        )
        SELECT
            [line],
            [title]  + ' - Duplicate'  as title,
            @StartDate AS [applicableDateStart],
            @EndDate AS [applicableDateEnd],
            [historicalDates],
            @userid AS [updatedByUserId],
            @userguid AS [updatedByUserGUID],
            @username AS [updatedByUserName],
            GETDATE() AS [lastUpdateDateTime],
            @userid AS [createdByUserId],
            @userguid AS [createdByUserGUID],
            @username AS [createdByUserName],
           0,
            'DRAFT' AS [status]
        FROM [bolt_stage].[PowerCurve]
        WHERE powerCurveID = @PowerCurveID;

        SET @NewPowerCurveID = SCOPE_IDENTITY();

        -- Duplicate PowerCurveDetails data and capture Old -> New ID mapping
        INSERT INTO [bolt_stage].[PowerCurveDetails] (
            [powerCurveID],
            [line],
            [station],
            [applicableDateRangeStart],
            [applicableDateRangeEnd],
            [historicalDateRange],
            [selectedCurveFitMethod],
            [polynomialCalculatedA],
            [polynomialCalculatedB],
            [polynomialCalculatedC],
            [polynomialRSquare],
            [exponentialCalculatedA],
            [exponentialCalculatedB],
            [exponentialRSquare],
            [userInputA],
            [userInputB],
            [userInputC],
            [updatedByUsername],
            [updatedByUserId],
            [updatedbyUserGUID],
            [lastUpdatedDateTime],
            [status],
            [createdByUserId],
            [createdByUserGUID],
            [createdByUserName]
        )
        --OUTPUT INSERTED.PowerCurveDetailID, 
        --       (SELECT PowerCurveDetailID 
        --        FROM [bolt_stage].[PowerCurveDetails] 
        --        WHERE PowerCurveDetailID = @PowerCurveID) as P INTO @DetailIDMapping (NewPowerCurveDetailID, OldPowerCurveDetailID)
        SELECT
            @NewPowerCurveID,
            [line],
            [station],
            @StartDate AS [applicableDateRangeStart],
            @EndDate AS [applicableDateRangeEnd],
            [historicalDateRange],
            [selectedCurveFitMethod],
            [polynomialCalculatedA],
            [polynomialCalculatedB],
            [polynomialCalculatedC],
            [polynomialRSquare],
            [exponentialCalculatedA],
            [exponentialCalculatedB],
            [exponentialRSquare],
            [userInputA],
            [userInputB],
            [userInputC],
            @username AS [updatedByUsername],
            @userid AS [updatedByUserId],
            @userguid AS [updatedbyUserGUID],
            GETDATE() AS [lastUpdatedDateTime],
             status AS [status],
            @userid AS [createdByUserId],
            @userguid AS [createdByUserGUID],
            @username AS [createdByUserName]
        FROM [bolt_stage].[PowerCurveDetails]
        WHERE powerCurveID = @PowerCurveID;

		-- Insert old and new PowerCurveDetailID mappings into the @DetailIDMapping table
INSERT INTO @DetailIDMapping (NewPowerCurveDetailID, OldPowerCurveDetailID)
SELECT
    NewPowerCurve.PowerCurveDetailID AS NewPowerCurveDetailID,
    OldPowerCurve.PowerCurveDetailID AS OldPowerCurveDetailID
FROM
    [bolt_stage].[PowerCurveDetails] OldPowerCurve
INNER JOIN
    [bolt_stage].[PowerCurveDetails] NewPowerCurve
    ON OldPowerCurve.line = NewPowerCurve.line
    AND OldPowerCurve.station = NewPowerCurve.station
    AND OldPowerCurve.historicalDateRange = NewPowerCurve.historicalDateRange
WHERE
    OldPowerCurve.powerCurveID = @PowerCurveID
    AND NewPowerCurve.powerCurveID = @NewPowerCurveID;


        -- Duplicate PowerCurveStationDetails
        INSERT INTO [bolt_stage].[PowerCurveStationDetails] (
            [powerCurveDetailID],
            [powerCurveID],
            [line],
            [station],
            [flowRate],
            [count],
referencePowerKwh,
            [userPowerKwh],
        
            [status],
            [lastUpdatedDateTime],
            [updatedByUsername],
            [updatedByUserId],
            [updatedbyUserGUID],
            [createdByUserId],
            [createdByUserGUID],
            [createdByUserName]
        )
        SELECT
            M.NewPowerCurveDetailID,
            @NewPowerCurveID,
            S.[line],
            S.[station],
            S.[flowRate],
            S.[count],
            S.referencePowerKwh,
            S.[userPowerKwh],
           
            'DRAFT' AS [status],
            GETDATE() AS [lastUpdatedDateTime],
            @username AS [updatedByUsername],
            @userid AS [updatedByUserId],
            @userguid AS [updatedbyUserGUID],
            @userid AS [createdByUserId],
            @userguid AS [createdByUserGUID],
            @username AS [createdByUserName]
        FROM [bolt_stage].[PowerCurveStationDetails] S
        INNER JOIN @DetailIDMapping M
            ON S.powerCurveDetailID = M.OldPowerCurveDetailID;

        -- Success response2n
        SET @StatusMessage = cast(@NewPowerCurveID  as varchar(10))  ;
        SET @StatusCode = 200;
    END TRY
    BEGIN CATCH
        -- Error handling
        SET @StatusMessage = ERROR_MESSAGE();
        SET @StatusCode = 400;
    END CATCH
END;