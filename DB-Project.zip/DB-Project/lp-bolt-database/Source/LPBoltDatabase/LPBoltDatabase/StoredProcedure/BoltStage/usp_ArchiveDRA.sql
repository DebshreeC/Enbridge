﻿
CREATE PROCEDURE [bolt_stage].[usp_ArchiveDRA] 
@DRASummaryID int,
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username VARCHAR(255),
    @userid VARCHAR(255),
    @userguid UNIQUEIDENTIFIER

AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
		-- Validate DRASummaryID
        IF (SELECT COUNT(1) FROM bolt_stage.DRASummary WHERE draSummaryID = @DRASummaryID )<1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid DRASummaryID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END

		ELSE
		BEGIN

		IF (SELECT COUNT(1) FROM bolt_stage.DRASummary WHERE draSummaryID = @DRASummaryID and status='Published')<1
		BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'DRA not in published status.';
		END
		 ELSE
		 BEGIN
			UPDATE bolt_stage.DRASummary
                   SET status='ARCHIVED',
				   updatedDateTime=getdate(),
				   	[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
                         WHERE draSummaryID = @DRASummaryID;
			   SET @StatusCode = 200; 
            SET @StatusMessage = 'Done successfully.';

		 END
		 
		END




        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
GO


