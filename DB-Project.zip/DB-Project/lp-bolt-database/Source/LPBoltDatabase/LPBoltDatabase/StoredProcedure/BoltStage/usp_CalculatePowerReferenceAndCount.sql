﻿
CREATE PROCEDURE [bolt_stage].[usp_CalculatePowerReferenceAndCount]
    @PowerCurveId INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY

        BEGIN TRANSACTION


		   --DELETE FROM bolt_stage.PowerCurveStationDetails WHERE powerCurveID = @PowerCurveId;
		   delete from bolt_stage.PowerCurveStationDetails where powerCurveDetailID in (select powerCurveDetailID  from bolt_stage.PowerCurveDetails where powerCurveID = @PowerCurveId and status = 'NEW')
		   and  powerCurveID = @PowerCurveId 
		   and status<>'USERPOWERKWH_CHANGED'

        -- Use the CTE and immediately insert data into PowerCurveStationDetails
        ;WITH PowerCurveData AS (
           SELECT 
                PC.PowerCurveDetailID,
                PC.Line,
                PC.Station,
                PC.HistoricalDateRange,
				COALESCE(Max(PC.updatedByUserId),Max(PC.[createdByUserId])) as [UserId],COALESCE(Max(PC.updatedByUsername),Max(PC.[createdByUserName])) as [UserName],COALESCE(max(PC.updatedbyUserGUID),max(PC.[createdByUserGUID])) as [UGuid],
                ISNULL(DA.FlowRateFinal_m3hr,FR.publishedFlowRatem3hr) as FlowRateFinal_m3hr,
             isnull( SUM(DA.AveragePowerDefault_kW * DA.DataPointsCount),0) AS Calc1,
           isnull(SUM(DA.DataPointsCount),0) AS DataPointsCount
            FROM 
                bolt_stage.PowerCurveDetails PC 
            INNER JOIN 
                bolt_stage.PowerCurve P ON PC.powerCurveID = P.powerCurveID
				left join bolt_stage.PublishedFlowRates FR on P.line=FR.Line 

				  CROSS APPLY 
                OPENJSON(PC.historicalDateRange) 
                WITH (
                    startDate DATE '$.startDate',
                    endDate DATE '$.endDate'
                ) AS DateRanges
            LEFT JOIN 
                bolt_stage.Daily_PowerPI_Avg DA ON DA.Line = PC.Line AND DA.Station = PC.Station  and FR.publishedFlowRatem3hr=DA.FlowRateFinal_m3hr
				  AND DA.Date BETWEEN ISNULL(DateRanges.startDate, '1900-01-01') AND ISNULL(DateRanges.endDate, '9999-12-31')
          
            WHERE 
               PC.status = 'NEW' and
                 PC.powerCurveID = @PowerCurveId 
           and PC.PowerCurveDetailID  not in (select PowerCurveDetailID from bolt_stage.PowerCurveStationDetails where powerCurveID=@PowerCurveId 
		   and status='USERPOWERKWH_CHANGED'
		   )
            GROUP BY 
                PC.PowerCurveDetailID,
                PC.Line,
                PC.Station,
                PC.HistoricalDateRange,
                isnull(DA.FlowRateFinal_m3hr,FR.publishedFlowRatem3hr))
 

        INSERT INTO bolt_stage.PowerCurveStationDetails (powerCurveDetailID, powerCurveID, line, station, flowRate, referencePowerKwh, userPowerKwh, [count],[createdByUserId],[createdByUserName],[createdByUserGUID],Status)
        SELECT 
            PCD.PowerCurveDetailID, 
            @PowerCurveId, 
            PCD.Line, 
            PCD.Station, 
            PCD.FlowRateFinal_m3hr, 
          isnull( Round( SUM(PCD.Calc1) / NULLIF(SUM(PCD.DataPointsCount), 0),0),0) AS ReferencePowerKwh,
			--Added by nidhi on 25th Nov as discussed by default should insert hte same value in userpowerKwh  as  in the ReferencePowerKwh
			          isnull(  Round(SUM(PCD.Calc1) / NULLIF(SUM(PCD.DataPointsCount), 0),0) ,0)userPowerKwh,

            SUM(PCD.DataPointsCount),max(userid),max(username),max(uguid),'loaded'
        FROM 
            PowerCurveData PCD
        GROUP BY 
            PCD.PowerCurveDetailID, 
            PCD.Line, 
            PCD.Station, 
            PCD.FlowRateFinal_m3hr;

        COMMIT TRANSACTION
        PRINT 'commit';

    END TRY
    BEGIN CATCH
        PRINT 4;
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        --INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        --VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

        THROW;  -- Re-throw the error
    END CATCH
END;
