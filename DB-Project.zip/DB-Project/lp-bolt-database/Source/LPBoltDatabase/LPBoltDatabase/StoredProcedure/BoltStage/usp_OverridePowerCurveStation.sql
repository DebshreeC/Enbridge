﻿
CREATE PROCEDURE [bolt_stage].[usp_OverridePowerCurveStation] @PowerCurveDetailID INT
	,@OverridePowerCurveData NVARCHAR(max)
	,@StatusMessage NVARCHAR(4000) OUTPUT
	,@StatusCode INT OUTPUT
	,@username VARCHAR(255)
	,@userid VARCHAR(255)
	,@userguid UNIQUEIDENTIFIER
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION;

		DECLARE @SelectedCurvefitMethod NVARCHAR(100) = JSON_VALUE(@OverridePowerCurveData, '$.data.selectedCurveFitMethod');
		DECLARE @userInputA FLOAT = JSON_VALUE(@OverridePowerCurveData, '$.data.userInputA');
		DECLARE @userInputB FLOAT = JSON_VALUE(@OverridePowerCurveData, '$.data.userInputB');
		DECLARE @userInputC FLOAT = JSON_VALUE(@OverridePowerCurveData, '$.data.userInputC');


		print @SelectedCurvefitMethod;
		IF (select count(*) from  bolt_stage.PowerCurvedetails where PowerCurveDetailID=@PowerCurveDetailID) < 1
		BEGIN
			SET @StatusCode = 406;
			SET @StatusMessage = 'Invalid powercurve detail id ' + Cast(@PowerCurveDetailID AS VARCHAR(50));
			ROLLBACK TRAN
			RETURN
		END
		IF (
				@SelectedCurvefitMethod = 'EXPONENTIAL'
				OR @SelectedCurvefitMethod = 'POLYNOMIAL'
				OR @SelectedCurvefitMethod = 'OVERRIDE-P'
				OR @SelectedCurvefitMethod = 'OVERRIDE-E'
				)
		BEGIN
			IF (
					@SelectedCurvefitMethod = 'EXPONENTIAL'
					OR @SelectedCurvefitMethod = 'POLYNOMIAL'
					)
			BEGIN
				UPDATE bolt_stage.PowerCurveDetails
				SET selectedCurveFitMethod = @SelectedCurvefitMethod
				WHERE PowerCurveDetailID = @PowerCurveDetailID
			END
			ELSE
			BEGIN
				IF (@SelectedCurvefitMethod = 'OVERRIDE-P')
				BEGIN
					IF (
							@userInputA != 0
							AND @userInputC != 0
							AND @userInputB != 0
							)
					BEGIN
						UPDATE bolt_stage.PowerCurveDetails
						SET selectedCurveFitMethod = @SelectedCurvefitMethod
							,userInputA = @userInputA
							,userInputB = @userInputB
							,userInputC = @userInputC
							,lastUpdatedDateTime= getdate()
							,updatedByUserId= COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID()))
							,updatedByUserguid= COALESCE(NULLIF(@userguid,NEWID()),NEWID())
							,updatedByUserName= COALESCE(NULLIF(@username,''),SUSER_NAME())
						WHERE PowerCurveDetailID = @PowerCurveDetailID
					END
					ELSE
					BEGIN
						SET @StatusCode = 406;
						SET @StatusMessage = 'UserInput value can not be 0.';
					END
				END
				ELSE
				BEGIN
					IF (
							@userInputA != 0
							AND @userInputB != 0
							)
					BEGIN
						UPDATE bolt_stage.PowerCurveDetails
						SET selectedCurveFitMethod = @SelectedCurvefitMethod
							,userInputA = @userInputA
							,userInputB = @userInputB
							,lastUpdatedDateTime= getdate()
							,updatedByUserId= COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID()))
							,updatedByUserguid= COALESCE(NULLIF(@userguid,NEWID()),NEWID())
							,updatedByUserName= COALESCE(NULLIF(@username,''),SUSER_NAME())
						WHERE PowerCurveDetailID = @PowerCurveDetailID
					END
					ELSE
					BEGIN
						SET @StatusCode = 406;
						SET @StatusMessage = 'UserInput value can not be 0.';
					END
				END
			END

			SET @StatusCode = 200;
			SET @StatusMessage = 'Override station successfully for Power curve detailId is ' + Cast(@PowerCurveDetailID AS VARCHAR(50));
		END
		ELSE
		BEGIN
			SET @StatusCode = 406;
			SET @StatusMessage = 'Invalid curve fit method selected';
		END

		COMMIT TRANSACTION;
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;

		SET @StatusCode = 0;
		SET @StatusMessage = ERROR_MESSAGE();

		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@StatusMessage
			,ERROR_SEVERITY()
			,ERROR_STATE()
			,GETDATE()
			);

		THROW;
	END CATCH
END;
