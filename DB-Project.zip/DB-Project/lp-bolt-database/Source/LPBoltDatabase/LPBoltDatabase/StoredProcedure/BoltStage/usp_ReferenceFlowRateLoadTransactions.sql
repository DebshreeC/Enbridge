﻿
CREATE PROCEDURE [bolt_stage].[usp_ReferenceFlowRateLoadTransactions] 
@OptimusUpdateSuccessFlag BIT, @ReferenceFlowRateData NVARCHAR(MAX), @Ref BIT = 0
AS
BEGIN
	BEGIN TRY
		Begin Transaction
		if (@OptimusUpdateSuccessFlag = 1)
		Begin
			
			TRUNCATE Table [bolt_stage].[ReferenceFlowRates];
			INSERT INTO [bolt_stage].[ReferenceFlowRates]
				([Region]
				,[Line]
				,[refFlowRatem3hr]
				,[refFlowRateUpdatedDateTime])
			
				SELECT
				--JSON_VALUE(value,'$.region') AS Region,
				REPLACE(REPLACE(JSON_VALUE(value,'$.region') , CHAR(9), ''), '[^A-Za-z0-9 ]', '') AS Region,
				--JSON_VALUE(value,'$.line') AS Line,
				REPLACE(REPLACE(JSON_VALUE(value,'$.line') , CHAR(9), ''), '[^A-Za-z0-9 ]', '') As Line,
				JSON_VALUE(value,'$.refFlowRatem3hr') AS refFlowRatem3hr,
				JSON_VALUE(value,'$.refFlowRateUpdatedDateTime') AS refFlowRateUpdatedDateTime
				FROM OPENJSON (@ReferenceFlowRateData); 

		End
		if (@Ref = 0)
				Begin
					IF (SELECT COUNT(1) FROM [bolt_stage].[DraftFlowRates])  < 1
						INSERT INTO [bolt_stage].[DraftFlowRates]
						([Region]
						,[Line]
						,[draftFlowRatem3hr]
						,[draftFlowRateUpdatedDateTime])
        				SELECT 
								[Region]
								,[Line]
								,[publishedFlowRatem3hr]
								,[publishedFlowRateUpdatedDateTime]
						FROM [bolt_stage].[PublishedFlowRates]
				End
		Else
			Begin
				TRUNCATE TABLE [bolt_stage].[DraftFlowRates];
				INSERT INTO [bolt_stage].[DraftFlowRates]
				([Region]
				,[Line]
				,[draftFlowRatem3hr]
				,[draftFlowRateUpdatedDateTime])
        		SELECT 
						[Region]
						,[Line]
						,[refFlowRatem3hr]
						,GetDate()
				FROM [bolt_stage].[ReferenceFlowRates]
			End
			--else display existing data
		Commit Transaction
	END TRY
	BEGIN CATCH
		-- Handle the error
		Commit Transaction
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
		VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;

