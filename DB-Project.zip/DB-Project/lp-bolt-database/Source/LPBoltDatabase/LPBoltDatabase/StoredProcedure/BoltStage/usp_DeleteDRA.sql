﻿
CREATE PROCEDURE [bolt_stage].[usp_DeleteDRA] 
@DRASummaryID int,
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT

AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
		-- Validate DRASummaryID
        IF (SELECT COUNT(1) FROM bolt_stage.DRASummary WHERE draSummaryID = @DRASummaryID )<1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid DRASummaryID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END

		ELSE
		BEGIN

		IF (SELECT COUNT(1) FROM bolt_stage.DRASummary WHERE draSummaryID = @DRASummaryID and status='Draft')<1
		BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'DRA not in draft status.';
		END
		 ELSE
		 BEGIN
			 delete from bolt_stage.DRA_Details where draSummaryID=@DRASummaryID
			 delete from bolt_stage.DRASummary where draSummaryID=@DRASummaryID
			 delete from bolt_stage.Comments where refID=@DRASummaryID
			 and ref='DRA'

			   SET @StatusCode = 200; 
            SET @StatusMessage = 'DRA deleted successfully.';


		 END
		 
		END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;

