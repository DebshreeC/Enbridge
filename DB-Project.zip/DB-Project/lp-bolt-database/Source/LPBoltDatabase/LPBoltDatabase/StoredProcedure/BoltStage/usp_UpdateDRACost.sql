﻿
CREATE PROCEDURE [bolt_stage].[usp_UpdateDRACost] 
@DraftDRACostData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier
	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
	
  
-- Declare a table variable to hold the parsed JSON data
DECLARE @ParsedData TABLE (
   DRAType varchar(50),
   Density float,
   CostPerGalCAD float,
   CostPerLBCAD  float

);

-- Insert JSON data into the table variable
INSERT INTO @ParsedData (DRAType,Density,CostPerGalCAD,CostPerLBCAD)
SELECT 
  JSON_VALUE(value, '$.DRAType') AS DRAType,
    TRY_CAST(JSON_VALUE(value, '$.Density') AS float) AS Density,
	 TRY_CAST(JSON_VALUE(value, '$.CostPerGalCAD') AS float) AS CostPerGalCAD,
	  TRY_CAST(JSON_VALUE(value, '$.CostPerLBCAD') AS float) AS CostPerLBCAD
FROM OPENJSON(@DraftDRACostData, '$.data');


	update   D  set 
	D.costPerGalCAD=P.CostPerGalCAD,
	D.density=P.density,
	D.costPerLbCAD=P.costPerLbCAD,
	updatedDateTime = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
	 FROM bolt_stage.DRA_Cost  D
    INNER JOIN @ParsedData P
        ON D.DRAType=P.DRAType
  

		
			SET @StatusCode = 201;-- Indicate success--data inserted
			   SET @StatusMessage = 'DRA cost updated successfully.';


			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;

