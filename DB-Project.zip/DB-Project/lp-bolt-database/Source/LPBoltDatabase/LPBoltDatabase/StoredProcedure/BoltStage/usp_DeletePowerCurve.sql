﻿
CREATE PROCEDURE [bolt_stage].[usp_DeletePowerCurve] 
@PowerCurveId int,
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT

AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
		-- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM bolt_stage.PowerCurve WHERE powerCurveID = @PowerCurveId )<1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            ROLLBACK TRANSACTION;
            RETURN;
        END

		ELSE
		BEGIN

		IF (SELECT COUNT(1) FROM bolt_stage.PowerCurve WHERE powerCurveID = @PowerCurveId and status='Draft')<1
		BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Power curve not in draft status.';
		END
		 ELSE
		 BEGIN
			 delete from bolt_stage.PowerCurveStationDetails where powerCurveID=@PowerCurveId
			 delete from bolt_stage.PowerCurveDetails where powerCurveID=@PowerCurveId
			 delete from bolt_stage.Comments where refID=@PowerCurveId
			 delete from bolt_stage.PowerCurve where powerCurveID=@PowerCurveId;

			   SET @StatusCode = 200; 
            SET @StatusMessage = 'Power curve Id deleted successfully.';


		 END
		 
		END




        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;
