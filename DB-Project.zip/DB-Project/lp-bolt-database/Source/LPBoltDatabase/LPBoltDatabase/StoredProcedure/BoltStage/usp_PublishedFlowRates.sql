﻿
CREATE procedure [bolt_stage].[usp_PublishedFlowRates]
as
begin

		
		WITH cte0 AS
		(select ID,Region,Line,publishedFlowRatem3hr,publishedFlowRateUpdatedDateTime
		 from bolt_stage.PublishedFlowRates
		 where minpublishedFlowRatem3hr is null and 
			   maxpublishedFlowRatem3hr is null
		 ),cte1 as
		   (SELECT *, 
				   LAG(publishedFlowRatem3hr) OVER (PARTITION BY line,region,cast(publishedFlowRateUpdatedDateTime as date) ORDER BY publishedFlowRatem3hr) AS prev_rate,
				   LEAD(publishedFlowRatem3hr) OVER (PARTITION BY line,region,cast(publishedFlowRateUpdatedDateTime as date) ORDER BY publishedFlowRatem3hr) AS next_rate,
				   ROW_NUMBER() OVER (PARTITION BY line,region,cast(publishedFlowRateUpdatedDateTime as date) ORDER BY publishedFlowRatem3hr) AS row_num
			FROM cte0
		),cte2 AS 
		  (
			SELECT *, 
				   MAX(row_num) OVER (PARTITION BY line,region,cast(publishedFlowRateUpdatedDateTime as date)) AS max_row_num
			FROM cte1
		  ),cte3 AS
			(SELECT *,
				   CASE 
					  WHEN row_num = max_row_num THEN publishedFlowRatem3hr + ((publishedFlowRatem3hr - prev_rate) / 2)
					  ELSE publishedFlowRatem3hr + ((next_rate - publishedFlowRatem3hr) / 2)
				   END AS max_FR
			FROM cte2
		),cte4 AS (
			SELECT ID,line, region, publishedFlowRatem3hr, publishedFlowRateUpdatedDateTime,
				   CASE 
					   WHEN row_num = 1 THEN publishedFlowRatem3hr - ((next_rate - publishedFlowRatem3hr) / 2)
					   WHEN row_num = max_row_num THEN publishedFlowRatem3hr - ((publishedFlowRatem3hr - prev_rate) / 2)
					   ELSE LAG(max_FR) OVER (PARTITION BY line,region,cast(publishedFlowRateUpdatedDateTime as date) ORDER BY publishedFlowRatem3hr) 
				   END AS min_FR,
				   max_FR
			FROM cte3
       )
		UPDATE bolt_stage.PublishedFlowRates
		SET minpublishedFlowRatem3hr = cte4.min_FR,
			maxpublishedFlowRatem3hr = cte4.max_FR
		FROM cte4
		WHERE bolt_stage.PublishedFlowRates.ID = cte4.ID;
		  
 end
