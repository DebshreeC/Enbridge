﻿CREATE PROCEDURE [bolt_stage].[usp_getXYDataPowerCurveGeneration] 
 @PowerCurveDetaild int
AS
BEGIN
    BEGIN TRY    
     
			SELECT   
				CAST(psd.flowRate AS FLOAT) AS XValue,  
			   --- CAST(SUM(AveragePowerDefault_kW * DataPointsCount) / SUM(DataPointsCount) AS FLOAT) AS YValue
					CAST(SUM(COALESCE(psd.userPowerKwh, psd.referencePowerKwh)) as FLOAT) AS YValue

			FROM 
				--[bolt_stage].[Daily_PowerPI_Avg] dp
				[bolt_stage].[PowerCurveStationDetails] psd
			INNER JOIN 
				[bolt_stage].[PowerCurveDetails] pcd 
				ON psd.line = pcd.line 
				AND psd.Station = pcd.station
				and psd.powerCurveDetailID=pcd.PowerCurveDetailID
			INNER JOIN
				[bolt_stage].PowerCurve pc 
				on pc.powerCurveID = pcd.powerCurveID
 			/*LEFT JOIN 
				[bolt_stage].[PowerCurveStationDetails] psd
				ON psd.powerCurveDetailID = pcd.PowerCurveDetailID 
				AND psd.line = dp.line 
				AND psd.flowRate = dp.FlowRateFinal_m3hr*/

			-- Use CROSS APPLY to parse startDate and endDate from historicalDateRange JSON array
			/*CROSS APPLY 
				OPENJSON(pcd.historicalDateRange) 
				WITH (
					startDate DATE '$.startDate',
					endDate DATE '$.endDate'
				) AS DateRanges*/
			WHERE 
				pc.status = 'DRAFT' 
			   AND pcd.status = 'COMPUTING' 
				--AND psd.referencePowerKwh > 0 
				AND psd.userPowerKwh>0
				AND pcd.PowerCurveDetailID = @PowerCurveDetaild
				-- Check if dp.Date is between any startDate and endDate from the JSON array
				--AND dp.Date BETWEEN DateRanges.startDate AND DateRanges.endDate
			GROUP BY 
				psd.line, psd.station, psd.flowRate
			ORDER BY 
				psd.flowRate;

    END TRY
    BEGIN CATCH
        -- Optionally, you can log the error or return an error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
