﻿

CREATE PROCEDURE [bolt_stage].[usp_UpdateDRASummaryDraft] 
@DraftDRAData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

/*Declare @DraftDRAData NVARCHAR(max),
		@StatusMessage NVARCHAR(max),
		@StatusCode INT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier;
		
set @DraftDRAData='{
    "data": {
        "line":"93",
        "title":"Titlee for Testing line 1 via SP",
        "applicableDateStart":"2024-11-16T00:00:00",
        "applicableDateEnd":"2024-11-30T00:00:00"
       
    }
}';
set  @username ='swami siva';
set @userid = '12345t';*/
	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		
  
-- Declare a table variable to hold the parsed JSON data
DECLARE @ParsedData TABLE (
draSummaryID int,
    title NVARCHAR(50),
    applicableDateStart NVARCHAR(50),
    applicableDateEnd NVARCHAR(50),
    heavyPercentage float,
	lightPercentage  float
);

-- Insert JSON data into the table variable
INSERT INTO @ParsedData (draSummaryID, title, applicableDateStart, applicableDateEnd,heavyPercentage,lightPercentage)
SELECT 
    TRY_CAST(JSON_VALUE(value, '$.draSummaryID') AS int) AS draSummaryID,
	    JSON_VALUE(value, '$.title') AS title,
		    JSON_VALUE(value, '$.applicableDateStart') AS applicableDateStart,
    JSON_VALUE(value, '$.applicableDateEnd') AS applicableDateEnd,
    TRY_CAST(JSON_VALUE(value, '$.heavyPercentage') AS FLOAT) AS heavyPercentage,
    TRY_CAST(JSON_VALUE(value, '$.lightPercentage') AS FLOAT) AS lightPercentage
FROM OPENJSON(@DraftDRAData, '$.data');

-- Check if any record in the JSON data does not exist in the main table
IF EXISTS (
    SELECT 1
    FROM @ParsedData pd
    WHERE NOT EXISTS (
        SELECT 1
        FROM bolt_stage.DRASummary  ds
        WHERE ds.draSummaryID=pd.draSummaryID and  ds.status='DRAFT'
    )
)
BEGIN
    -- Raise an error if any record does not exist
	SET @StatusCode = 400;-- Indicate faliure--
   SET @StatusMessage =  'One or more  records do not exist in the DRA Summary table with draft status.';
   Rollback tran;
   return;

END;


	-- Validate applicable dates for all records
IF EXISTS (
    SELECT 1
    FROM @ParsedData pd
    WHERE 
        TRY_CAST(pd.applicableDateStart AS DATE) < CAST(GETDATE() AS DATE) OR
        TRY_CAST(pd.applicableDateEnd AS DATE) < TRY_CAST(pd.applicableDateStart AS DATE)
)
BEGIN
    SET @StatusCode = 400;

    IF EXISTS (
        SELECT 1
        FROM @ParsedData pd
        WHERE TRY_CAST(pd.applicableDateStart AS DATE) < CAST(GETDATE() AS DATE)
    )
    BEGIN
		
        SET @StatusMessage = 'ApplicableDateStart must be greater than the current date.';
    END
    ELSE
    BEGIN
        SET @StatusMessage = 'ApplicableDateEnd must be greater than ApplicableDateStart.';
    END

    ROLLBACK TRAN;
    RETURN;
END;

	
	
	update D
         
           set [applicableDateStart]=p.applicableDateStart
           ,[applicableDateEnd]=p.applicableDateEnd
           ,[title]=p.title
		   ,[heavyPercentage]=p.heavyPercentage
		   ,[lightPercentage]=p.lightPercentage
           ,[updatedByUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID()))
           ,[updatedByUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID())
           ,[updatedByUserName]=COALESCE(NULLIF(@username,''),SUSER_NAME()) 
           ,[updatedDateTime]=getdate()

		   from [bolt_stage].[DRASummary] D inner join @ParsedData  P on D.draSummaryID=P.draSummaryID
		 
         
        
		
			SET @StatusCode = 201;-- Indicate success--data inserted
			   SET @StatusMessage = 'Draft updated successfully.';


			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
