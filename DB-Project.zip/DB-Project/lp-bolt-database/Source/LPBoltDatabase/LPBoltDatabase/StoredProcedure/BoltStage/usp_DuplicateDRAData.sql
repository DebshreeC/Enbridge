﻿CREATE PROCEDURE [bolt_stage].[usp_DuplicateDRAData]
    @DRASummaryID INT,
    @StatusMessage NVARCHAR(4000) OUTPUT,
    @StatusCode INT OUTPUT,
    @username VARCHAR(255),
    @userid VARCHAR(255),
    @userguid UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
	BEGIN TRANSACTION
        -- Variables for date calculations
        --DECLARE @StartDate DATE = DATEADD(DAY, 1, GETDATE());
        --DECLARE @EndDate DATE = DATEADD(DAY, 45, GETDATE());
        DECLARE @NewDRASummaryID INT;


		
	
		--Validate DRA Summary-----------
		IF (
				(
					SELECT count(1)
					FROM bolt_stage.DRASummary 
					WHERE draSummaryID = @DRASummaryID
					) < 1
			)
		BEGIN
			SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Invalid DRA.';

			INSERT INTO bolt_stage.ErrorLog (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
			
			RETURN;
		END

		
	INSERT INTO [bolt_stage].[DRASummary]
           (
           [line]
           ,[applicableDateStart]
           ,[applicableDateEnd]
           ,[title] 
		   ,[heavyPercentage]
		   ,[lightPercentage]
           ,[updatedByUserId]
           ,[updatedByUserGUID]
           ,[updatedByUserName]
           ,[updatedDateTime]
           ,[createdDateTime]
		   ,[createdByUserId]
		   ,[createdByUserGUID]
           ,[createdByUserName]
           ,[status])
     
			SELECT D.line
				,D.applicableDateStart
				,D.applicableDateEnd
			    ,D.title + ' - Duplicate'  as title
				,D.heavyPercentage
				,D.lightPercentage
				,COALESCE(NULLIF(@userid,''),convert(NVARCHAR,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID())
				,COALESCE(NULLIF(@username,''),SUSER_NAME()) 
				,GETDATE()
				,GETDATE()
				,COALESCE(NULLIF(@userid,''),convert(NVARCHAR,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID())
				,COALESCE(NULLIF(@username,''),SUSER_NAME()) 
				,'DRAFT' AS STATUS  -- Change as 
			FROM bolt_stage.DRASummary D 
			WHERE draSummaryID=@DRASummaryID
        SET @NewDRASummaryID = SCOPE_IDENTITY();

		DECLARE @Line VARCHAR(10);
		SELECT  @Line= line   FROM bolt_stage.DRASummary D WHERE draSummaryID=@NewDRASummaryID


			
INSERT INTO [bolt_stage].[DRA_Details]
           ([draSummaryID]
           ,[station]
           ,[publishedFlowRatem3hr]
          ,[referenceUsageLbHr]
          ,[userGivenUsageLbHr]
           ,[draType]
		     ,[updatedByUserId]
           ,[updatedByUserGUID]
           ,[updatedByUserName]
           ,[lastupdateDateTime]
		   ,[createdByUserId]
		   ,[createdByUserGUID]
           ,[createdByUserName])
		   SELECT 
				@NewDRASummaryID
				,  station
				, publishedFlowRatem3hr
				,  sum(isnull(DRARate,0))/Count(publishedFlowRatem3hr) AS referenceUsageLbHr
				, sum(isnull(DRARate,0))/Count(publishedFlowRatem3hr) AS  userGivenUsageLbHr 
				,DRAType 
				,COALESCE(NULLIF(@userid,''),convert(NVARCHAR,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID())
				,COALESCE(NULLIF(@username,''),SUSER_NAME()) 
					,GETDATE(),  
					COALESCE(NULLIF(@userid,''),convert(NVARCHAR,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID())
				,COALESCE(NULLIF(@username,''),SUSER_NAME()) 
			FROM  bolt_stage.DRA_Reference WHERE line=@Line
			AND drarate IS NOT NULL
		   GROUP BY
		    station,publishedFlowRatem3hr,DRAType

			update N SET [userGivenUsageLbHr]=O.[userGivenUsageLbHr]
			FROM
			 [bolt_stage].[DRA_Details]  N INNER JOIN 
			(SELECT station,userGivenUsageLbHr,publishedFlowRatem3hr,referenceUsageLbHr,draType
			FROM  [bolt_stage].[DRA_Details]  WHERE draSummaryID=@DRASummaryID) O
			ON N.station=O.station AND N.publishedFlowRatem3hr=O.publishedFlowRatem3hr AND N.draType=O.draType 
			AND N.referenceUsageLbHr=O.referenceUsageLbHr
			WHERE N.draSummaryID=@NewDRASummaryID

		

        -- Success response2n
        SET @StatusMessage = cast(@NewDRASummaryID  as varchar(10))  ;
        SET @StatusCode = 200;

			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 400;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;