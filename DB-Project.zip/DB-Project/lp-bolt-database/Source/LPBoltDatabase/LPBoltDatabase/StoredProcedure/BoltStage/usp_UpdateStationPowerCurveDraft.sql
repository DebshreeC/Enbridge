﻿CREATE PROCEDURE [bolt_stage].[usp_UpdateStationPowerCurveDraft] 
@PowerCurveDetailId int,
@DraftPowerCurveData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT,
@StatusCode INT OUTPUT,
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

       --DECLARE @Station NVARCHAR(100) = JSON_VALUE(@DraftPowerCurveData, '$.data.station');
        DECLARE @ApplicableDateStart DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateStart');
        DECLARE @ApplicableDateEnd DATETIME = JSON_VALUE(@DraftPowerCurveData, '$.data.applicableDateEnd');
        DECLARE @HistoricDates NVARCHAR(MAX);
		declare @mindate varchar(20), @maxdate varchar(20);
        SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');

	Declare @OldHistoricDate  nvarchar(max);
	
     --   SET @HistoricDates = JSON_QUERY(@DraftPowerCurveData, '$.data.historicDates');
        
        -- Validate PowerCurveID
        IF (SELECT COUNT(1) FROM PowerCurve PC inner join PowerCurveDetails PCD on PC.powerCurveID=PCD.powerCurveID WHERE PCD.PowerCurveDetailID = @PowerCurveDetailId AND PC.status = 'Draft') < 1
        BEGIN
            SET @StatusCode = 400; 
            SET @StatusMessage = 'Invalid PowerCurve ID.';
            INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
            VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());
            COMMIT TRANSACTION;
            RETURN;
        END
		
		declare @PowerCurveId as int ;
		select top 1  @PowerCurveId= PC.powerCurveID FROM PowerCurve PC inner join PowerCurveDetails PCD on PC.powerCurveID=PCD.powerCurveID WHERE PCD.PowerCurveDetailID = @PowerCurveDetailId
		AND PC.status = 'DRAFT'
		
		-- need to validate only applicable dates;
		SELECT @StatusCode= StatusCode,  @StatusMessage=StatusMessage
		FROM bolt_stage.ValidateDates(@HistoricDates, @ApplicableDateStart, @ApplicableDateEnd,'UPDATE STATION'   );
		If(@StatusCode=400)
		BEGIN
		COMMIT TRANSACTION;
		Return;
		END

				    
		IF(@ApplicableDateStart  is not null  and @ApplicableDateEnd  is not null)
		BEGIN
    
     
			UPDATE PD
				SET 
					PD.applicableDateRangeStart = @ApplicableDateStart,
					PD.applicableDateRangeEnd = @ApplicableDateEnd,
						PD.lastUpdatedDateTime = GETDATE(),
						PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
				PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
					FROM [bolt_stage].[PowerCurveDetails] PD
					INNER JOIN [bolt_stage].PowerCurve PC ON PD.powerCurveID = PC.powerCurveID
					INNER JOIN [bolt_stage].LineStationReference LR ON PC.line = LR.line
					WHERE PC.STATUS = 'DRAFT' AND 
					PD.PowerCurveDetailID=@PowerCurveDetailId

	
		END
		    
		IF(@HistoricDates is not null  or @HistoricDates<>'[]' )
		BEGIN
		select @OldHistoricDate= PCD.historicalDateRange FROM PowerCurve PC inner join PowerCurveDetails PCD on PC.powerCurveID=PCD.powerCurveID WHERE PCD.PowerCurveDetailID = @PowerCurveDetailId
		AND PC.status = 'DRAFT' and PC.powerCurveID=@PowerCurveId

		if(@OldHistoricDate<>REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''))
		BEGIN



		  CREATE TABLE #HistoricDates (StartDate DATETIME, EndDate DATETIME);
		  
		INSERT INTO #HistoricDates (StartDate, EndDate)
            SELECT 
                TRY_CAST(JSON_VALUE(value, '$.startDate') AS DATETIME) AS StartDate,
                TRY_CAST(JSON_VALUE(value, '$.endDate') AS DATETIME) AS EndDate
            FROM OPENJSON(@HistoricDates) AS HistoricDates;

		select @mindate = Cast(min(StartDate) as varchar(20)), @maxdate = cast(max(EndDate) as varchar(20)) from #HistoricDates


		
		UPDATE [bolt_stage].[PowerCurve]
        SET 
            [historicalDates] =  '' + @mindate + ',' + @maxdate +'' ,
			[lastUpdateDateTime] = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
        WHERE powerCurveID = @PowerCurveId;

		UPDATE PD
			SET 
		        PD.historicalDateRange=	REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),
				PD.selectedCurveFitMethod=null,
				PD.polynomialCalculatedA=null,
				pd.polynomialCalculatedB=null,
				pd.polynomialCalculatedC=null,
				pd.exponentialCalculatedA=null,
				pd.exponentialCalculatedB=null,
				pd.exponentialRSquare=null,
				pd.polynomialRSquare=null,
				pd.status='NEW',
				PD.lastUpdatedDateTime = GETDATE(),
						PD.[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
				PD.[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				PD.[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()) 
				FROM [bolt_stage].[PowerCurveDetails] PD
				INNER JOIN [bolt_stage].PowerCurve PC ON PD.powerCurveID = PC.powerCurveID
				INNER JOIN [bolt_stage].LineStationReference LR ON PC.line = LR.line
				WHERE PowerCurveDetailID=@PowerCurveDetailId

				    -- Clean up temporary table
        DROP TABLE #HistoricDates;

		END
			  END





	
			--	-- Update PowerCurve
			--UPDATE [bolt_stage].PowerCurveDetails
			--SET 
			--	applicableDateRangeStart = @ApplicableDateStart,
			--	applicableDateRangeEnd = @ApplicableDateEnd,
			--	[historicalDateRange] = REPLACE(REPLACE(REPLACE(@HistoricDates, CHAR(13), ''), CHAR(10), ''), ' ', ''),
			--	[lastUpdatedDateTime] = GETDATE(),
			--	[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			--	[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			--	[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME()),
			--	status = 'NEW'
			--WHERE PowerCurveDetailID=@PowerCurveDetailId


     
			SET @StatusCode = 200; 
			SET @StatusMessage = '{"status":"success"}';

        
			COMMIT TRANSACTION;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @StatusCode = 0; 
        SET @StatusMessage = ERROR_MESSAGE();

        INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
        VALUES (@StatusMessage, ERROR_SEVERITY(), ERROR_STATE(), GETDATE());

        THROW;
    END CATCH
END;


