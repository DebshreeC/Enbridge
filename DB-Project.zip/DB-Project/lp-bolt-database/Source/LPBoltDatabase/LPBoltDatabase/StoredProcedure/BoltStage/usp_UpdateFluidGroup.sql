﻿
CREATE PROCEDURE [bolt_stage].[usp_UpdateFluidGroup] 
@DraftFluidGroupData NVARCHAR(max),
@StatusMessage NVARCHAR(4000) OUTPUT ,@StatusCode INT OUTPUT,@line varchar(20),
@username varchar(255), @userid VARCHAR(255), @userguid uniqueidentifier

	
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

	
		--Validate line-----------
		IF (
				(
					SELECT count(1)
					FROM bolt_stage.LineStationReference 
					WHERE line = @line
					) < 1
			)
		BEGIN
			SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Invalid line.';

			INSERT INTO bolt_stage.ErrorLog (
				ErrorMessage
				,ErrorSeverity
				,ErrorState
				,ErrorTime
				)
			VALUES (
				@StatusMessage
				,ERROR_SEVERITY()
				,ERROR_STATE()
				,GETDATE()
				);

			COMMIT TRANSACTION;-- Rollback on failure
			
			RETURN;
		END



		
  
-- Declare a table variable to hold the parsed JSON data
DECLARE @ParsedData TABLE (
   fluidGroup int,
   value  int

);

-- Insert JSON data into the table variable
INSERT INTO @ParsedData (fluidGroup,value)
SELECT 
 
    TRY_CAST(JSON_VALUE(value, '$.fluidGroup') AS int) AS fluidGroup,
    TRY_CAST(JSON_VALUE(value, '$.value') AS int) AS value
   
FROM OPENJSON(@DraftFluidGroupData, '$.data');

Declare @TotalPer as int 
select @TotalPer= sum(fluidGroupPercentage) from bolt_stage.DRA_fluidgroup where line=@line
and fluidGroup  not in (select fluidGroup  from  @ParsedData)

select @TotalPer= isnull(@TotalPer,0)+ sum(value)  from @ParsedData;





If(@TotalPer>100)
BEGIN
SET @StatusCode = 400;-- Indicate Bad Data
			SET @StatusMessage = 'Corresponding to this line fluid group percentage greater than  100% ';
Rollback TRAN;
RETURN;
END

	update   D  set  D.fluidGroupPercentage=P.value,
	updatedDateTime = GETDATE(),
			[updatedbyUserId]=COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),
			[updatedbyUserGUID]=COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
			[updatedbyUserName]=	COALESCE(NULLIF(@username,''),SUSER_NAME())
	 FROM bolt_stage.DRA_fluidgroup  D
    INNER JOIN @ParsedData P
        ON D.fluidGroup=p.fluidGroup
    WHERE D.line = @line;

		
			SET @StatusCode = 201;-- Indicate success--data inserted
			   SET @StatusMessage = 'fluid group updated successfully.';


			COMMIT TRANSACTION

		
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;-- Rollback if there is an active transaction

		SET @StatusCode = 0;-- Indicate failure
		SET @StatusMessage = ERROR_MESSAGE();
		print 'error';

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE()
			,@ErrorSeverity = ERROR_SEVERITY()
			,@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (
			ErrorMessage
			,ErrorSeverity
			,ErrorState
			,ErrorTime
			)
		VALUES (
			@ErrorMessage
			,@ErrorSeverity
			,@ErrorState
			,GETDATE()
			);

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END;
GO


