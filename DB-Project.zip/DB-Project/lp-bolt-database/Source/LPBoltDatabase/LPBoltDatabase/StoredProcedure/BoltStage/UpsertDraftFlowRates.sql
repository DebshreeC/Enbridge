﻿CREATE PROCEDURE [bolt_stage].[UpsertDraftFlowRates]
    @DraftFlowRateData NVARCHAR(MAX),
	@username VARCHAR(255),
    @userid VARCHAR(255),
    @userguid UNIQUEIDENTIFIER
AS
BEGIN
  BEGIN TRY
		-- Parse the JSON data into a table
		DECLARE @TempTable TABLE (
			Region VARCHAR(255),
			Line VARCHAR(255),
			draftFlowRatem3hr INT,
			draftFlowRateUpdatedDateTime DATETIME2(7)
		);
		BEGIN TRANSACTION
		INSERT INTO @TempTable ( Line, draftFlowRatem3hr, draftFlowRateUpdatedDateTime)
		SELECT 
			---JSON_VALUE(value, '$.region') AS Region,
			--JSON_VALUE(value, '$.line') AS Line,
			REPLACE(REPLACE(JSON_VALUE(value,'$.line') , CHAR(9), ''), '[^A-Za-z0-9 ]', '') As Line,
			JSON_VALUE(value, '$.draftFlowRatem3hr') AS draftFlowRatem3hr,
			GETDATE() AS draftFlowRateUpdatedDateTime
		FROM OPENJSON(@DraftFlowRateData, '$.Data') AS value;

		update T   set Region=LR.region
		from bolt_stage.LineStationReference  LR inner join @TempTable as T
		on  LR.line=T.line


		DELETE target FROM [bolt_stage].[DraftFlowRates] as target 
		JOIN @TempTable as Source on target.Line = source.line and target.Region=source.Region;
		
		INSERT INTO [bolt_stage].[DraftFlowRates] (Region, Line, draftFlowRatem3hr, draftFlowRateUpdatedDateTime
		  ,[updatedByUserId]
           ,[updatedByUserGUID]
           ,[updatedByUserName])
			SELECT region, line, draftFlowRatem3hr,draftFlowRateUpdatedDateTime,
			COALESCE(NULLIF(@userid,''),convert(nvarchar,USER_ID())),COALESCE(NULLIF(@userguid,NEWID()),NEWID()),
				COALESCE(NULLIF(@username,''),SUSER_NAME()) from @TempTable;
		COMMIT TRANSACTION	
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		ROLLBACK TRANSACTION
		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		-- Log the error details or take appropriate action
		-- For example, you could insert the error details into an error log table
		INSERT INTO bolt_stage.ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorTime)
		VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

		-- Re-throw the error to the calling application
		THROW;
	END CATCH
END